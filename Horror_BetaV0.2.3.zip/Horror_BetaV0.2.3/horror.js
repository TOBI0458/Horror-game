// ==========================================
// GAME CONFIGURATION
// ==========================================
const CURRENT_VERSION = "0.2.3";
const DOWNLOAD_URL = "https://github.com/TOBI0458/Horror-game"; // Change this to your download link
const VERSION_CHECK_URL = "https://raw.githubusercontent.com/TOBI0458/Horror-game/main/version.json";

// Hier kannst du neue Updates einfach eintragen:
// Layout: NEW THINGS, CHANGES, FIXES, UPCOMING
const CHANGELOG_DATA = [
    {
        version: "0.2.3",
        changes: [
            "<span class='log-tag new'>NEW</span> Real recorded sounds from the web (thunder, growls, screams, creaking doors, howling wind)",
            "<span class='log-tag change'>CHG</span> Completely redesigned monster: pale skin, visible ribs, unhinged jaw, jerky twitching",
            "<span class='log-tag new'>NEW</span> FNAF-style main menu: TV static, scanlines, flickering title and a '>>' selection list",
            "<span class='log-tag new'>NEW</span> Modern, minimalist death screen with run statistics",
            "<span class='log-tag change'>CHG</span> More realistic death portrait: skin pores, veins, corpse blotches, asymmetric skull, wet teeth",
            "<span class='log-tag new'>NEW</span> You can faintly hear the monster roaming in the distance (stereo direction + muffled by distance)",
            "<span class='log-tag change'>CHG</span> Scarier layered jumpscare scream with sub-bass impact",
            "<span class='log-tag change'>CHG</span> Wind is much quieter, whispering sound removed",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.2",
        changes: [
            "<span class='log-tag new'>NEW</span> Real photo textures (bricks & wood) loaded from the web, with horror post-processing",
            "<span class='log-tag new'>NEW</span> Full sound overhaul: thunder, ambient drone, monster growls, heartbeat, whispers, door creaks, jumpscare scream",
            "<span class='log-tag fix'>FIX</span> Stairs finally work: press E once and you climb automatically (all difficulties are finishable now)",
            "<span class='log-tag change'>CHG</span> Scarier atmosphere: film grain, flashlight blackouts, exhausted breathing",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.1.1",
        changes: [
            "<span class='log-tag change'>CHG</span> Version update to 0.2.1.1",
            "<span class='log-tag fix'>FIX</span> Corrected vertical look sensitivity and light synchronization",
            "<span class='log-tag new'>NEW</span> Sounds for the ground.",
            "<span class='log-tag fix'>FIX</span> Fixed bugs.",
            "<strong>Upcoming:</strong>",
            "• Fixing Stairs (Only Easy Gamemode is finishable)",
            "• More sounds",
            "• And much more....."
        ]
    },
    {
        version: "0.2.1",
        changes: [
            "<span class='log-tag new'>NEW</span> Integrated an 'Update Available' notification system",
            "<span class='log-tag new'>NEW</span> Added a dedicated, scrollable Changelog modal",
            "<span class='log-tag change'>CHG</span> Centralized version management and UI sync",
            "<span class='log-tag change'>CHG</span> Enhanced legibility with high-contrast text shadows",
            "<span class='log-tag change'>CHG</span> Migrated the entire interface to English",
            "<span class='log-tag change'>CHG</span> Adjusted color palette for better menu visibility",
            "<span class='log-tag fix'>FIX</span> Resolved UI listener lockout when skipping intro"
        ]
    },
    {
        version: "0.2.0",
        changes: [
            "Initial Beta release",
            "Added monster AI and floor generation",
            "Implemented key collection mechanics"
        ]
    },
];

const canvas = document.getElementById('gameCanvas');
const ctx = canvas ? canvas.getContext('2d', { alpha: false }) : null;

if (!canvas)
{
    console.error("Fehler: 'gameCanvas' nicht im HTML gefunden! Das Spiel kann nicht starten.");
}

let width, height;

let cachedScreenImg = null;
let cachedPixels = null;
let zBuffer = null;

window.addEventListener('load', () =>
{
    // Sync the top-right version display with the actual version variable
    const versionDisplay = document.getElementById('game-version');
    if (versionDisplay)
    {
        versionDisplay.textContent = 'V' + CURRENT_VERSION;
    }

    const intro = document.getElementById('intro-screen');
    const introText = document.querySelector('#intro-screen h2');

    // Prüfen, ob das Intro in dieser Sitzung bereits gezeigt wurde
    if (sessionStorage.getItem('introPlayed'))
    {
        if (intro)
        {
            intro.classList.add('hidden');
        }
    }
    else
    {
        // Starte die Text-Animation erst, wenn alles geladen ist
        if (introText)
        {
            introText.classList.add('start-anim');
        }

        setTimeout(() =>
        {
            if (intro)
            {
                intro.style.opacity = '0';
                setTimeout(() =>
                {
                    intro.classList.add('hidden');
                    // Marker setzen, damit es beim nächsten Reload übersprungen wird
                    sessionStorage.setItem('introPlayed', 'true');
                }, 1500);
            }
        }, 4000); 
    }

    // Changelog Initialisierung
    const trigger = document.getElementById('changelog-trigger');
    const modal = document.getElementById('changelog-modal');
    const closeBtn = document.getElementById('changelog-close-btn');
    const list = document.getElementById('changelog-list');

    // Update Button Logic
    const updateBtn = document.getElementById('update-btn');
    console.log("Update-Button im HTML gefunden?", updateBtn ? "Ja" : "Nein, ID prüfen!");

    if (updateBtn) {
        fetch(VERSION_CHECK_URL)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Datei nicht gefunden (404)! Prüfe ob 'main' oder 'master' der richtige Branch ist. URL: ${VERSION_CHECK_URL}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("Update Check:", { lokal: CURRENT_VERSION, remote: data.version });
                
                if (data.version && data.version !== CURRENT_VERSION) {
                    console.log("Versionen sind unterschiedlich. Button wird eingeblendet.");
                    updateBtn.classList.remove('hidden');
                    updateBtn.style.display = "block"; // Sicherstellen, dass er nicht per CSS versteckt bleibt
                    updateBtn.addEventListener('click', () => {
                        if (confirm(`A new version (${data.version}) is available. Do you want to download it?`)) {
                            window.open(data.download_url || DOWNLOAD_URL, '_blank');
                        }
                    });
                } else {
                    console.log("Kein Update nötig oder Versionen identisch.");
                }
            })
            .catch(err => console.error("Fehler beim Update-Check:", err.message));
    }

    if (trigger && modal && closeBtn && list)
    {
        trigger.addEventListener('click', () =>
        {
            list.innerHTML = CHANGELOG_DATA
                .filter(entry => entry.version === CURRENT_VERSION)
                .map(entry => 
                {
                    return `
                    <div class="changelog-entry">
                        <h3>Version ${entry.version}</h3>
                        <ul>${entry.changes.map(c => `<li>${c}</li>`).join('')}</ul>
                    </div>
                `;
                }).join('');
            modal.classList.remove('hidden');
        });
        closeBtn.addEventListener('click', () => modal.classList.add('hidden'));
    }
});

function resize()
{
    if (!canvas) return;
    // Performance: Halbe Auflösung rendern, aber auf volle Größe skalieren
    width = Math.floor(window.innerWidth / 2);
    height = Math.floor(window.innerHeight / 2);
    canvas.style.width = window.innerWidth + 'px';
    canvas.style.height = window.innerHeight + 'px';
    canvas.width = width;
    canvas.height = height;
}
window.addEventListener('resize', resize);
resize();

// --- TEXTUR LADEN (OPTIMIERT) ---
function loadExternalImage(url)
{
    const img = new Image();
    img.crossOrigin = "anonymous"; // Erlaubt die Verwendung auf dem Canvas (CORS)
    img.src = url;
    return img;
}

// --- PROZEDURAL GENERIERTE TEXTUREN (keine externen Abhängigkeiten) ---

// Gemeinsame Hilfsfunktionen für Textur-Generierung
function noise2D(x, y)
{
    const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
    return n - Math.floor(n);
}

function smoothNoise(x, y)
{
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const fx = x - ix;
    const fy = y - iy;
    // Smoothstep
    const sfx = fx * fx * (3 - 2 * fx);
    const sfy = fy * fy * (3 - 2 * fy);
    const a = noise2D(ix, iy);
    const b = noise2D(ix + 1, iy);
    const cc = noise2D(ix, iy + 1);
    const d = noise2D(ix + 1, iy + 1);
    return a + (b - a) * sfx + (cc - a) * sfy + (a - b - cc + d) * sfx * sfy;
}

function fbm(x, y, octaves)
{
    let val = 0, amp = 0.5, freq = 1;
    for (let i = 0; i < octaves; i++)
    {
        val += amp * smoothNoise(x * freq, y * freq);
        amp *= 0.5;
        freq *= 2;
    }
    return val;
}

function makeSeededRandom(startSeed)
{
    let s = startSeed;
    return function ()
    {
        s = (s * 16807 + 0) % 2147483647;
        return (s - 1) / 2147483646;
    };
}

// --- 1. WAND-TEXTUR: Alte Steinmauer / rissiger Putz ---
function createWallTexture()
{
    const size = 1024;
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const c = cv.getContext('2d');
    const imgData = c.createImageData(size, size);
    const data = imgData.data;
    const rand = makeSeededRandom(54321);

    // Ziegelmuster-Parameter
    const brickH = 32, brickW = 64, mortarSize = 3;

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Welcher Ziegel?
            const row = Math.floor(py / brickH);
            const offset = (row % 2 === 0) ? 0 : brickW / 2;
            const bx = ((px + offset) % brickW);
            const by = py % brickH;

            // Fuge?
            const isMortar = bx < mortarSize || by < mortarSize;

            let r, g, b;
            if (isMortar)
            {
                // Dunkelgrauer Mörtel
                const n = noise2D(px * 0.1, py * 0.1) * 15;
                r = 25 + n; g = 22 + n; b = 20 + n;
            }
            else
            {
                // Stein-Basis: dunkler Grau-Braun
                const brickSeed = row * 37 + Math.floor((px + offset) / brickW) * 53;
                const brickVariation = noise2D(brickSeed, 0) * 30 - 15;

                const baseR = 55 + brickVariation;
                const baseG = 48 + brickVariation * 0.8;
                const baseB = 42 + brickVariation * 0.5;

                // Stein-Textur
                const stoneTex = fbm(px * 0.03, py * 0.03, 4) * 20 - 10;
                // Feinstruktur
                const micro = (noise2D(px * 0.3, py * 0.3) - 0.5) * 12;

                r = baseR + stoneTex + micro;
                g = baseG + stoneTex * 0.8 + micro * 0.8;
                b = baseB + stoneTex * 0.5 + micro * 0.6;

                // Kanten der Ziegel: leicht dunkler
                const edgeDist = Math.min(bx - mortarSize, brickW - bx, by - mortarSize, brickH - by);
                if (edgeDist < 4)
                {
                    const edgeDarken = (1 - edgeDist / 4) * 0.2;
                    r *= (1 - edgeDarken);
                    g *= (1 - edgeDarken);
                    b *= (1 - edgeDarken);
                }

                // Feuchtigkeitsflecken
                const damp = fbm(px * 0.005 + 3.3, py * 0.008 + 1.7, 3);
                if (damp > 0.6)
                {
                    const dampAmt = (damp - 0.6) * 2;
                    r *= (1 - dampAmt * 0.3);
                    g *= (1 - dampAmt * 0.2);
                    b *= (1 - dampAmt * 0.1);
                }
            }

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);

    // Risse
    c.globalCompositeOperation = 'multiply';
    for (let crack = 0; crack < 5; crack++)
    {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 15; s++)
        {
            cx += (rand() - 0.5) * 20;
            cy += rand() * 15 + 3;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(5, 3, 2, ${0.4 + rand() * 0.3})`;
        c.lineWidth = 0.5 + rand() * 1;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';
    return cv;
}

// --- 2. DECKEN-TEXTUR: Alter Putz mit Wasserflecken und Schimmel ---
function createCeilingTexture()
{
    const size = 1024;
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const c = cv.getContext('2d');
    const imgData = c.createImageData(size, size);
    const data = imgData.data;
    const rand = makeSeededRandom(99887);

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Basis: schmutzig-weißer Putz
            const baseVal = 38;
            const plasterNoise = fbm(px * 0.02, py * 0.02, 4) * 15 - 7;
            const micro = (noise2D(px * 0.2, py * 0.2) - 0.5) * 8;

            let r = baseVal + plasterNoise + micro;
            let g = baseVal + plasterNoise * 0.95 + micro * 0.9;
            let b = baseVal + plasterNoise * 0.85 + micro * 0.85;

            // Wasserflecken (gelblich-braun)
            const water = fbm(px * 0.006 + 7.7, py * 0.006 + 2.3, 4);
            if (water > 0.55)
            {
                const wAmt = (water - 0.55) * 3;
                r += wAmt * 18;
                g += wAmt * 10;
                b -= wAmt * 5;
            }

            // Schimmelflecken (dunkelgrün/schwarz)
            const mold = fbm(px * 0.008 + 44.1, py * 0.008 + 22.5, 3);
            if (mold > 0.68)
            {
                const mAmt = (mold - 0.68) * 4;
                r *= (1 - mAmt * 0.6);
                g *= (1 - mAmt * 0.3);
                b *= (1 - mAmt * 0.5);
                g += mAmt * 4; // leichter Grünstich
            }

            // Putzrisse / Abblättern
            const crackNoise = fbm(px * 0.015 + 11.1, py * 0.015 + 33.3, 5);
            if (crackNoise > 0.72)
            {
                const cAmt = (crackNoise - 0.72) * 5;
                r -= cAmt * 12;
                g -= cAmt * 12;
                b -= cAmt * 10;
            }

            // Spinnweben-Simulation (helle Streifen)
            const web = Math.sin(px * 0.02 + py * 0.015 + noise2D(px * 0.005, py * 0.005) * 8);
            if (Math.abs(web) > 0.98)
            {
                r += 8; g += 8; b += 8;
            }

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);
    return cv;
}

// --- 3. BODEN-TEXTUR: Alte Holzdielen ---
function createDetailedFloorTexture()
{
    const size = 1024;
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = size;
    floorCanvas.height = size;
    const c = floorCanvas.getContext('2d');
    const rand = makeSeededRandom(12345);

    // Basis-Holzfarbe (dunkles, altes Holz)
    const baseR = 45, baseG = 30, baseB = 18;

    // Dielen-Layout
    const plankWidth = 50 + (rand() * 20 | 0);
    const numPlanks = Math.ceil(size / plankWidth) + 1;
    const planks = [];
    let currentX = 0;
    for (let i = 0; i < numPlanks; i++)
    {
        const w = plankWidth + (rand() * 16 - 8 | 0);
        planks.push({ x: currentX, w: w, hue: rand() * 18 - 9, brightness: rand() * 22 - 11, grainSeed: rand() * 1000 });
        currentX += w;
    }

    const imgData = c.createImageData(size, size);
    const data = imgData.data;

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Welche Diele?
            let plank = planks[0], plankIdx = 0;
            for (let i = 0; i < planks.length; i++)
            {
                if (px >= planks[i].x && px < planks[i].x + planks[i].w)
                {
                    plank = planks[i]; plankIdx = i; break;
                }
            }

            const localX = px - plank.x;
            const plankEdgeDist = Math.min(localX, plank.w - localX);

            // Holzmaserung
            const grainY = py * 0.02 + plank.grainSeed;
            const grain = Math.sin(grainY * 3.5 + smoothNoise(px * 0.01, py * 0.04) * 5) * 0.5 + 0.5;
            const grainFine = Math.sin(grainY * 12 + noise2D(px * 0.02, py * 0.05) * 3) * 0.12;

            // Astlöcher (mehr als vorher)
            let knotDark = 0;
            const knots = [
                { cx: (plank.x + plank.w * 0.3) % size, cy: (150 + plankIdx * 317) % size },
                { cx: (plank.x + plank.w * 0.7) % size, cy: (400 + plankIdx * 251) % size },
                { cx: (plank.x + plank.w * 0.5) % size, cy: (50 + plankIdx * 113) % size },
                { cx: (plank.x + plank.w * 0.2) % size, cy: (280 + plankIdx * 401) % size }
            ];
            for (let k of knots)
            {
                const kd = Math.hypot(px - k.cx, py - k.cy);
                if (kd < 14) knotDark = Math.max(knotDark, (1 - kd / 14) * 0.5 + Math.sin(kd * 0.9) * 0.1);
            }

            let r = baseR + plank.hue + plank.brightness;
            let g = baseG + plank.hue * 0.5 + plank.brightness * 0.7;
            let b = baseB + plank.brightness * 0.3;

            // Maserung
            const ge = grain * 14 + grainFine * 9;
            r += ge; g += ge * 0.7; b += ge * 0.3;

            // Knoten
            r *= (1 - knotDark); g *= (1 - knotDark); b *= (1 - knotDark);

            // Fugen
            if (plankEdgeDist <= 2)
            {
                const f = plankEdgeDist / 2 * 0.3 + 0.05;
                r *= f; g *= f; b *= f;
            }

            // Abnutzung
            const age = fbm(px * 0.01, py * 0.01, 3);
            const af = 1 - age * 0.22;
            r *= af; g *= af; b *= af;

            // Dreck
            const stain = fbm(px * 0.005 + 5.7, py * 0.005 + 3.2, 3);
            if (stain > 0.6)
            {
                const si = (stain - 0.6) * 3;
                r *= (1 - si * 0.5); g *= (1 - si * 0.45); b *= (1 - si * 0.3);
            }

            // Wasser/Feuchtigkeitspützen
            const water = fbm(px * 0.007 + 12.3, py * 0.007 + 45.6, 3);
            if (water > 0.65)
            {
                const wi = (water - 0.65) * 4;
                r *= (1 - wi * 0.7);
                g *= (1 - wi * 0.7);
                b *= (1 - wi * 0.6); // Leicht bläuliche/dunkle Spiegelung
            }

            // Schimmel (grünlich) in den Ecken oder feuchten Stellen
            const mold = fbm(px * 0.01 + 88.2, py * 0.01 + 22.1, 4);
            if (mold > 0.7)
            {
                const mi = (mold - 0.7) * 5;
                r *= (1 - mi * 0.8);
                g *= (1 - mi * 0.3); // Erhält mehr Grün
                b *= (1 - mi * 0.8);
                g += mi * 18; // Grünstich hinzufügen
            }

            // Blut-Suggestion (gewischt)
            const blood = fbm(px * 0.006 + 99.1, py * 0.006 + 77.3, 3);
            if (blood > 0.78)
            {
                const bi = (blood - 0.78) * 5;
                r = r * (1 - bi * 0.3) + 40 * bi;
                g *= (1 - bi * 0.7); b *= (1 - bi * 0.6);
            }

            // Nägel und Rost
            const nailY = py % 120;
            if (nailY < 5)
            {
                const n1 = Math.hypot(px - (plank.x + plank.w * 0.15), nailY - 2.5);
                const n2 = Math.hypot(px - (plank.x + plank.w * 0.85), nailY - 2.5);
                const nd = Math.min(n1, n2);
                if (nd < 2.5) { const ns = 0.2 + nd / 2.5 * 0.2; r *= ns; g *= ns; b *= ns; }
            }
            else if (nailY >= 5 && nailY < 20)
            {
                // Rost läuft von den Nägeln herunter
                const rx_dist = Math.min(Math.abs(px - (plank.x + plank.w * 0.15)), Math.abs(px - (plank.x + plank.w * 0.85)));
                if (rx_dist < 3)
                {
                    const rust_amt = (1 - rx_dist / 3) * (1 - (nailY - 5) / 15) * (noise2D(px * 0.1, py * 0.1) * 0.5 + 0.5);
                    r = r * (1 - rust_amt * 0.4) + 50 * rust_amt; // Rost-Rot/Orange
                    g = g * (1 - rust_amt * 0.5) + 20 * rust_amt;
                    b *= (1 - rust_amt * 0.8);
                }
            }

            // Mikro-Rauschen
            const mn = (noise2D(px * 0.5, py * 0.5) - 0.5) * 7;
            r += mn; g += mn * 0.8; b += mn * 0.5;

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);

    // --- Post-Processing Details auf dem Canvas ---

    // 1. Risse (Längs)
    c.globalCompositeOperation = 'multiply';
    for (let crack = 0; crack < 10; crack++)
    { // Mehr Risse
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 12 + (rand() * 10 | 0); s++)
        {
            cx += (rand() - 0.5) * 12; cy += rand() * 18 + 3;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(10, 5, 2, ${0.3 + rand() * 0.35})`;
        c.lineWidth = 0.4 + rand() * 1.2;
        c.stroke();
    }

    // 2. Horizontale Kratzer (Quer zu den Dielen)
    for (let i = 0; i < 25; i++)
    {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        let scratchLength = 2 + (rand() * 4 | 0);
        for (let j = 0; j < scratchLength; j++)
        {
            cx += (rand() - 0.5) * 25 + 10; // Querbewegung
            cy += (rand() - 0.5) * 4;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(8, 4, 2, ${0.4 + rand() * 0.5})`;
        c.lineWidth = 0.3 + rand() * 0.8;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';

    // 3. Frische Blutstropfen und Spritzer
    c.fillStyle = 'rgba(80, 0, 0, 0.85)';
    for (let i = 0; i < 40; i++)
    {
        let bx = rand() * size, by = rand() * size;
        let bSize = rand() * 3 + 0.5;

        c.beginPath();
        c.arc(bx, by, bSize, 0, Math.PI * 2);
        c.fill();

        // Laufspur/Schmierspur
        if (rand() > 0.6) {
            c.beginPath();
            c.moveTo(bx, by);
            // Spur zieht sich in eine Richtung
            let dx = (rand() - 0.5) * 15;
            let dy = rand() * 20;
            c.lineTo(bx + dx, by + dy);
            c.lineWidth = bSize * 0.6;
            c.strokeStyle = 'rgba(60, 0, 0, 0.7)';
            c.stroke();
        }
    }

    return floorCanvas;
}

// ==========================================
// TEXTUREN: Echte Foto-Texturen aus dem Netz (CORS-frei, three.js CDN)
// mit Horror-Nachbearbeitung. Prozedurale Texturen dienen als Offline-Fallback.
// ==========================================
const TEXTURE_URLS = {
    wall: 'https://threejs.org/examples/textures/brick_diffuse.jpg',
    floor: 'https://threejs.org/examples/textures/hardwood2_diffuse.jpg',
    ceiling: 'https://threejs.org/examples/textures/hardwood2_diffuse.jpg' // wird rotiert & stark abgedunkelt (Holzbalkendecke)
};

// Prozedurale Fallbacks zuerst generieren
const proceduralWall = createWallTexture();
const proceduralCeiling = createCeilingTexture();
const proceduralFloor = createDetailedFloorTexture();

function makeCompositeCanvas(source) {
    const cv = document.createElement('canvas');
    cv.width = 1024; cv.height = 1024;
    cv.getContext('2d').drawImage(source, 0, 0, 1024, 1024);
    return cv;
}

// Die Render-Pipeline nutzt diese Canvases. Sie starten mit dem Fallback
// und werden überschrieben, sobald die Web-Texturen geladen sind.
const wallImg = makeCompositeCanvas(proceduralWall);
const ceilingImg = makeCompositeCanvas(proceduralCeiling);
const floorImg = makeCompositeCanvas(proceduralFloor);

// Horror-Nachbearbeitung: abdunkeln, entsättigen, Schmutz- und Schimmelflecken
function applyHorrorGrunge(cv, opts) {
    const c = cv.getContext('2d');
    const size = cv.width;
    const rand = makeSeededRandom(opts.seed);

    // Entsättigen (kaltes, totes Grau)
    if (opts.desat > 0) {
        c.globalCompositeOperation = 'saturation';
        c.fillStyle = `rgba(128, 128, 128, ${opts.desat})`;
        c.fillRect(0, 0, size, size);
    }

    // Abdunkeln
    c.globalCompositeOperation = 'source-over';
    c.fillStyle = `rgba(0, 0, 0, ${opts.darken})`;
    c.fillRect(0, 0, size, size);

    // Feuchtigkeits- und Schimmelflecken
    c.globalCompositeOperation = 'multiply';
    for (let i = 0; i < 16; i++) {
        const x = rand() * size, y = rand() * size, r = 60 + rand() * 200;
        const g = c.createRadialGradient(x, y, 0, x, y, r);
        const tone = opts.moldGreen ? '90, 110, 80' : '90, 75, 60';
        g.addColorStop(0, `rgba(${tone}, ${0.45 + rand() * 0.35})`);
        g.addColorStop(1, 'rgba(255, 255, 255, 0)');
        c.fillStyle = g;
        c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }

    // Kratzer / Risse
    for (let i = 0; i < 12; i++) {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 10; s++) {
            cx += (rand() - 0.5) * 30;
            cy += rand() * 25 + 5;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(15, 10, 8, ${0.3 + rand() * 0.4})`;
        c.lineWidth = 0.5 + rand() * 1.5;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';

    // Blutspuren (nur wenn gewünscht)
    if (opts.blood) {
        for (let i = 0; i < 30; i++) {
            const bx = rand() * size, by = rand() * size;
            const bSize = rand() * 4 + 1;
            c.fillStyle = `rgba(70, 0, 0, ${0.5 + rand() * 0.35})`;
            c.beginPath(); c.arc(bx, by, bSize, 0, Math.PI * 2); c.fill();
            if (rand() > 0.6) {
                c.strokeStyle = 'rgba(55, 0, 0, 0.6)';
                c.lineWidth = bSize * 0.6;
                c.beginPath();
                c.moveTo(bx, by);
                c.lineTo(bx + (rand() - 0.5) * 20, by + rand() * 30);
                c.stroke();
            }
        }
    }
}

function loadTextureInto(targetCv, url, compose) {
    return new Promise(resolve => {
        const img = loadExternalImage(url);
        const timeout = setTimeout(() => resolve(false), 8000);
        img.onload = () => {
            clearTimeout(timeout);
            try {
                compose(targetCv, img);
                console.log("Web-Textur geladen:", url);
                resolve(true);
            } catch (e) {
                console.warn("Web-Textur konnte nicht verarbeitet werden (Fallback aktiv):", e);
                resolve(false);
            }
        };
        img.onerror = () => {
            clearTimeout(timeout);
            console.warn("Web-Textur nicht erreichbar (Fallback aktiv):", url);
            resolve(false);
        };
    });
}

const texturesReady = Promise.all([
    // Wände: alte Ziegelmauer
    loadTextureInto(wallImg, TEXTURE_URLS.wall, (cv, img) => {
        const c = cv.getContext('2d');
        c.drawImage(img, 0, 0, 1024, 1024);
        applyHorrorGrunge(cv, { darken: 0.45, desat: 0.45, seed: 777, moldGreen: false });
    }),
    // Boden: alte Holzdielen mit Blutspuren
    loadTextureInto(floorImg, TEXTURE_URLS.floor, (cv, img) => {
        const c = cv.getContext('2d');
        c.drawImage(img, 0, 0, 1024, 1024);
        applyHorrorGrunge(cv, { darken: 0.55, desat: 0.35, seed: 1234, moldGreen: false, blood: true });
    }),
    // Decke: rotierte, fast schwarze Holzbalken mit Schimmel
    loadTextureInto(ceilingImg, TEXTURE_URLS.ceiling, (cv, img) => {
        const c = cv.getContext('2d');
        c.save();
        c.translate(512, 512);
        c.rotate(Math.PI / 2);
        c.drawImage(img, -512, -512, 1024, 1024);
        c.restore();
        applyHorrorGrunge(cv, { darken: 0.72, desat: 0.6, seed: 4242, moldGreen: true });
    })
]);

// Hilfsfunktion um Pixeldaten aus Bildern zu extrahieren
let floorPixels = null, ceilingPixels = null, wallPixels = null;

const assetList = [
    { img: wallImg, setter: (p) => wallPixels = p, name: "Wand" },
    { img: floorImg, setter: (p) => floorPixels = p, name: "Boden" },
    { img: ceilingImg, setter: (p) => ceilingPixels = p, name: "Decke" }
];

function extractPixels(img, callback)
{
    return new Promise((resolve) =>
    {
        const process = () =>
        {
            try
            {
                const off = document.createElement('canvas');
                off.width = 1024; off.height = 1024;
                const octx = off.getContext('2d');
                octx.drawImage(img, 0, 0, 1024, 1024);
                const data = octx.getImageData(0, 0, 1024, 1024).data;
                callback(new Uint32Array(data.buffer));
                resolve();
            }
            catch (e)
            {
                console.error("Fehler bei Pixel-Extraktion:", e);
                resolve(); // Trotzdem weiter, um den Ladebildschirm nicht zu blockieren
            }
        };

        // Canvas-Elemente (prozedural generiert) sofort verarbeiten
        if (img instanceof HTMLCanvasElement) {
            process();
            return;
        }

        // Sicherheits-Timeout: Falls ein Bild gar nicht reagiert, nach 5 Sek. weitermachen
        const timeout = setTimeout(() =>
        {
            console.warn("Lade-Timeout für Bild:", img.src);
            resolve();
        }, 5000);

        const wrappedProcess = () =>
        {
            clearTimeout(timeout);
            process();
        };

        if (img.complete)
        {
            if (img.naturalWidth > 0)
            {
                wrappedProcess();
            }
            else
            {
                // Bild ist 'complete', aber kaputt -> nicht hängen bleiben
                clearTimeout(timeout);
                resolve();
            }
        }
        else
        {
            img.onload = wrappedProcess;
            img.onerror = () =>
            {
                clearTimeout(timeout);
                console.error("Bild konnte nicht geladen werden:", img.src);
                resolve();
            };
        }
    });
}

const stairsImg = new Image(); stairsImg.src = 'treppe.png';
const doorImg = new Image(); doorImg.src = 'tuer.png';

let floorPattern, ceilingPattern;

// --- TEXTUR-GENERATOR FÜR FALLBACKS (Gegen unsichtbare Objekte) ---
function createFallbackTex(color1, color2, type) {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 256;
    const c = canvas.getContext('2d');
    c.fillStyle = color1;
    c.fillRect(0, 0, 256, 256);
    if (type === 'door') {
        c.strokeStyle = color2;
        c.lineWidth = 4;
        c.strokeRect(20, 20, 216, 216);
        c.strokeRect(40, 40, 176, 80);
        c.strokeRect(40, 140, 176, 80);
        c.fillStyle = color2;
        c.beginPath(); c.arc(200, 128, 10, 0, Math.PI * 2); c.fill();
    } else {
        // Prozedurale Rausch-Textur für Wände/Boden
        for (let i = 0; i < 2000; i++) {
            let x = Math.random() * 256;
            let y = Math.random() * 256;
            let size = Math.random() * 2;
            c.fillStyle = Math.random() > 0.5 ? color2 : 'rgba(0,0,0,0.2)';
            c.fillRect(x, y, size, size);
        }
        c.strokeStyle = color2;
        c.strokeRect(0, 0, 256, 256);
    }
    return canvas;
}

const wallTexFallback = createFallbackTex('#222', '#111', 'wall');
const doorTexFallback = createFallbackTex('#3d2b1f', '#1a0f00', 'door');
const stairsTexFallback = createFallbackTex('#333', '#222', 'stairs');

const TILE_SIZE = 60;
const MAP_WIDTH = 80;  // Riesige Map
const MAP_HEIGHT = 60; // Riesige Map

// --- SCHWIERIGKEITSGRADE ---
const DIFFICULTY_SETTINGS = {
    leicht: { floors: 1, keys: 5, enemiesPerFloor: 1, speed: 1.2, visionRange: 350, searchDist: 400, intelligence: 0, desc: "Gentle start. The monster is slow and forgetful." },
    normal: { floors: 2, keys: 10, enemiesPerFloor: 1, speed: 2.2, visionRange: 500, searchDist: 800, intelligence: 1, desc: "The standard experience. Balanced challenge." },
    schwer: { floors: 3, keys: 15, enemiesPerFloor: 1.7, speed: 3.0, visionRange: 750, searchDist: 1500, intelligence: 2, desc: "Persistent monsters that barely let you out of their sight." },
    impossible: { floors: 5, keys: 25, enemiesPerFloor: 3, speed: 4.2, visionRange: 1200, searchDist: 3000, intelligence: 3, desc: "Your death is certain. The monsters smell your fear." }
};
let currentDifficulty = 'normal';

let maps = [];
let currentFloor = 0;
const startScreenMap = [
    "111111111111".split(''),
    "100000000001".split(''),
    "111121121121".split(''), // doors on right wall
    "100000000001".split(''),
    "111111111111".split('')
];
let map = [];

let keysData = [];
let TOTAL_KEYS = 10;
let enemiesData = [];
let bloodSplattersData = [];
let doorsData = []; // Neues Array für Tür-Objekte
let torchesData = [];
let windowsData = [];

let audioCtx = null;

// ==========================================
// AUDIO SYSTEM (komplett mit WebAudio synthetisiert)
// ==========================================
let masterGain = null, reverbSend = null;

function getAudio() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    if (!masterGain) {
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.9;
        masterGain.connect(audioCtx.destination);

        // Prozeduraler Hall: lässt alles klingen wie in einem leeren alten Haus
        const convolver = audioCtx.createConvolver();
        const len = Math.floor(audioCtx.sampleRate * 2.2);
        const ir = audioCtx.createBuffer(2, len, audioCtx.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
            const d = ir.getChannelData(ch);
            for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5);
        }
        convolver.buffer = ir;
        reverbSend = audioCtx.createGain();
        reverbSend.gain.value = 0.35;
        reverbSend.connect(convolver);
        convolver.connect(masterGain);
    }
    return audioCtx;
}

// Routet eine Node trocken zum Master und anteilig in den Hall
function routeOut(node, wet) {
    node.connect(masterGain);
    if (wet > 0) {
        const w = audioCtx.createGain();
        w.gain.value = wet;
        node.connect(w);
        w.connect(reverbSend);
    }
}

function createNoiseBuffer(seconds) {
    const ac = getAudio();
    const len = Math.floor(ac.sampleRate * seconds);
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
}

// ==========================================
// ECHTE SOUND-SAMPLES AUS DEM NETZ (Wikimedia Commons, frei lizenziert)
// Werden im Hintergrund geladen; bis dahin (oder offline) greifen
// die synthetisierten Fallback-Sounds.
// ==========================================
const SOUND_URLS = {
    thunder: [
        'https://upload.wikimedia.org/wikipedia/commons/f/fa/Thunder_01.ogg',
        'https://upload.wikimedia.org/wikipedia/commons/7/75/Thunder_crack_2B.ogg'
    ],
    growl: [
        'https://upload.wikimedia.org/wikipedia/commons/7/71/Monster_growls.ogg',
        'https://upload.wikimedia.org/wikipedia/commons/3/36/Monster_growls_2.ogg'
    ],
    scream: [
        'https://upload.wikimedia.org/wikipedia/commons/9/92/Scream-e.wav',
        'https://upload.wikimedia.org/wikipedia/commons/d/dc/Scream-c.wav'
    ],
    doorCreak: [
        'https://upload.wikimedia.org/wikipedia/commons/7/74/Door_handle_creaking.ogg'
    ],
    wind: [
        'https://upload.wikimedia.org/wikipedia/commons/2/2d/Howling_wind.ogg'
    ]
};
const soundBank = {}; // name -> Array dekodierter AudioBuffer

function loadSoundBank() {
    try { getAudio(); } catch (e) { return; }
    Object.entries(SOUND_URLS).forEach(([name, urls]) => {
        soundBank[name] = [];
        urls.forEach(url => {
            fetch(url)
                .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
                .then(buf => audioCtx.decodeAudioData(buf))
                .then(decoded => {
                    soundBank[name].push(decoded);
                    console.log('Sound-Sample geladen:', name);
                })
                .catch(err => console.warn('Sample nicht ladbar (Synth-Fallback aktiv):', name, err.message));
        });
    });
}

// Spielt ein geladenes Sample ab. Gibt false zurück, wenn (noch) keines
// verfügbar ist — dann übernimmt der synthetisierte Fallback.
function playSample(name, opts = {}) {
    const bank = soundBank[name];
    if (!bank || bank.length === 0) return false;
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const buf = bank[(Math.random() * bank.length) | 0];
        const src = ac.createBufferSource();
        src.buffer = buf;
        src.playbackRate.value = opts.rate || 1;
        const vol = opts.volume != null ? opts.volume : 1;
        const g = ac.createGain();

        // Optionale Kette: Tiefpass (Distanz-Dämpfung) und Stereo-Panning (Richtungsortung)
        let chainEnd = src;
        if (opts.lowpass) {
            const lp = ac.createBiquadFilter();
            lp.type = 'lowpass';
            lp.frequency.value = opts.lowpass;
            chainEnd.connect(lp);
            chainEnd = lp;
        }
        if (opts.pan != null && ac.createStereoPanner) {
            const p = ac.createStereoPanner();
            p.pan.value = Math.max(-1, Math.min(1, opts.pan));
            chainEnd.connect(p);
            chainEnd = p;
        }

        if (opts.loop) {
            src.loop = true;
            g.gain.setValueAtTime(0.0001, now);
            g.gain.linearRampToValueAtTime(vol, now + 3); // langsam einblenden
            chainEnd.connect(g);
            routeOut(g, opts.wet != null ? opts.wet : 0.4);
            src.start(now);
            return src;
        }

        // Bei langen Aufnahmen einen zufälligen Ausschnitt spielen (mit Fades)
        let offset = 0, dur = buf.duration / (opts.rate || 1);
        if (opts.maxDur && dur > opts.maxDur) {
            dur = opts.maxDur;
            offset = Math.random() * (buf.duration - dur * (opts.rate || 1));
        }
        const fadeIn = Math.min(0.06, dur * 0.15);
        const fadeOut = Math.min(0.3, dur * 0.3);
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(vol, now + fadeIn);
        g.gain.setValueAtTime(vol, now + dur - fadeOut);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        chainEnd.connect(g);
        routeOut(g, opts.wet != null ? opts.wet : 0.4);
        src.start(now, offset);
        src.stop(now + dur + 0.1);
        return src;
    } catch (e) { return false; }
}

function playMonsterGrowl(intensity, opts = {}) {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.9 + Math.random() * 0.5;
        const vol = 0.45 * Math.max(0.1, Math.min(1, intensity));

        // Echtes Monster-Knurren (Sample), leicht heruntergepitcht für mehr Masse.
        // pan/lowpass erlauben Richtungsortung und Distanz-Dämpfung.
        if (playSample('growl', {
            volume: vol * 1.4, maxDur: 2.4,
            rate: 0.78 + Math.random() * 0.2,
            wet: opts.wet != null ? opts.wet : 0.5,
            pan: opts.pan,
            lowpass: opts.lowpass
        })) return;

        // Kehliges Knurren: tiefer Sägezahn mit Vibrato
        const o = ac.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(55 + Math.random() * 25, now);
        o.frequency.linearRampToValueAtTime(40, now + dur);
        const lfo = ac.createOscillator();
        lfo.frequency.value = 9 + Math.random() * 6;
        const lfoG = ac.createGain();
        lfoG.gain.value = 14;
        lfo.connect(lfoG); lfoG.connect(o.frequency);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass'; lp.frequency.value = 350;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(vol, now + 0.1);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        o.connect(lp); lp.connect(g); routeOut(g, 0.5);
        o.start(now); o.stop(now + dur);
        lfo.start(now); lfo.stop(now + dur);

        // Atem-Rauschen dazu
        const br = ac.createBufferSource();
        br.buffer = createNoiseBuffer(dur);
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 600; bp.Q.value = 1.5;
        const bg = ac.createGain();
        bg.gain.setValueAtTime(0.0001, now);
        bg.gain.exponentialRampToValueAtTime(vol * 0.4, now + 0.15);
        bg.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        br.connect(bp); bp.connect(bg); routeOut(bg, 0.5);
        br.start(now);
    } catch (e) { }
}

function playHeartbeat(intensity) {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const vol = 0.25 + intensity * 0.45;
        // "Lub-Dub": zwei tiefe Schläge
        [[0, vol], [0.16, vol * 0.6]].forEach(([off, v]) => {
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(60, now + off);
            o.frequency.exponentialRampToValueAtTime(35, now + off + 0.1);
            const g = ac.createGain();
            g.gain.setValueAtTime(v, now + off);
            g.gain.exponentialRampToValueAtTime(0.0001, now + off + 0.13);
            o.connect(g); g.connect(masterGain);
            o.start(now + off); o.stop(now + off + 0.15);
        });
    } catch (e) { }
}

function playDoorCreak() {
    try {
        // Echtes Türknarren (Sample) mit zufälliger Tonhöhe
        if (playSample('doorCreak', { volume: 0.35, maxDur: 1.8, rate: 0.7 + Math.random() * 0.4, wet: 0.6 })) return;

        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.8 + Math.random() * 0.4;
        const o = ac.createOscillator();
        o.type = 'sawtooth';
        // Knarrende, ruckelige Frequenzkurve
        let f = 120 + Math.random() * 80;
        o.frequency.setValueAtTime(f, now);
        let t = now;
        while (t < now + dur) {
            t += 0.05 + Math.random() * 0.1;
            f += (Math.random() - 0.35) * 90;
            f = Math.max(70, Math.min(450, f));
            o.frequency.linearRampToValueAtTime(f, t);
        }
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 700; bp.Q.value = 2;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(0.07, now + 0.1);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        o.connect(bp); bp.connect(g); routeOut(g, 0.6);
        o.start(now); o.stop(now + dur + 0.05);
    } catch (e) { }
}

function playKeyPickup() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        // Kleines metallisches Klimpern
        [880, 1318.5].forEach((f, i) => {
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.value = f;
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now + i * 0.07);
            g.gain.exponentialRampToValueAtTime(0.12, now + i * 0.07 + 0.02);
            g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.07 + 0.5);
            o.connect(g); routeOut(g, 0.6);
            o.start(now + i * 0.07); o.stop(now + i * 0.07 + 0.55);
        });
    } catch (e) { }
}

function playStairStep() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        // Schwerer Schritt auf alter Holzstufe
        const o = ac.createOscillator();
        o.type = 'sine';
        o.frequency.setValueAtTime(70 + Math.random() * 15, now);
        o.frequency.exponentialRampToValueAtTime(28, now + 0.07);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.8, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        o.connect(g); routeOut(g, 0.4);
        o.start(now); o.stop(now + 0.1);

        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(0.12);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass'; lp.frequency.value = 250 + Math.random() * 100;
        const ng = ac.createGain();
        ng.gain.setValueAtTime(0.6, now);
        ng.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        src.connect(lp); lp.connect(ng); routeOut(ng, 0.5);
        src.start(now);
    } catch (e) { }
}

function playExhaustedBreath() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.5;
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 500; bp.Q.value = 1.2;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(0.08, now + dur * 0.4);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        src.connect(bp); bp.connect(g); g.connect(masterGain);
        src.start(now);
    } catch (e) { }
}

function playJumpscareScream() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;

        // Mehrschichtiger Schrei: tiefer dämonischer Layer + schriller Layer
        // + Knurren direkt am Ohr + Sub-Bass-Schlag in der Brust
        if (playSample('scream', { volume: 1.0, rate: 0.58 + Math.random() * 0.08, wet: 0.85 })) {
            playSample('scream', { volume: 0.65, rate: 1.05, wet: 0.6 });
            playSample('growl', { volume: 0.9, maxDur: 2.0, rate: 0.62, wet: 0.6 });

            // Sub-Bass-Impact (spürbarer Schlag)
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(70, now);
            o.frequency.exponentialRampToValueAtTime(24, now + 0.5);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.9, now);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);
            o.connect(g); g.connect(masterGain);
            o.start(now); o.stop(now + 0.65);
            return;
        }

        const dur = 1.3;
        // Drei verstimmte, schrille Stimmen
        for (let i = 0; i < 3; i++) {
            const det = 1 + (i - 1) * 0.04;
            const o = ac.createOscillator();
            o.type = 'sawtooth';
            o.frequency.setValueAtTime(350 * det, now);
            o.frequency.exponentialRampToValueAtTime(1100 * det, now + 0.18);
            o.frequency.exponentialRampToValueAtTime(600 * det, now + dur);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.exponentialRampToValueAtTime(0.35, now + 0.04);
            g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
            o.connect(g); routeOut(g, 0.8);
            o.start(now); o.stop(now + dur);
        }
        // Schrilles Rauschen obendrauf
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const hp = ac.createBiquadFilter();
        hp.type = 'highpass'; hp.frequency.value = 1500;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.45, now);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        src.connect(hp); hp.connect(g); routeOut(g, 0.7);
        src.start(now);
    } catch (e) { }
}

let ambientStarted = false;
function startAmbientSound() {
    if (ambientStarted) return;
    try {
        const ac = getAudio();
        ambientStarted = true;
        const now = ac.currentTime;

        // Tiefer Drone: zwei leicht verstimmte Sinus-Oszillatoren erzeugen
        // eine langsam schwebende, bedrohliche Grundstimmung
        [[55, 0.04], [55.8, 0.04], [110.3, 0.015]].forEach(([f, v], i) => {
            const o = ac.createOscillator();
            o.type = i === 2 ? 'triangle' : 'sine';
            o.frequency.value = f;
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.linearRampToValueAtTime(v, now + 4); // langsam einblenden
            o.connect(g); routeOut(g, 0.9);
            o.start(now);
        });

        // Wind: bevorzugt echte Aufnahme (heulender Wind, geloopt),
        // sonst gefiltertes Rauschen mit langsamer Lautstärke-Modulation
        if (!playSample('wind', { volume: 0.07, loop: true, rate: 0.85, wet: 0.4 })) {
            const src = ac.createBufferSource();
            src.buffer = createNoiseBuffer(4);
            src.loop = true;
            const lp = ac.createBiquadFilter();
            lp.type = 'lowpass'; lp.frequency.value = 420; lp.Q.value = 0.8;
            const g = ac.createGain();
            g.gain.value = 0.018;
            const lfo = ac.createOscillator();
            lfo.frequency.value = 0.07;
            const lfoG = ac.createGain();
            lfoG.gain.value = 0.012;
            lfo.connect(lfoG); lfoG.connect(g.gain);
            src.connect(lp); lp.connect(g); routeOut(g, 0.6);
            src.start(now); lfo.start(now);
        }
    } catch (e) { ambientStarted = false; }
}

function playFootstepSound() {
    try {
        getAudio();

        const now = audioCtx.currentTime;

        // 1. Heel Impact (The Thump)
        let heel = audioCtx.createOscillator();
        let heelGain = audioCtx.createGain();
        heel.type = 'sine';
        heel.frequency.setValueAtTime(80 + Math.random() * 20, now);
        // Kürzere Ramp-Zeit (0.05 statt 0.08) verhindert den Laser-Effekt
        heel.frequency.exponentialRampToValueAtTime(30, now + 0.05);
        heelGain.gain.setValueAtTime(0.7, now);
        heelGain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
        heel.connect(heelGain);
        heelGain.connect(masterGain);
        heel.start(); heel.stop(now + 0.06);

        // 2. Hollow Wood Resonance (Filtered Noise)
        let resonance = audioCtx.createBufferSource();
        let bufferSize = audioCtx.sampleRate * 0.1;
        let buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        let data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        resonance.buffer = buffer;

        let filter = audioCtx.createBiquadFilter();
        filter.type = "lowpass"; // Lowpass macht den Sound dumpfer/holziger als Bandpass
        filter.frequency.value = 300 + Math.random() * 100;
        filter.Q.value = 1;

        let resGain = audioCtx.createGain();
        resGain.gain.setValueAtTime(0.8, now);
        resGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        resonance.connect(filter);
        filter.connect(resGain);
        resGain.connect(masterGain);
        resonance.start();

        // 3. Subtle Plank Creak (Occasional detail)
        if (Math.random() > 0.85) {
            let creak = audioCtx.createOscillator();
            let creakGain = audioCtx.createGain();
            creak.type = 'triangle';
            creak.frequency.setValueAtTime(150 + Math.random() * 50, now);
            creak.frequency.linearRampToValueAtTime(60, now + 0.1);
            creakGain.gain.setValueAtTime(0.12, now);
            creakGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
            creak.connect(creakGain); creakGain.connect(masterGain);
            creak.start(); creak.stop(now + 0.1);
        }
    } catch (e) { }
}

let thunderState = { active: false, intensity: 0, timer: 0, nextThunder: 300 };
let stingTimer = 500;

// --- MINIMAP SYSTEM ---
let minimapOpen = false;
let exploredTiles = []; // Array of Sets, one per floor
const EXPLORE_RADIUS = 6; // Tiles around the player that get revealed

function playScarySting() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const type = Math.random();

        if (type < 0.35) {
            // Metallisches Kratzen (wie Krallen an einem Rohr)
            const src = ac.createBufferSource();
            src.buffer = createNoiseBuffer(1.4);
            const bp = ac.createBiquadFilter();
            bp.type = 'bandpass'; bp.Q.value = 18;
            bp.frequency.setValueAtTime(2600, now);
            bp.frequency.exponentialRampToValueAtTime(500, now + 1.3);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.exponentialRampToValueAtTime(0.15, now + 0.25);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 1.4);
            src.connect(bp); bp.connect(g); routeOut(g, 0.7);
            src.start(now);
        } else if (type < 0.7) {
            // Dissonante Streicher (kleine Sekunde, schwillt langsam an)
            [138.6, 146.8].forEach(f => {
                const o = ac.createOscillator();
                o.type = 'sawtooth';
                o.frequency.value = f;
                const lp = ac.createBiquadFilter();
                lp.type = 'lowpass'; lp.frequency.value = 900;
                const g = ac.createGain();
                g.gain.setValueAtTime(0.0001, now);
                g.gain.linearRampToValueAtTime(0.06, now + 1.2);
                g.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);
                o.connect(lp); lp.connect(g); routeOut(g, 0.8);
                o.start(now); o.stop(now + 3);
            });
        } else {
            // Dumpfer Schlag in der Ferne (als käme er aus einer anderen Etage)
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(85, now);
            o.frequency.exponentialRampToValueAtTime(35, now + 0.4);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.3, now);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);
            o.connect(g); routeOut(g, 0.9);
            o.start(now); o.stop(now + 0.55);
        }
    } catch (e) { }
}

function playThunderSound() {
    try {
        // Echter Donner (Sample), leicht heruntergepitcht für mehr Wucht
        if (playSample('thunder', { volume: 0.8, rate: 0.8 + Math.random() * 0.3, wet: 0.5 })) return;

        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 2.5 + Math.random() * 1.5;

        // Grollen: Rauschen durch absinkenden Tiefpass
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass';
        lp.frequency.setValueAtTime(350, now);
        lp.frequency.exponentialRampToValueAtTime(45, now + dur);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(0.7, now + 0.08);
        g.gain.exponentialRampToValueAtTime(0.2, now + dur * 0.4);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        src.connect(lp); lp.connect(g); routeOut(g, 0.5);
        src.start(now);

        // Sub-Bass-Grollen darunter
        const sub = ac.createOscillator();
        sub.type = 'sine';
        sub.frequency.setValueAtTime(50, now);
        sub.frequency.exponentialRampToValueAtTime(28, now + dur);
        const sg = ac.createGain();
        sg.gain.setValueAtTime(0.0001, now);
        sg.gain.exponentialRampToValueAtTime(0.4, now + 0.15);
        sg.gain.exponentialRampToValueAtTime(0.0001, now + dur * 0.8);
        sub.connect(sg); sg.connect(masterGain);
        sub.start(now); sub.stop(now + dur);
    } catch (e) { }
}

const player = {
    x: 0,
    y: 0,
    radius: 12,
    isExhausted: false,
    speed: 2.3,
    runSpeed: 5.0,
    angle: 0,
    stamina: 100,
    maxStamina: 100,
    keys: 0,
    footstepTimer: 0,
    pitch: 0,
    z: 0 // Vertikale Position für Treppen
};

let fadeAlpha = 0; // Für Treppen-Animation

// --- STATIC TEXTURES ---
// --- PROCEDURAL GENERATION ---
function createRandomFloor() {
    let grid = Array(MAP_HEIGHT).fill(0).map(() => Array(MAP_WIDTH).fill('1'));
    const rooms = [];

    // Konstanten für Flure definieren (werden in addDoor benötigt)
    const mainHallX = Math.floor(MAP_WIDTH / 2);
    const crossHallY = Math.floor(MAP_HEIGHT / 2);

    const addRoom = (x, y, w, h, label) => {
        // Bestimme Wand-Typ basierend auf dem Raum-Label für unterschiedliche Optik
        let wallChar = '1';
        if (label === "Küche") wallChar = 'K';
        else if (label.startsWith("Schlafzimmer")) wallChar = 'S';
        else if (label === "Wohnzimmer") wallChar = 'W';
        else if (label === "Bad") wallChar = 'B';

        // Markiere die Wände um den Raum herum mit dem spezifischen Charakter
        for (let iy = y - 1; iy <= y + h; iy++) {
            for (let ix = x - 1; ix <= x + w; ix++) {
                if (iy >= 0 && iy < MAP_HEIGHT && ix >= 0 && ix < MAP_WIDTH) {
                    if (grid[iy][ix] === '1') grid[iy][ix] = wallChar;
                }
            }
        }

        for (let iy = y; iy < y + h; iy++) {
            for (let ix = x; ix < x + w; ix++) {
                if (iy >= 0 && iy < MAP_HEIGHT && ix >= 0 && ix < MAP_WIDTH) {
                    grid[iy][ix] = '0';
                }
            }
        }
        let roomObj = { x, y, w, h, centerX: Math.floor(x + w / 2), centerY: Math.floor(y + h / 2), label };
        rooms.push(roomObj);
        return roomObj;
    };

    const addDoor = (x, y) => {
        if (y >= 1 && y < MAP_HEIGHT - 1 && x >= 1 && x < MAP_WIDTH - 1) {
            // Bloß keine Türen in den großen Gängen (Hauptachsen)
            if (x === mainHallX || y === crossHallY) return;

            // Sicherstellen, dass die Tür in einem Engpass sitzt (Wände links/rechts oder oben/unten)
            const isW = c => '1KSWB'.includes(c);
            const hasWallHorizontal = (isW(grid[y][x - 1]) && isW(grid[y][x + 1]));
            const hasWallVertical = (isW(grid[y - 1][x]) && isW(grid[y + 1][x]));

            // Wenn es kein 1-Kachel-breiter Durchgang ist, ist es kein kleiner Gang
            if (!hasWallHorizontal && !hasWallVertical) return;

            // Verhindere Türen direkt nebeneinander (Prüfung im 3x3 Bereich)
            for (let dy = -1; dy <= 1; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    if (grid[y + dy][x + dx] === '2') return;
                }
            }
            grid[y][x] = '2';
        }
    };

    // 1. ZENTRALE HAUPTFLURE (1 Kachel breit)
    const mainHallYStart = 5;
    const mainHallYEnd = MAP_HEIGHT - 5;
    for (let y = mainHallYStart; y < mainHallYEnd; y++) {
        grid[y][mainHallX] = '0';
    }
    // Füge ein Raum-Objekt für den Hauptflur hinzu (für Spawn-Zwecke)
    rooms.push({ x: mainHallX, y: mainHallYStart, w: 1, h: mainHallYEnd - mainHallYStart, centerX: mainHallX, centerY: Math.floor(mainHallYStart + (mainHallYEnd - mainHallYStart) / 2), label: "Hauptflur" });

    const crossHallXStart = 5;
    const crossHallXEnd = MAP_WIDTH - 5;
    for (let x = crossHallXStart; x < crossHallXEnd; x++) {
        grid[crossHallY][x] = '0';
    }
    // Sicherstellen, dass die Kreuzung offen ist
    grid[crossHallY][mainHallX] = '0';

    // 2. HAUPTRÄUME (Kompakte Maße, direkt an die Flure angeschlossen)
    let roomX, roomY;

    // 2. HAUPTRÄUME (Kompakte Maße, mit Brückenkorridoren zum Flur)
    // Wohnzimmer
    roomX = mainHallX - 10 - Math.floor(Math.random() * 3);
    roomY = crossHallY - 4 + Math.floor(Math.random() * 4);
    addRoom(roomX, roomY, 5, 5, "Wohnzimmer");
    for (let x = roomX + 5; x < mainHallX; x++) grid[roomY + 2][x] = '0';
    addDoor(roomX + 5, roomY + 2); // Tür direkt am Zimmereingang

    // Küche
    roomX = mainHallX + 5 + Math.floor(Math.random() * 3);
    roomY = crossHallY - 4 + Math.floor(Math.random() * 4);
    addRoom(roomX, roomY, 4, 4, "Küche");
    for (let x = mainHallX + 1; x < roomX; x++) grid[roomY + 2][x] = '0';
    addDoor(roomX - 1, roomY + 2); // Tür direkt am Zimmereingang

    // Schlafzimmer 1
    roomX = mainHallX - 9 - Math.floor(Math.random() * 2);
    roomY = mainHallYStart + Math.floor(Math.random() * 3);
    addRoom(roomX, roomY, 4, 4, "Schlafzimmer 1");
    let s1ConnY = roomY + 2;
    for (let x = roomX + 4; x < mainHallX; x++) grid[s1ConnY][x] = '0';
    addDoor(roomX + 4, s1ConnY); // Tür direkt am Zimmereingang

    // Schlafzimmer 2
    roomX = mainHallX + 5 + Math.floor(Math.random() * 2);
    roomY = mainHallYStart + Math.floor(Math.random() * 3);
    addRoom(roomX, roomY, 4, 4, "Schlafzimmer 2");
    let s2ConnY = roomY + 2;
    for (let x = mainHallX + 1; x < roomX; x++) grid[s2ConnY][x] = '0';
    addDoor(roomX - 1, s2ConnY); // Tür direkt am Zimmereingang

    // Badezimmer
    roomX = crossHallXStart + Math.floor(Math.random() * 3);
    roomY = crossHallY + 5 + Math.floor(Math.random() * 2);
    addRoom(roomX, roomY, 3, 3, "Bad");
    let badConnY = crossHallY;
    for (let y = badConnY + 1; y < roomY; y++) grid[y][roomX + 1] = '0';
    addDoor(roomX + 1, roomY - 1); // Tür am Eingang des Bads

    // Vorratskammer / Abstellraum
    roomX = crossHallXEnd - 6 + Math.floor(Math.random() * 3);
    roomY = crossHallY + 5 + Math.floor(Math.random() * 2);
    addRoom(roomX, roomY, 3, 3, "Kammer");
    let kamConnY = crossHallY;
    for (let y = kamConnY + 1; y < roomY; y++) grid[y][roomX + 1] = '0';
    addDoor(roomX + 1, roomY - 1); // Tür am Eingang der Kammer

    // 3. ZUFÄLLIGE KLEINST-RÄUME (Kammern und Nischen, an die 1-Kachel-Flure andocken)
    const potentialConnectionPoints = [];
    // Entlang des vertikalen Hauptflurs mit Abstand (Step 4)
    for (let y = mainHallYStart + 2; y < mainHallYEnd - 2; y += 4) {
        if (grid[y][mainHallX] === '0') {
            if (grid[y][mainHallX - 1] === '1') potentialConnectionPoints.push({ x: mainHallX - 1, y: y, dir: 'left' });
            if (grid[y][mainHallX + 1] === '1') potentialConnectionPoints.push({ x: mainHallX + 1, y: y, dir: 'right' });
        }
    }
    // Entlang des horizontalen Querflurs mit Abstand (Step 4)
    for (let x = crossHallXStart + 2; x < crossHallXEnd - 2; x += 4) {
        if (grid[crossHallY][x] === '0') {
            if (grid[crossHallY - 1][x] === '1') potentialConnectionPoints.push({ x: x, y: crossHallY - 1, dir: 'up' });
            if (grid[crossHallY + 1][x] === '1') potentialConnectionPoints.push({ x: x, y: crossHallY + 1, dir: 'down' });
        }
    }

    for (let i = 0; i < 60; i++) { // Drastisch mehr Räume für eine riesige Map
        if (potentialConnectionPoints.length === 0) break;

        const connIdx = Math.floor(Math.random() * potentialConnectionPoints.length);
        const conn = potentialConnectionPoints.splice(connIdx, 1)[0]; // Punkt nach Verwendung entfernen

        let rw = 2 + Math.floor(Math.random() * 2); // 2-3 Kacheln
        let rh = 2 + Math.floor(Math.random() * 2); // 2-3 Kacheln
        let rx, ry;

        // Raum relativ zum Verbindungspunkt positionieren
        if (conn.dir === 'left') {
            rx = conn.x - rw;
            ry = conn.y - Math.floor(rh / 2);
        } else if (conn.dir === 'right') {
            rx = conn.x + 1;
            ry = conn.y - Math.floor(rh / 2);
        } else if (conn.dir === 'up') {
            rx = conn.x - Math.floor(rw / 2);
            ry = conn.y - rh;
        } else { // 'down'
            rx = conn.x - Math.floor(rw / 2);
            ry = conn.y + 1;
        }

        // Grundlegende Randprüfung
        if (rx > 1 && ry > 1 && rx + rw < MAP_WIDTH - 2 && ry + rh < MAP_HEIGHT - 2) {
            // Überlappungsprüfung mit bestehenden Räumen/Korridoren
            let overlap = false;
            for (let r of rooms) {
                // Puffer erhöht auf 2 Kacheln für sauberere Wände
                if (rx < r.x + r.w + 2 && rx + rw + 2 > r.x && ry < r.y + r.h + 2 && ry + rh + 2 > r.y) {
                    overlap = true;
                    break;
                }
            }

            if (!overlap) {
                let newRoom = addRoom(rx, ry, rw, rh, "Kammer");
                // Tür am Verbindungspunkt platzieren
                addDoor(conn.x, conn.y);

                // --- ANTI-SACKGASSEN-LOGIK (Loop-System) ---
                // Chance, eine Verbindung zu einem nahen Raum zu schaffen, wenn sie fast Wände teilen
                rooms.forEach(otherRoom => {
                    if (otherRoom === newRoom) return;

                    if (Math.random() < 0.6) { // Only attempt connection with 60% probability
                        let connected = false;

                        // Check for horizontal adjacency (newRoom left/right of otherRoom)
                        // Case 1: newRoom is to the right of otherRoom
                        if (newRoom.x === otherRoom.x + otherRoom.w + 1 || newRoom.x === otherRoom.x + otherRoom.w) { // Adjacent or 1 tile gap
                            let overlapYStart = Math.max(newRoom.y, otherRoom.y);
                            let overlapYEnd = Math.min(newRoom.y + newRoom.h, otherRoom.y + otherRoom.h);
                            if (overlapYEnd - overlapYStart >= 2) { // Need at least 2 tiles overlap for a door
                                let doorY = Math.floor(overlapYStart + (overlapYEnd - overlapYStart) / 2);
                                if (grid[doorY][newRoom.x - 1] === '1' && grid[doorY][newRoom.x] === '1') { // Ensure there's a wall to break
                                    grid[doorY][newRoom.x - 1] = '0'; // Break wall in otherRoom
                                    grid[doorY][newRoom.x] = '0'; // Break wall in newRoom
                                    addDoor(newRoom.x - 1, doorY);
                                    connected = true;
                                }
                            }
                        }
                        // Case 2: otherRoom is to the right of newRoom
                        else if (otherRoom.x === newRoom.x + newRoom.w + 1 || otherRoom.x === newRoom.x + newRoom.w) {
                            let overlapYStart = Math.max(newRoom.y, otherRoom.y);
                            let overlapYEnd = Math.min(newRoom.y + newRoom.h, otherRoom.y + otherRoom.h);
                            if (overlapYEnd - overlapYStart >= 2) {
                                let doorY = Math.floor(overlapYStart + (overlapYEnd - overlapYStart) / 2);
                                if (grid[doorY][otherRoom.x - 1] === '1' && grid[doorY][otherRoom.x] === '1') {
                                    grid[doorY][otherRoom.x - 1] = '0';
                                    grid[doorY][otherRoom.x] = '0';
                                    addDoor(otherRoom.x - 1, doorY);
                                    connected = true;
                                }
                            }
                        }

                        // Check for vertical adjacency (newRoom above/below otherRoom)
                        if (!connected) { // Only check vertical if not already connected horizontally
                            // Case 3: newRoom is below otherRoom
                            if (newRoom.y === otherRoom.y + otherRoom.h + 1 || newRoom.y === otherRoom.y + otherRoom.h) {
                                let overlapXStart = Math.max(newRoom.x, otherRoom.x);
                                let overlapXEnd = Math.min(newRoom.x + newRoom.w, otherRoom.x + otherRoom.w);
                                if (overlapXEnd - overlapXStart >= 2) {
                                    let doorX = Math.floor(overlapXStart + (overlapXEnd - overlapXStart) / 2);
                                    if (grid[newRoom.y - 1][doorX] === '1' && grid[newRoom.y][doorX] === '1') {
                                        grid[newRoom.y - 1][doorX] = '0';
                                        grid[newRoom.y][doorX] = '0';
                                        addDoor(doorX, newRoom.y - 1);
                                        connected = true;
                                    }
                                }
                            }
                            // Case 4: otherRoom is below newRoom
                            else if (otherRoom.y === newRoom.y + newRoom.h + 1 || otherRoom.y === newRoom.y + newRoom.h) {
                                let overlapXStart = Math.max(newRoom.x, otherRoom.x);
                                let overlapXEnd = Math.min(newRoom.x + newRoom.w, otherRoom.x + otherRoom.w);
                                if (overlapXEnd - overlapXStart >= 2) {
                                    let doorX = Math.floor(overlapXStart + (overlapXEnd - overlapXStart) / 2);
                                    if (grid[otherRoom.y - 1][doorX] === '1' && grid[otherRoom.y][doorX] === '1') {
                                        grid[otherRoom.y - 1][doorX] = '0';
                                        grid[otherRoom.y][doorX] = '0';
                                        addDoor(doorX, otherRoom.y - 1);
                                        connected = true;
                                    }
                                }
                            }
                        }
                    }
                });
            }
        }
    }

    return { grid: grid, rooms: rooms };
}

function initGameWorld() {
    maps = [];
    keysData = [];
    enemiesData = [];
    bloodSplattersData = [];
    doorsData = []; // doorsData bei jedem Start zurücksetzen
    torchesData = [];
    windowsData = [];

    // Reset Player Stats
    player.keys = 0;
    player.stamina = player.maxStamina;
    stairsCooldown = 0; // Sicherstellen, dass Treppen sofort benutzbar sind

    const settings = DIFFICULTY_SETTINGS[currentDifficulty];
    TOTAL_KEYS = settings.keys;
    const floorCount = settings.floors;

    for (let f = 0; f < floorCount; f++) {
        let gen = createRandomFloor();
        let grid = gen.grid;
        let rooms = gen.rooms;

        // Filtert Flure aus, damit Treppen und Startpunkte nur in "echten" Räumen landen
        let habitableRooms = rooms.filter(r => r.label !== "Hauptflur");

        if (f === 0) {
            let rStart = habitableRooms[0];
            player.x = rStart.centerX * TILE_SIZE;
            player.y = rStart.centerY * TILE_SIZE;
        }

        // Treppe nach oben (überall außer in der letzten Etage)
        if (f < floorCount - 1) {
            let rUp = habitableRooms[Math.floor(Math.random() * (habitableRooms.length - 2)) + 1];
            grid[rUp.y + Math.floor(Math.random() * rUp.h)][rUp.x + Math.floor(Math.random() * rUp.w)] = 'U';
        }

        // Treppe nach unten (überall außer in der ersten Etage)
        if (f > 0) {
            let rDown = habitableRooms[0];
            grid[rDown.y + Math.floor(Math.random() * rDown.h)][rDown.x + Math.floor(Math.random() * rDown.w)] = 'D';
        }

        // Ausgang (nur in der letzten Etage)
        if (f === floorCount - 1) {
            let rExit = habitableRooms[habitableRooms.length - 1];
            grid[rExit.centerY][rExit.centerX] = 'E';
        }

        let availableRooms = habitableRooms.slice(1, habitableRooms.length - 1);
        for (let i = availableRooms.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [availableRooms[i], availableRooms[j]] = [availableRooms[j], availableRooms[i]];
        }

        // Schlüssel gleichmäßig auf Etagen verteilen
        let numKeys = Math.ceil(TOTAL_KEYS / floorCount);
        if (f === floorCount - 1) numKeys = Math.max(1, TOTAL_KEYS - (numKeys * (floorCount - 1))); // Rest für letzte Etage (mindestens 1)

        let keysPlacedThisFloor = 0;
        // Mindestabstand zwischen Schlüsseln (ca. 18 Kacheln), um sie weit zu verteilen
        const MIN_KEY_DIST = TILE_SIZE * 18;

        for (let r of availableRooms) {
            if (keysPlacedThisFloor >= numKeys) break;

            let kx = r.centerX * TILE_SIZE;
            let ky = r.centerY * TILE_SIZE;

            // Prüfe Abstand zu bereits platzierten Schlüsseln auf DIESER Etage
            let tooClose = false;
            for (let i = keysData.length - keysPlacedThisFloor; i < keysData.length; i++) {
                let otherKey = keysData[i];
                if (Math.hypot(kx - otherKey.x, ky - otherKey.y) < MIN_KEY_DIST) {
                    tooClose = true;
                    break;
                }
            }

            if (!tooClose) {
                keysData.push({
                    x: kx + (Math.random() * 20 - 10),
                    y: ky + (Math.random() * 20 - 10),
                    floor: f,
                    collected: false
                });
                keysPlacedThisFloor++;
            }
        }

        // Fallback: Falls wegen des Abstands-Checks nicht genug Schlüssel platziert werden konnten
        if (keysPlacedThisFloor < numKeys) {
            for (let r of availableRooms) {
                if (keysPlacedThisFloor >= numKeys) break;
                let hasKey = keysData.some(k => k.floor === f && Math.abs(k.x - r.centerX * TILE_SIZE) < 10);
                if (!hasKey) {
                    keysData.push({ x: r.centerX * TILE_SIZE, y: r.centerY * TILE_SIZE, floor: f, collected: false });
                    keysPlacedThisFloor++;
                }
            }
        }

        let numEnemies = Math.round(settings.enemiesPerFloor);
        for (let e = 0; e < numEnemies; e++) {
            // Wähle einen zufälligen Raum, aber vermeide den Start- und Zielraum jeder Etage
            let r = null;
            let attempts = 0;
            const MIN_DIST = TILE_SIZE * 10; // Erhöht auf 10 Kacheln Sicherheitsabstand
            const spawnX = habitableRooms[0].centerX * TILE_SIZE;
            const spawnY = habitableRooms[0].centerY * TILE_SIZE;

            while (attempts < 100) { // Versuche, einen geeigneten Raum zu finden
                // Wähle einen zufälligen Raum, der nicht der Startraum ist
                let roomIdx = Math.floor(Math.random() * habitableRooms.length);
                let potentialRoom = habitableRooms[roomIdx];

                // Vermeide den Startraum des Spielers
                if (potentialRoom === habitableRooms[0]) {
                    attempts++;
                    continue;
                }

                let dist = Math.hypot(potentialRoom.centerX * TILE_SIZE - player.x, potentialRoom.centerY * TILE_SIZE - player.y);

                // Prüfe den Mindestabstand zum Spieler
                if (dist >= MIN_DIST) {
                    r = potentialRoom;
                    break;
                }
                attempts++;
            }
            // Fallback: Wenn nach vielen Versuchen kein geeigneter Raum gefunden wurde, nimm einen zufälligen, der nicht der Startraum ist.
            if (!r) {
                r = habitableRooms[Math.floor(Math.random() * habitableRooms.length)];
                if (r === habitableRooms[0] && habitableRooms.length > 1) r = habitableRooms[1]; // Nimm den nächsten, wenn es der Startraum ist
            }

            enemiesData.push({
                x: r.centerX * TILE_SIZE,
                y: r.centerY * TILE_SIZE,
                floor: f,
                baseSpeed: settings.speed + (f * 0.3),
                radius: 26 + f * 2, // Größer = bedrohlichere Erscheinung

                state: 'patrol',
                targetX: 0,
                targetY: 0,
                chaseTime: 0,
                wanderAngle: Math.random() * Math.PI * 2,
                lastKnownX: r.centerX * TILE_SIZE,
                lastKnownY: r.centerY * TILE_SIZE,
                chaseSoundTimer: 0
            });
        }

        // Türen für diese Etage in doorsData aufnehmen
        for (let y = 0; y < MAP_HEIGHT; y++) {
            for (let x = 0; x < MAP_WIDTH; x++) {
                if (grid[y][x] === '2') {
                    doorsData.push({ x: x, y: y, floor: f, state: 'closed', timer: 0 });
                }
            }
        }

        // Generate Torches
        for (let y = 1; y < MAP_HEIGHT - 1; y++) {
            for (let x = 1; x < MAP_WIDTH - 1; x++) {
                if (grid[y][x] === '1') {
                    let floorAdjacent = 0;
                    if (grid[y + 1][x] === '0') floorAdjacent++;
                    if (grid[y - 1][x] === '0') floorAdjacent++;
                    if (grid[y][x + 1] === '0') floorAdjacent++;
                    if (grid[y][x - 1] === '0') floorAdjacent++;

                    if (floorAdjacent > 0) {
                        if (Math.random() < 0.04) {
                            torchesData.push({
                                x: x * TILE_SIZE + TILE_SIZE / 2,
                                y: y * TILE_SIZE + TILE_SIZE / 2,
                                floor: f,
                                flickerCounter: Math.random() * 100
                            });
                        } else if (Math.random() < 0.008) {
                            // Only make it a window if it's not a torch
                            windowsData.push({
                                x: x,
                                y: y,
                                floor: f
                            });
                        }
                    }
                }
            }
        }

        maps[f] = grid;
    }

    currentFloor = 0;
    map = maps[currentFloor];

    // Initialisiere Fog of War für jede Etage
    exploredTiles = [];
    for (let f = 0; f < maps.length; f++) {
        exploredTiles.push(new Set());
    }

    updateMessage(); // Sofortige Aktualisierung der UI
}

let mouse = { x: (canvas ? canvas.width : 800) / 2, y: (canvas ? canvas.height : 600) / 2 };
let keysPressed = {};
let gameState = 'start';
let stairsCooldown = 0;

// Treppen-Zustand: nach einmaligem E-Druck klettert der Spieler automatisch
let stairAnim = { active: false, dir: 0, stepTimer: 0 };
// Edge-getriggerte Interaktionstaste (true nur für den Frame des Tastendrucks)
let interactPressed = false;

let jumpscareEffect = {
    active: false,
    timer: 0, // frames remaining for the effect
    maxTimer: 0, // total duration of the effect
    currentRedIntensity: 0 // 0 = no red, 1 = full red
};

// Schwierigkeits-Auswahl vor dem Start (Optional: Man könnte Buttons im HTML dafür haben)
// Hier setzen wir es beispielhaft über die URL oder einfach vor dem init:
function setDifficulty(level) {
    if (DIFFICULTY_SETTINGS[level]) {
        currentDifficulty = level;
        initGameWorld();
        const descEl = document.getElementById('difficulty-desc');
        if (descEl) {
            descEl.textContent = DIFFICULTY_SETTINGS[level].desc;

            // Animation neu triggern (durch Entfernen und Hinzufügen der Klasse)
            descEl.classList.remove('flicker-effect');
            void descEl.offsetWidth; // Force Reflow
            descEl.classList.add('flicker-effect');
        }
        const statsEl = document.getElementById('difficulty-stats');
        if (statsEl) {
            const s = DIFFICULTY_SETTINGS[level];
            const totalMonsters = s.floors * Math.round(s.enemiesPerFloor);
            statsEl.textContent = `Etagen: ${s.floors} | Monster: ${totalMonsters}`;
            statsEl.classList.remove('flicker-effect');
            void statsEl.offsetWidth;
            statsEl.classList.add('flicker-effect');
        }
    }
}

function spawnBloodSplatterNear(monster) {
    // Nur mit geringer Wahrscheinlichkeit spawnen (ca. alle 1-2 Sekunden während der Jagd)
    if (Math.random() > 0.02) return;

    const gx = Math.floor(monster.x / TILE_SIZE);
    const gy = Math.floor(monster.y / TILE_SIZE);

    // Prüfe die 4 Nachbarzellen auf Wände
    const directions = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }];
    for (let d of directions) {
        let nx = gx + d.x;
        let ny = gy + d.y;

        if (map[ny] && '1KSWB'.includes(map[ny][nx])) {
            bloodSplattersData.push({
                x: monster.x + d.x * (monster.radius + 2),
                y: monster.y + d.y * (monster.radius + 2),
                z: (Math.random() - 0.5) * TILE_SIZE * 0.5, // Zufällige Höhe an der Wand
                floor: monster.floor,
                size: 15 + Math.random() * 25,
                opacity: 0.8,
                timer: 1200 + Math.random() * 600 // Hält ca. 20-30 Sekunden
            });
            break; // Nur einen Spritzer pro Check
        }
    }
}

// Standard-Initialisierung
initGameWorld();

// Sound-Samples sofort im Hintergrund laden (während der Spieler noch im Menü ist)
loadSoundBank();

// Event-Listener für die Schwierigkeits-Buttons
document.querySelectorAll('.diff-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const level = btn.getAttribute('data-level');
        setDifficulty(level);
        document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Optional: Kurzes Feedback
        console.log(`Difficulty set to ${level}.`);
    });
});

const startBtn = document.getElementById('start-btn');
if (startBtn) {
    startBtn.addEventListener('click', () => {
        canvas.requestPointerLock();
        // Hide start screen content, show warning
        document.getElementById('start-content').classList.add('hidden');
        const statsEl = document.getElementById('difficulty-stats');
        if (statsEl) statsEl.classList.add('hidden');
        
        let warningContent = document.getElementById('warning-content');
        if (warningContent) {
            warningContent.classList.remove('hidden');
            warningContent.classList.add('flicker-effect');
        }

        // 3 Sekunden Warnung anzeigen, dann den Ladebalken starten
        setTimeout(async () => {
            if (warningContent) warningContent.classList.add('hidden');

            let loadingContent = document.getElementById('loading-content');
            loadingContent.classList.remove('hidden');
            loadingContent.classList.add('fade-in');

            // Echtzeit-Laden der Texturen
            let loadingBar = document.getElementById('loading-bar');
            let loadingText = document.querySelector('#loading-content p');

            // Erst auf die Web-Texturen warten (max. 8s, sonst prozeduraler Fallback)
            loadingText.textContent = "downloading textures...";
            await Promise.race([texturesReady, new Promise(resolve => setTimeout(resolve, 8500))]);

            // Sequentielles Laden für realistischen Ladebalken
            for (let i = 0; i < assetList.length; i++) {
                const asset = assetList[i];
                
                // Künstliche Verzögerung, damit man den Balken sieht (150-350ms pro Asset)
                await new Promise(resolve => setTimeout(resolve, 150 + Math.random() * 200));
                
                // Das tatsächliche Asset laden
                await extractPixels(asset.img, asset.setter);
                
                let progress = ((i + 1) / assetList.length) * 100;
                loadingBar.style.width = progress + '%';
                
                if (progress < 40) loadingText.textContent = "summoning demons...";
                else if (progress < 80) loadingText.textContent = "extracting textures...";
                else loadingText.textContent = "loading mechanics...";
            }

            // Kurzer Moment bei 100%
            await new Promise(resolve => setTimeout(resolve, 600));

            let screen = document.getElementById('start-screen');
            if (screen) {
                screen.style.transition = 'opacity 1s ease';
                screen.style.opacity = '0';
            }
            gameState = 'playing';
            gameRunStartTime = Date.now();
            startAmbientSound(); // Bedrohlicher Drone + Wind starten
            showHudMinimap();
            showFloorPopup(0);
            updateMessage();
            setTimeout(() => screen && screen.classList.add('hidden'), 1000);
        }, 3000);
    });
}

function updateMessage() {
    let msg = document.getElementById('message');
    let missing = TOTAL_KEYS - player.keys;
    msg.style.color = '#ffffff';
    msg.classList.remove('hidden');

    if (missing === 0) {
        msg.textContent = `Find the exit in the attic!`;
        msg.style.color = '#00ff00';
    } else {
        msg.textContent = `Find the keys! ${missing} remaining`;
    }
}
function showFloorPopup(floorIndex) {
    let names = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
    // Wenn es mehr als 5 Etagen gibt, generiere Namen dynamisch
    if (floorIndex === maps.length - 1) names[floorIndex] = "Attic";
    else if (!names[floorIndex]) names[floorIndex] = (floorIndex) + ". Floor";

    let popup = document.getElementById('floor-popup');
    popup.textContent = names[floorIndex];
    popup.classList.remove('hidden');
    popup.style.transition = 'none';
    popup.style.opacity = '1';

    void popup.offsetWidth;

    popup.style.transition = 'opacity 2s ease-out';
    popup.style.opacity = '0';

    setTimeout(() => {
        if (popup.style.opacity === '0') popup.classList.add('hidden');
    }, 2000);
}

let jumpscareFrame = 0;
let gameRunStartTime = 0;

function drawDeathMonster() {
    const dCanvas = document.getElementById('deathMonsterCanvas');
    if (!dCanvas) return;
    dCanvas.width = 600;
    dCanvas.height = 600;
    const dCtx = dCanvas.getContext('2d');

    // Pre-render static noise once
    const noiseCanvas = document.createElement('canvas');
    noiseCanvas.width = 600;
    noiseCanvas.height = 600;
    const noiseCtx = noiseCanvas.getContext('2d');
    for (let i = 0; i < 1000; i++) {
        noiseCtx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
        noiseCtx.fillRect(Math.random() * 600, Math.random() * 600, 2, 2);
    }

    // Haut-Textur einmalig vorrendern: Poren, Adern, Leichenflecken, Risse
    const skinTex = document.createElement('canvas');
    skinTex.width = 600; skinTex.height = 600;
    const sCtx = skinTex.getContext('2d');
    // Poren und Unebenheiten
    for (let i = 0; i < 9000; i++) {
        const px = Math.random() * 600, py = Math.random() * 600;
        sCtx.fillStyle = Math.random() > 0.5
            ? `rgba(0, 0, 0, ${Math.random() * 0.16})`
            : `rgba(220, 210, 190, ${Math.random() * 0.08})`;
        sCtx.fillRect(px, py, 1 + Math.random() * 1.5, 1 + Math.random() * 1.5);
    }
    // Leichenflecken (bläulich und bräunlich)
    for (let i = 0; i < 26; i++) {
        const px = Math.random() * 600, py = Math.random() * 600, r = 8 + Math.random() * 40;
        const g = sCtx.createRadialGradient(px, py, 0, px, py, r);
        const tone = Math.random() > 0.5 ? '70, 60, 80' : '60, 50, 40';
        g.addColorStop(0, `rgba(${tone}, ${0.10 + Math.random() * 0.15})`);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        sCtx.fillStyle = g;
        sCtx.beginPath(); sCtx.arc(px, py, r, 0, Math.PI * 2); sCtx.fill();
    }
    // Feine Adern unter der Haut
    sCtx.lineWidth = 1;
    for (let i = 0; i < 35; i++) {
        let vx = Math.random() * 600, vy = Math.random() * 600;
        sCtx.strokeStyle = `rgba(${Math.random() > 0.5 ? '90, 40, 50' : '50, 45, 70'}, ${0.12 + Math.random() * 0.12})`;
        sCtx.beginPath(); sCtx.moveTo(vx, vy);
        for (let s = 0; s < 7; s++) {
            vx += (Math.random() - 0.5) * 28;
            vy += (Math.random() - 0.5) * 28;
            sCtx.lineTo(vx, vy);
        }
        sCtx.stroke();
    }
    // Trockene Hautrisse
    sCtx.lineWidth = 0.7;
    for (let i = 0; i < 14; i++) {
        let vx = Math.random() * 600, vy = Math.random() * 600;
        sCtx.strokeStyle = `rgba(10, 5, 5, ${0.25 + Math.random() * 0.25})`;
        sCtx.beginPath(); sCtx.moveTo(vx, vy);
        for (let s = 0; s < 5; s++) {
            vx += (Math.random() - 0.5) * 16;
            vy += Math.random() * 22;
            sCtx.lineTo(vx, vy);
        }
        sCtx.stroke();
    }

    // Asymmetrische Schädelform (echte Gesichter sind nie symmetrisch)
    function traceSkullPath(c) {
        c.beginPath();
        c.moveTo(4, -290);
        c.bezierCurveTo(228, -276, 200, 70, 88, 218);
        c.quadraticCurveTo(-4, 286, -86, 212);
        c.bezierCurveTo(-212, 56, -218, -284, 4, -290);
        c.closePath();
    }

    function animateDeathMonster() {
        let cx = 300;
        let cy = 300;
        let time = Date.now() * 0.002;

        // Ruckartige Zuckungen wie beim Ingame-Monster
        const twitchSeed = Math.floor(Date.now() / 90);
        const twitchX = (noise2D(twitchSeed, 1.7) - 0.5) * 22;
        const twitchTilt = (noise2D(twitchSeed, 9.3) - 0.5) * 0.16;

        dCtx.fillStyle = '#000';
        dCtx.fillRect(0, 0, 600, 600);
        dCtx.drawImage(noiseCanvas, 0, 0); // Draw pre-rendered noise

        dCtx.save();
        dCtx.translate(cx + twitchX, cy + Math.cos(time * 0.8) * 6);
        dCtx.rotate(twitchTilt);

        // Roter Schein hinter dem Schädel
        dCtx.shadowBlur = 60;
        dCtx.shadowColor = 'rgba(255, 0, 0, 0.35)';

        // Länglicher, fahler Schädel mit schmalem Kinn
        const skull = dCtx.createRadialGradient(-40, -120, 20, 0, -40, 320);
        skull.addColorStop(0, '#8f8478');
        skull.addColorStop(0.6, '#574d42');
        skull.addColorStop(1, '#181410');
        dCtx.fillStyle = skull;
        traceSkullPath(dCtx);
        dCtx.fill();
        dCtx.shadowBlur = 0;

        // Haut-Textur und Beleuchtung in die Schädelform clippen
        dCtx.save();
        traceSkullPath(dCtx);
        dCtx.clip();

        dCtx.globalAlpha = 0.85;
        dCtx.drawImage(skinTex, -300, -340);
        dCtx.globalAlpha = 1;

        // Licht fällt von oben ein (wie von der Taschenlampe), unten Ambient Occlusion
        const topLight = dCtx.createLinearGradient(0, -300, 0, 290);
        topLight.addColorStop(0, 'rgba(235, 225, 205, 0.18)');
        topLight.addColorStop(0.35, 'rgba(0, 0, 0, 0)');
        topLight.addColorStop(1, 'rgba(0, 0, 0, 0.55)');
        dCtx.fillStyle = topLight;
        dCtx.fillRect(-300, -340, 600, 660);

        // Stirn-Highlight (feuchte, kranke Haut glänzt)
        const fHi = dCtx.createRadialGradient(-50, -190, 5, -50, -190, 120);
        fHi.addColorStop(0, 'rgba(255, 250, 235, 0.14)');
        fHi.addColorStop(1, 'rgba(0,0,0,0)');
        dCtx.fillStyle = fHi;
        dCtx.fillRect(-300, -340, 600, 660);

        // Wangenknochen fangen Licht
        for (let side = -1; side <= 1; side += 2) {
            const cHi = dCtx.createRadialGradient(side * 130, -10, 2, side * 130, -10, 55);
            cHi.addColorStop(0, 'rgba(230, 220, 200, 0.10)');
            cHi.addColorStop(1, 'rgba(0,0,0,0)');
            dCtx.fillStyle = cHi;
            dCtx.fillRect(-300, -340, 600, 660);
        }
        dCtx.restore();

        // Eingefallene Wangen
        dCtx.fillStyle = 'rgba(0,0,0,0.4)';
        dCtx.beginPath();
        dCtx.ellipse(-115, 60, 48, 80, 0.3, 0, Math.PI * 2);
        dCtx.ellipse(115, 60, 48, 80, -0.3, 0, Math.PI * 2);
        dCtx.fill();

        // Tiefe schwarze Augenhöhlen (leicht asymmetrisch — die rechte hängt tiefer)
        for (let side = -1; side <= 1; side += 2) {
            const sy = side < 0 ? -94 : -82;
            const sock = dCtx.createRadialGradient(side * 100, sy, 5, side * 100, sy, 85);
            sock.addColorStop(0, '#000');
            sock.addColorStop(0.8, '#030303');
            sock.addColorStop(1, 'rgba(3,3,3,0)');
            dCtx.fillStyle = sock;
            dCtx.beginPath();
            dCtx.ellipse(side * 100, sy, 72, 88, side * 0.15, 0, Math.PI * 2);
            dCtx.fill();
            // Knochenkante über der Höhle
            dCtx.strokeStyle = 'rgba(160, 145, 125, 0.18)';
            dCtx.lineWidth = 5;
            dCtx.beginPath();
            dCtx.arc(side * 100, sy - 8, 78, Math.PI * 1.15, Math.PI * 1.85);
            dCtx.stroke();
        }

        // Stechend rote Pupillen tief in den Höhlen (ungleich groß)
        let pulse = 12 + Math.sin(time * 5) * 4;
        dCtx.fillStyle = '#ff1500';
        dCtx.shadowBlur = pulse * 3;
        dCtx.shadowColor = '#ff0000';
        dCtx.beginPath(); dCtx.arc(-100, -88, pulse, 0, Math.PI * 2); dCtx.fill();
        dCtx.beginPath(); dCtx.arc(100, -74, pulse * 1.2, 0, Math.PI * 2); dCtx.fill();
        dCtx.shadowBlur = 0;
        // Dunkler Iris-Ring um die Pupillen
        dCtx.strokeStyle = 'rgba(120, 10, 0, 0.7)';
        dCtx.lineWidth = 2.5;
        dCtx.beginPath(); dCtx.arc(-100, -88, pulse + 4, 0, Math.PI * 2); dCtx.stroke();
        dCtx.beginPath(); dCtx.arc(100, -74, pulse * 1.2 + 4, 0, Math.PI * 2); dCtx.stroke();
        // Feuchter Glanzpunkt
        dCtx.fillStyle = 'rgba(255, 240, 230, 0.85)';
        dCtx.beginPath(); dCtx.arc(-104, -92, 2.4, 0, Math.PI * 2); dCtx.fill();
        dCtx.beginPath(); dCtx.arc(96, -78, 2.8, 0, Math.PI * 2); dCtx.fill();

        // Nasenschlitze
        dCtx.fillStyle = 'rgba(0,0,0,0.8)';
        dCtx.beginPath();
        dCtx.ellipse(-14, 35, 9, 22, 0.15, 0, Math.PI * 2);
        dCtx.ellipse(14, 35, 9, 22, -0.15, 0, Math.PI * 2);
        dCtx.fill();

        // Ausgerenkter, klaffender Kiefer mit dunklem Rachen (zittert)
        const jawDrop = 150 + Math.sin(time * 9) * 12;
        const throat = dCtx.createRadialGradient(0, 160 + jawDrop * 0.35, 10, 0, 160 + jawDrop * 0.35, jawDrop);
        throat.addColorStop(0, '#000');
        throat.addColorStop(0.7, '#0a0303');
        throat.addColorStop(1, '#1c0606');
        dCtx.fillStyle = throat;
        dCtx.beginPath();
        dCtx.ellipse(0, 160 + jawDrop * 0.35, 95, jawDrop, 0, 0, Math.PI * 2);
        dCtx.fill();

        // Zahnfleisch-Kante oben
        dCtx.fillStyle = '#2a0d0d';
        dCtx.fillRect(-95, 160 - jawDrop * 0.5 - 8, 190, 10);

        // Schiefe Zähne: dunkle Wurzel, helle Spitze, manche blutig, feuchter Glanz
        for (let tooth = -5; tooth <= 5; tooth++) {
            if (tooth === 0) continue;
            const tx = tooth * 17 + noise2D(tooth, 2.2) * 5;
            const tLen = 28 + Math.abs(noise2D(tooth, 5.5)) * 30;
            const lean = (noise2D(tooth, 7.7) - 0.5) * 8;
            const topY = 160 - jawDrop * 0.5;
            const botY = 160 + jawDrop * 1.28;

            const tg = dCtx.createLinearGradient(0, topY, 0, topY + tLen);
            tg.addColorStop(0, '#6e5a45');
            tg.addColorStop(0.35, '#cfc5a8');
            tg.addColorStop(1, tooth % 4 === 0 ? '#7a1212' : '#e8dfc2');
            dCtx.fillStyle = tg;
            dCtx.beginPath();
            dCtx.moveTo(tx - 7, topY);
            dCtx.lineTo(tx + lean, topY + tLen);
            dCtx.lineTo(tx + 7, topY);
            dCtx.fill();

            const bg = dCtx.createLinearGradient(0, botY, 0, botY - tLen);
            bg.addColorStop(0, '#5e4c3a');
            bg.addColorStop(0.35, '#c4ba9e');
            bg.addColorStop(1, tooth % 3 === 0 ? '#6a0f0f' : '#ddd4b6');
            dCtx.fillStyle = bg;
            dCtx.beginPath();
            dCtx.moveTo(tx - 7, botY);
            dCtx.lineTo(tx - lean, botY - tLen);
            dCtx.lineTo(tx + 7, botY);
            dCtx.fill();

            // Feuchter Glanzstreifen auf dem Zahn
            dCtx.strokeStyle = 'rgba(255, 250, 235, 0.25)';
            dCtx.lineWidth = 1.5;
            dCtx.beginPath();
            dCtx.moveTo(tx - 3, topY + 4);
            dCtx.lineTo(tx + lean * 0.6 - 1, topY + tLen * 0.7);
            dCtx.stroke();
        }

        // Schwarzer Speichel
        dCtx.strokeStyle = 'rgba(15, 5, 5, 0.8)';
        dCtx.lineWidth = 5;
        for (let d = -1; d <= 1; d++) {
            const dx = d * 30;
            const dLen = 40 + Math.abs(noise2D(d, twitchSeed)) * 60;
            dCtx.beginPath();
            dCtx.moveTo(dx, 160 + jawDrop * 1.25);
            dCtx.quadraticCurveTo(dx + d * 8, 160 + jawDrop * 1.25 + dLen * 0.6, dx, 160 + jawDrop * 1.25 + dLen);
            dCtx.stroke();
        }

        dCtx.restore();

        // Rote Vignette über den Canvas
        let grad = dCtx.createRadialGradient(300, 300, 100, 300, 300, 350);
        grad.addColorStop(0, 'rgba(0,0,0,0)');
        grad.addColorStop(1, 'rgba(100,0,0,0.5)');
        dCtx.fillStyle = grad;
        dCtx.fillRect(0, 0, 600, 600);

        if (gameState === 'gameover') requestAnimationFrame(animateDeathMonster);
    }
    animateDeathMonster(); // Start the animation loop
}

function triggerJumpscare() {
    if (gameState === 'gameover') return;
    gameState = 'gameover';
    hideHudMinimap();

    if (document.pointerLockElement) document.exitPointerLock();
    document.getElementById('jumpscare').classList.remove('hidden');

    playJumpscareScream();

    jumpscareFrame = 0;
    let splatters = [];

    const jsCanvas = document.getElementById('jumpscareCanvas');
    if (!jsCanvas) return;
    const jCtx = jsCanvas.getContext('2d');

    // Setze die Größe nur einmalig fest, um Einfrieren zu verhindern
    jsCanvas.width = window.innerWidth;
    jsCanvas.height = window.innerHeight;

    function animate() {
        jumpscareFrame++;

        let cx = jsCanvas.width / 2;
        let cy = jsCanvas.height / 2;

        // Screen shake
        let shakeIntensity = jumpscareFrame * 1.5;
        let shakeX = (Math.random() - 0.5) * shakeIntensity;
        let shakeY = (Math.random() - 0.5) * shakeIntensity;

        // Scale factor (rushes forward)
        let scale = 1 + (jumpscareFrame * 0.04);
        if (scale > 3.5) scale = 3.5;

        jCtx.fillStyle = '#000';
        jCtx.fillRect(0, 0, jsCanvas.width, jsCanvas.height);

        jCtx.save();
        jCtx.translate(cx + shakeX, cy + shakeY);
        jCtx.scale(scale, scale);

        // Face base
        jCtx.fillStyle = '#e6e6e6';
        jCtx.beginPath();
        jCtx.ellipse(0, -50, 350, 450, 0, 0, Math.PI * 2);
        jCtx.fill();

        // Eyes
        jCtx.fillStyle = '#000';
        jCtx.beginPath();
        jCtx.ellipse(-150, -200, 80, 120, -0.2, 0, Math.PI * 2);
        jCtx.ellipse(150, -200, 80, 120, 0.2, 0, Math.PI * 2);
        jCtx.fill();

        // Glowing red pupils (grow over time)
        let pupilSize = 15 + (jumpscareFrame * 0.4);
        if (pupilSize > 40) pupilSize = 40;
        jCtx.fillStyle = '#ff0000';
        jCtx.shadowBlur = 40 + jumpscareFrame;
        jCtx.shadowColor = '#ff0000';
        jCtx.beginPath();
        jCtx.arc(-150, -200, pupilSize, 0, Math.PI * 2);
        jCtx.arc(150, -200, pupilSize, 0, Math.PI * 2);
        jCtx.fill();
        jCtx.shadowBlur = 0;

        // Mouth (opens wider over time)
        let mouthHeight = 180 + (jumpscareFrame * 2.5);
        if (mouthHeight > 320) mouthHeight = 320;
        jCtx.fillStyle = '#050000';
        jCtx.beginPath();
        jCtx.ellipse(0, 200, 250, mouthHeight, 0, 0, Math.PI * 2);
        jCtx.fill();

        // Teeth
        jCtx.fillStyle = '#800000';
        for (let i = 0; i < 16; i++) {
            jCtx.beginPath();
            jCtx.moveTo(-230 + i * 30, 200 - mouthHeight + 10);
            jCtx.lineTo(-215 + i * 30, 200 - mouthHeight + 80 + Math.random() * 30);
            jCtx.lineTo(-200 + i * 30, 200 - mouthHeight + 10);
            jCtx.fill();

            jCtx.beginPath();
            jCtx.moveTo(-230 + i * 30, 200 + mouthHeight - 10);
            jCtx.lineTo(-215 + i * 30, 200 + mouthHeight - 80 - Math.random() * 30);
            jCtx.lineTo(-200 + i * 30, 200 + mouthHeight - 10);
            jCtx.fill();
        }

        jCtx.restore();

        // Add new blood splatters progressively
        if (jumpscareFrame % 2 === 0) {
            for (let i = 0; i < 4; i++) {
                splatters.push({
                    x: Math.random() * jsCanvas.width,
                    y: Math.random() * jsCanvas.height,
                    r: Math.random() * 80 + 20
                });
            }
        }

        // Draw splatters
        jCtx.fillStyle = '#800000';
        splatters.forEach(s => {
            jCtx.beginPath();
            jCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
            jCtx.fill();
        });

        if (jumpscareFrame < 35) {
            requestAnimationFrame(animate);
        } else {
            document.getElementById('jumpscare').classList.add('hidden');
            document.getElementById('game-over').classList.remove('hidden');

            // Statistik des Versuchs anzeigen
            const statsEl = document.getElementById('death-stats');
            if (statsEl) {
                const survived = gameRunStartTime > 0 ? Math.floor((Date.now() - gameRunStartTime) / 1000) : 0;
                const mins = Math.floor(survived / 60);
                const secs = String(survived % 60).padStart(2, '0');
                const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
                let floorName = floorNames[currentFloor] || (currentFloor + ". Floor");
                if (maps.length > 0 && currentFloor === maps.length - 1) floorName = "Attic";
                statsEl.innerHTML =
                    `<div class="stat"><div class="stat-label">Keys</div><div class="stat-value">${player.keys} / ${TOTAL_KEYS}</div></div>` +
                    `<div class="stat"><div class="stat-label">Floor</div><div class="stat-value">${floorName}</div></div>` +
                    `<div class="stat"><div class="stat-label">Survived</div><div class="stat-value">${mins}:${secs}</div></div>`;
            }
            drawDeathMonster();
        }
    }

    requestAnimationFrame(animate);
}

setTimeout(updateMessage, 100);

window.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'f') {
        if (document.pointerLockElement === canvas) {
            document.exitPointerLock();
        } else {
            canvas.requestPointerLock();
        }
    }
    // Minimap Toggle mit 'M'
    if (e.key.toLowerCase() === 'm' && gameState === 'playing') {
        toggleMinimap();
    }
    // Interaktion (E) nur beim ersten Drücken auslösen, nicht bei Key-Repeat
    if (e.key.toLowerCase() === 'e' && !e.repeat) {
        interactPressed = true;
    }
    keysPressed[e.key.toLowerCase()] = true; if (e.key === 'Shift') keysPressed['shift'] = true;
});
window.addEventListener('keyup', (e) => { keysPressed[e.key.toLowerCase()] = false; if (e.key === 'Shift') keysPressed['shift'] = false; });
document.addEventListener('mousemove', (e) => {
    if (document.pointerLockElement === canvas && gameState === 'playing') {
        player.angle += (e.movementX || 0) * 0.004; // Erhöhte horizontale Sensitivität
        // Limit leicht angepasst für bessere Stabilität und POV-Gefühl
        player.pitch = Math.max(-0.75, Math.min(0.75, player.pitch - (e.movementY || 0) * 0.005)); // Erhöhte vertikale Sensitivität
    }
});

// Klick-Listener, um die Steuerung zu reaktivieren, falls sie verloren geht
canvas.addEventListener('click', () => {
    if (gameState === 'playing' && document.pointerLockElement !== canvas) {
        canvas.requestPointerLock();
    }
});

function castRay(ox, oy, angle, maxDist) {
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);
    let x = ox, y = oy;
    for (let i = 0; i < maxDist; i += 4) {
        x += dx * 4;
        y += dy * 4;
        const gx = Math.floor(x / TILE_SIZE);
        const gy = Math.floor(y / TILE_SIZE);
        if (gy >= 0 && gy < map.length && gx >= 0 && gx < map[0].length) {
            let t = map[gy][gx];
            if (t === '1' || t === '2' || t === '4' || t === '5' || 'KSWB'.includes(t)) {
                let bx = x, by = y;
                while (Math.floor(bx / TILE_SIZE) === gx && Math.floor(by / TILE_SIZE) === gy) {
                    bx -= dx;
                    by -= dy;
                }
                return { x: bx + dx * 30, y: by + dy * 30 };
            }
        } else {
            return { x, y };
        }
    }
    return { x, y };
}

function hasLineOfSight(x1, y1, x2, y2) {
    if (!map || !map.length) return false;
    const dist = Math.hypot(x2 - x1, y2 - y1);
    const angle = Math.atan2(y2 - y1, x2 - x1);
    let x = x1, y = y1;
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);
    for (let i = 0; i < dist; i += 5) {
        x += dx * 5;
        y += dy * 5;
        const gx = Math.floor(x / TILE_SIZE);
        const gy = Math.floor(y / TILE_SIZE);
        let t = map[gy] ? map[gy][gx] : null;
        // Monster können nicht durch Wände, Türen oder Treppenaufbauten sehen
        if ('12UDKSWB'.includes(t)) return false;
    }
    return true;
}

function handleCollision(entity) {
    const buffer = entity.radius;
    const gx = Math.floor(entity.x / TILE_SIZE);
    const gy = Math.floor(entity.y / TILE_SIZE);

    for (let y = gy - 1; y <= gy + 1; y++) {
        for (let x = gx - 1; x <= gx + 1; x++) {
            let t = map[y] ? map[y][x] : null;
            if (t === '1' || t === '2' || t === '4' || t === '5' || 'KSWB'.includes(t)) {
                const wallX = x * TILE_SIZE;
                const wallY = y * TILE_SIZE;

                const closestX = Math.max(wallX, Math.min(entity.x, wallX + TILE_SIZE));
                const closestY = Math.max(wallY, Math.min(entity.y, wallY + TILE_SIZE));

                const distanceX = entity.x - closestX;
                const distanceY = entity.y - closestY;
                const distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);

                if (distanceSquared < buffer * buffer) {
                    const distance = Math.sqrt(distanceSquared);
                    if (distance > 0) {
                        const overlap = buffer - distance;
                        entity.x += (distanceX / distance) * overlap;
                        entity.y += (distanceY / distance) * overlap;
                    }
                }
            }
        }
    }
}

function checkStairs() {
    // Laufende Treppen-Animation: klettert automatisch weiter (einmal E drücken genügt)
    if (stairAnim.active) {
        player.z += 1.5 * stairAnim.dir;
        fadeAlpha = Math.min(1, Math.abs(player.z) / (TILE_SIZE * 0.8));
        player.pitch = stairAnim.dir > 0 ? -0.1 : 0.1;

        // Schwere Schritte auf den Stufen
        stairAnim.stepTimer--;
        if (stairAnim.stepTimer <= 0) {
            playStairStep();
            stairAnim.stepTimer = 14;
        }

        if (Math.abs(player.z) >= TILE_SIZE) {
            // Etagenwechsel
            currentFloor += stairAnim.dir;
            map = maps[currentFloor];
            spawnAtTile(stairAnim.dir > 0 ? 'D' : 'U');
            player.z = 0;
            player.pitch = 0;
            stairAnim.active = false;
            showFloorPopup(currentFloor);
        }
        return;
    }

    const gx = Math.floor(player.x / TILE_SIZE);
    const gy = Math.floor(player.y / TILE_SIZE);
    const tile = (maps[currentFloor] && maps[currentFloor][gy]) ? maps[currentFloor][gy][gx] : null;

    if ((tile === 'U' || tile === 'D') && stairsCooldown === 0 && interactPressed) {
        let dir = 0;
        if (tile === 'U' && currentFloor < maps.length - 1) dir = 1;
        else if (tile === 'D' && currentFloor > 0) dir = -1;

        if (dir !== 0) {
            interactPressed = false; // Tastendruck konsumieren (öffnet nicht nebenbei eine Tür)
            player.x = gx * TILE_SIZE + TILE_SIZE / 2;
            player.y = gy * TILE_SIZE + TILE_SIZE / 2;
            stairAnim.active = true;
            stairAnim.dir = dir;
            stairAnim.stepTimer = 0;
        }
    } else {
        // Sanftes Zurücksetzen der Z-Position, wenn nicht auf Treppe
        player.z *= 0.8;
        fadeAlpha *= 0.8;
        if (Math.abs(player.z) < 0.1) player.z = 0;
    }
}

function spawnAtTile(targetTile) {
    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] === targetTile) {
                player.x = x * TILE_SIZE + TILE_SIZE / 2;
                player.y = y * TILE_SIZE + TILE_SIZE / 2;
                stairsCooldown = 60;
                return;
            }
        }
    }
    // Fallback: Sollte die Ziel-Treppe fehlen, auf der ersten freien Bodenkachel
    // spawnen, damit der Spieler niemals im Nichts oder in einer Wand landet
    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] === '0') {
                player.x = x * TILE_SIZE + TILE_SIZE / 2;
                player.y = y * TILE_SIZE + TILE_SIZE / 2;
                stairsCooldown = 60;
                return;
            }
        }
    }
}

function update() {
    if (gameState !== 'playing') return;

    // --- EXPLORATION TRACKING ---
    updateExploration();
    // --- TASCHENLAMPEN-FLACKERN ---
    if (!window._flashlightFlicker) window._flashlightFlicker = 1.0;
    if (!window._blackoutTimer) window._blackoutTimer = 0;

    if (window._blackoutTimer > 0) {
        // Seltener Total-Ausfall der Taschenlampe: fast völlige Dunkelheit
        window._blackoutTimer--;
        window._flashlightFlicker = 0.08 + Math.random() * 0.1;
    } else if (Math.random() < 0.0006) {
        window._blackoutTimer = 25 + Math.floor(Math.random() * 50);
    } else if (Math.random() < 0.03) {
        window._flashlightFlicker = 0.7 + Math.random() * 0.2; // kurzer Einbruch
    } else {
        window._flashlightFlicker += (1.0 - window._flashlightFlicker) * 0.15; // sanft zurück zu 1.0
    }
    window._flashlightFlicker = Math.min(1.0, window._flashlightFlicker + (Math.random() - 0.5) * 0.02);

    // --- DONNER & BLITZ SYSTEM ---
    if (thunderState.timer > 0) {
        thunderState.timer--;
        thunderState.intensity *= 0.88; // Schneller Abfall des Blitzes
    } else {
        thunderState.active = false;
        thunderState.intensity = 0;
    }
    thunderState.nextThunder--;
    if (thunderState.nextThunder <= 0) {
        thunderState.active = true;
        thunderState.intensity = 0.6 + Math.random() * 0.4;
        thunderState.timer = 8 + Math.floor(Math.random() * 12); // 8-20 Frames
        thunderState.nextThunder = 400 + Math.floor(Math.random() * 1200); // 7-27 Sekunden bis zum nächsten
        playThunderSound();
    }

    // --- RANDOM AMBIENT STINGS ---
    stingTimer--;
    if (stingTimer <= 0) {
        playScarySting();
        stingTimer = 600 + Math.random() * 1800; // Alle 10-40 Sekunden
    }

    // Blutspritzer altern, verblassen und entfernen
    for (let i = bloodSplattersData.length - 1; i >= 0; i--) {
        let b = bloodSplattersData[i];
        b.timer--;
        if (b.timer < 150) b.opacity = b.timer / 150;
        if (b.timer <= 0) bloodSplattersData.splice(i, 1);
    }

    // Update jumpscare effect
    if (jumpscareEffect.active) {
        jumpscareEffect.timer--;

        const progress = 1 - (jumpscareEffect.timer / jumpscareEffect.maxTimer); // 0 to 1
        // Use sine wave to smoothly ramp up and down
        const effectPhase = Math.sin(progress * Math.PI); // Peaks at 0.5, goes from 0 to 1 to 0

        // Red intensity in and then out (max 0.6 opacity)
        jumpscareEffect.currentRedIntensity = 0.6 * effectPhase;

        if (jumpscareEffect.timer <= 0) {
            jumpscareEffect.active = false;
            jumpscareEffect.currentRedIntensity = 0;
        }
    }

    const DOOR_OPEN_TIME = 180; // 3 Sekunden bei 60 FPS
    const DOOR_INTERACTION_DISTANCE = TILE_SIZE * 1.5; // Spieler muss innerhalb von 1.5 Kacheln sein

    let interactionPromptMessage = null; // Speichert die Nachricht für den Interaktions-Prompt
    let currentFloorDoors = doorsData.filter(d => d.floor === currentFloor);

    // --- 1. TREPPEN-CHECK (Priorität vor Türen) ---
    const pgx = Math.floor(player.x / TILE_SIZE);
    const pgy = Math.floor(player.y / TILE_SIZE);
    const currentTile = (map[pgy] && map[pgy][pgx]) ? map[pgy][pgx] : null;
    const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];

    if ((currentTile === 'U' || currentTile === 'D') && stairsCooldown === 0 && !stairAnim.active) {
        if (currentTile === 'U') {
            let nextFloorName = currentFloor + 1 === maps.length - 1 ? "Attic" : (currentFloor + 1) + ". Floor";
            interactionPromptMessage = `press E: Climb to ${nextFloorName}`;
        } else {
            let nextFloorName = currentFloor - 1 === 0 ? "Ground Floor" : (currentFloor - 1) + ". Floor";
            interactionPromptMessage = `press E: Descend to ${nextFloorName}`;
        }
    }
    checkStairs();

    if (stairsCooldown > 0) stairsCooldown--; // Keep only one decrement per frame

    // --- 2. TÜR-INTERAKTION ---
    // Tür-Interaktion und -Zustand verwalten
    currentFloorDoors.forEach(door => {
        const doorCenterX = door.x * TILE_SIZE + TILE_SIZE / 2;
        const doorCenterY = door.y * TILE_SIZE + TILE_SIZE / 2;
        const distToDoor = Math.hypot(player.x - doorCenterX, player.y - doorCenterY);

        // Performance-Optimierung: Nur berechnen, wenn der Spieler oder ein Gegner in der Nähe ist
        if (distToDoor > TILE_SIZE * 5 && door.state === 'closed') return;

        // Prüfen, ob jemand in der Tür steht (Spieler oder Monster)
        const isBlocked = distToDoor < TILE_SIZE * 0.6 ||
            enemiesData.some(e => e.floor === door.floor &&
                Math.hypot(e.x - doorCenterX, e.y - doorCenterY) < TILE_SIZE * 0.6);

        if (door.state === 'closed') {
            if (distToDoor < DOOR_INTERACTION_DISTANCE) { // Spieler ist in Reichweite einer geschlossenen Tür
                let angleToDoor = Math.atan2(doorCenterY - player.y, doorCenterX - player.x);
                let angleDiff = Math.abs(Math.atan2(Math.sin(angleToDoor - player.angle), Math.cos(angleToDoor - player.angle)));
                if (angleDiff < Math.PI / 4) { // Prüfen ob Spieler die Tür ansieht (innerhalb von 45 Grad)
                    interactionPromptMessage = "press E to open";
                    if (interactPressed && !stairAnim.active) { // Manuelles Öffnen mit E (Einzeldruck)
                        door.state = 'open';
                        door.timer = DOOR_OPEN_TIME;
                        maps[door.floor][door.y][door.x] = '0'; // Tür in der richtigen Etage öffnen
                        interactPressed = false;
                        playDoorCreak();
                    }
                }
            }
        } else if (door.state === 'open') {
            if (door.timer > 0) {
                door.timer--;
            } else if (!isBlocked) { // Tür schließt nur, wenn niemand darin steht
                door.state = 'closed';
                maps[door.floor][door.y][door.x] = '2'; // Tür in der richtigen Etage schließen
            }
        }
    });

    // --- 3. PICKUP & EXIT ---
    updatePickupsAndExit();

    // --- 4. BEWEGUNG & KOLLISION ---

    // EMF-Reader Logik (Gefahrenmeter)
    let minEnemyDist = Infinity;
    enemiesData.forEach(e => {
        if (e.floor === currentFloor) {
            let d = Math.hypot(player.x - e.x, player.y - e.y);
            if (d < minEnemyDist) minEnemyDist = d;
        }
    });

    const emfSegments = document.getElementsByClassName('emf-segment');
    if (emfSegments.length > 0) { // EMF-Reader Logik (Gefahrenmeter)
        let emfIntensity = 0;
        if (minEnemyDist < 1000) { // Erkennungsradius 1000 Einheiten
            emfIntensity = 1 - Math.max(0, (minEnemyDist - 150) / 850);
            emfIntensity = Math.min(1, emfIntensity);
        }

        let activeSegments = Math.ceil(emfIntensity * 5);
        const colors = ['#00ff00', '#00ff00', '#ffff00', '#ffff00', '#ff0000'];
        for (let i = 0; i < 5; i++) {
            if (i < activeSegments) {
                emfSegments[i].style.backgroundColor = colors[i];
                emfSegments[i].style.boxShadow = `0 0 10px ${colors[i]}`;
            } else {
                emfSegments[i].style.backgroundColor = '#111';
                emfSegments[i].style.boxShadow = 'none';
            }
        }
    }

    // --- HERZSCHLAG bei Monsternähe (schneller, je näher es kommt) ---
    if (!window._heartbeatTimer) window._heartbeatTimer = 0;
    window._heartbeatTimer--;
    if (minEnemyDist < 400 && window._heartbeatTimer <= 0) {
        const proximity = 1 - minEnemyDist / 400;
        playHeartbeat(proximity);
        window._heartbeatTimer = 25 + (1 - proximity) * 50;
    }

    // Interaktions-Hinweis am unteren Bildschirmrand anzeigen
    const promptEl = document.getElementById('interaction-prompt');
    if (promptEl && interactionPromptMessage) {
        promptEl.textContent = interactionPromptMessage;
        promptEl.classList.remove('hidden');
    } else if (promptEl) {
        promptEl.classList.add('hidden');
    }

    let speed = player.speed;
    let isMoving = keysPressed['w'] || keysPressed['a'] || keysPressed['s'] || keysPressed['d'];

    // Stamina-Logik: Verhindert "Stottern" bei leerer Ausdauer
    if (keysPressed['shift'] && isMoving && player.stamina > 0 && !player.isExhausted) {
        speed = player.runSpeed;
        player.stamina = Math.max(0, player.stamina - 0.8);
        player.footstepTimer -= 2.5;
        if (player.stamina <= 0) player.isExhausted = true;
    } else {
        player.stamina = Math.min(player.maxStamina, player.stamina + 0.4);
        if (isMoving) player.footstepTimer -= 1.5;
        if (player.stamina >= player.maxStamina) player.isExhausted = false; // Erst wieder rennen, wenn voll regeneriert
    }

    if (isMoving && player.footstepTimer <= 0) {
        playFootstepSound();
        player.footstepTimer = 25;
    }

    const staminaBarFill = document.getElementById('stamina-bar-fill');
    const staminaText = document.getElementById('stamina-percentage-text');

    if (staminaBarFill) {
        let staminaPercent = (player.stamina / player.maxStamina * 100);
        staminaBarFill.style.width = staminaPercent + '%';

        if (staminaText) {
            staminaText.textContent = `Stamina: ${Math.round(staminaPercent)}%`;
        }

        if (player.isExhausted) {
            staminaBarFill.style.backgroundColor = '#ff0000'; // Rot bei Erschöpfung
            staminaBarFill.style.boxShadow = '0 0 15px #ff0000';
            staminaBarFill.style.animation = 'pulseRed 1s infinite alternate';

            // Schweres Keuchen, solange man erschöpft ist
            window._breathTimer = (window._breathTimer || 0) - 1;
            if (window._breathTimer <= 0) {
                playExhaustedBreath();
                window._breathTimer = 45;
            }
        } else {
            staminaBarFill.style.animation = 'none';
            if (staminaPercent > 70) {
                staminaBarFill.style.backgroundColor = '#ffffff'; // Voll
            } else if (staminaPercent > 30) {
                staminaBarFill.style.backgroundColor = '#ffff00'; // Mittel
            } else {
                staminaBarFill.style.backgroundColor = '#ffa500'; // Niedrig
            }
            staminaBarFill.style.boxShadow = '0 0 5px ' + staminaBarFill.style.backgroundColor;
        }
    }

    // Only allow horizontal movement if not actively climbing/descending stairs
    // A small threshold for player.z is used to allow slight z-movement without blocking horizontal movement
    if (Math.abs(player.z) < 1 && !stairAnim.active) {
        let moveX = 0; let moveY = 0;
        if (keysPressed['w']) { moveX += Math.cos(player.angle) * speed; moveY += Math.sin(player.angle) * speed; }
        if (keysPressed['s']) { moveX -= Math.cos(player.angle) * speed; moveY -= Math.sin(player.angle) * speed; }
        if (keysPressed['a']) { moveX += Math.cos(player.angle - Math.PI / 2) * speed; moveY += Math.sin(player.angle - Math.PI / 2) * speed; }
        if (keysPressed['d']) { moveX += Math.cos(player.angle + Math.PI / 2) * speed; moveY += Math.sin(player.angle + Math.PI / 2) * speed; }

        if (moveX !== 0 || moveY !== 0) { // Check if there's any movement
            const length = Math.sqrt(moveX * moveX + moveY * moveY);
            moveX = (moveX / length) * speed;
            moveY = (moveY / length) * speed;
        }

        player.x += moveX;
        player.y += moveY;
        handleCollision(player);
    } else {
        // If climbing, still handle collision for the current stair tile to prevent going through walls
        handleCollision(player);
    }

    keysData.forEach(k => {
        if (!k.collected && k.floor === currentFloor && Math.hypot(player.x - k.x, player.y - k.y) < player.radius + 20) {
            k.collected = true;
            player.keys++;
            playKeyPickup();
            updateMessage();
        }
    });

    if (player.keys >= TOTAL_KEYS && currentFloor === maps.length - 1) {
        if (map[pgy] && (map[pgy][pgx] === 'E' || map[pgy][pgx] === '0')) {
            const distToExit = Math.hypot(player.x - (pgx * TILE_SIZE + 30), player.y - (pgy * TILE_SIZE + 30));
            if (distToExit < 40 && map[pgy][pgx] === 'E') {
                gameState = 'victory';
                hideHudMinimap();
                if (document.pointerLockElement) document.exitPointerLock();
                document.getElementById('victory').classList.remove('hidden');
            }
        }
    }

    enemiesData.forEach(e => {
        const settings = DIFFICULTY_SETTINGS[currentDifficulty];
        if (e.floor !== currentFloor) return;

        // Wenn das Monster aktiv ist, hinterlässt es Spuren
        if (e.state === 'chase' || e.state === 'search') {
            spawnBloodSplatterNear(e);
        }

        // Gegner öffnet Türen jetzt über das neue doorsData System
        const egx = Math.floor(e.x / TILE_SIZE);
        const egy = Math.floor(e.y / TILE_SIZE);

        for (let i = 0; i < currentFloorDoors.length; i++) {
            let door = currentFloorDoors[i];
            if (door.state === 'closed' && Math.abs(door.x - egx) <= 1 && Math.abs(door.y - egy) <= 1) {
                door.state = 'open';
                door.timer = 180;
                maps[door.floor][door.y][door.x] = '0';
                // Unheimlich: man hört das Monster irgendwo eine Tür öffnen
                if (door.floor === currentFloor) playDoorCreak();
            }
        }

        const distToPlayer = Math.hypot(player.x - e.x, player.y - e.y);

        // --- ENTFERNTES KNURREN: Man hört das Monster leise durch das Haus ---
        // Lautstärke nach Distanz, Stereo-Panning nach Richtung, Tiefpass dämpft Ferne
        if (e.idleSoundTimer === undefined) e.idleSoundTimer = 300 + Math.random() * 600;
        e.idleSoundTimer--;
        if (e.idleSoundTimer <= 0) {
            if (e.state !== 'chase' && distToPlayer < 1600) {
                const closeness = 1 - distToPlayer / 1600;
                const relAngle = Math.atan2(e.y - player.y, e.x - player.x) - player.angle;
                playMonsterGrowl(0.06 + Math.pow(closeness, 1.5) * 0.45, {
                    pan: Math.sin(relAngle),
                    lowpass: 500 + closeness * 2500,
                    wet: 0.85 // viel Hall: klingt weit weg im Gebäude
                });
            }
            e.idleSoundTimer = 360 + Math.random() * 540; // alle 6-15 Sekunden
        }

        let canSee = hasLineOfSight(e.x, e.y, player.x, player.y);

        // Sicherheitscheck für atan2 (vermeidet NaN bei identischer Position)
        let angleToPlayer = distToPlayer > 0.1 ? Math.atan2(player.y - e.y, player.x - e.x) : e.wanderAngle;
        let angleDiff = Math.abs(Math.atan2(Math.sin(e.wanderAngle - angleToPlayer), Math.cos(e.wanderAngle - angleToPlayer)));

        let inFOV = (angleDiff < Math.PI / 2.2);
        if (e.state === 'chase') inFOV = true;

        if (canSee && (distToPlayer < 100 || (distToPlayer < settings.visionRange && inFOV))) {
            e.state = 'chase';
            if (!jumpscareEffect.active) { // Trigger effect only if not already active
                jumpscareEffect.active = true;
                jumpscareEffect.timer = 90; // 1.5 seconds
                jumpscareEffect.maxTimer = 90;

                // Das Monster hat dich entdeckt: lautes Knurren
                playMonsterGrowl(1.0);
            }
            e.lastKnownX = player.x;
            e.lastKnownY = player.y;
        } else if (e.state === 'chase') {
            // Bei niedriger Intelligenz (Leicht) vergisst das Monster sofort
            if (settings.intelligence > 0) {
                e.state = 'search';
            } else {
                e.state = 'patrol';
            }
        } else if (e.state === 'search' && distToPlayer > settings.searchDist) {
            e.state = 'patrol';
        }

        let currentBaseSpeed = e.baseSpeed + (player.keys * 0.2);

        if (e.state === 'chase') {
            e.wanderAngle = angleToPlayer;
            e.chaseTime += 1 / 60;
            // Beschleunigung begrenzt: Das Monster wird schneller, aber nur bis zu einem fairen Maximum
            let activeSpeed = Math.min(currentBaseSpeed + (e.chaseTime * 0.3), currentBaseSpeed + 2);

            // Jagd-Sound Logik: Intervalle verkürzen sich, wenn das Monster näher kommt
            e.chaseSoundTimer--;
            if (e.chaseSoundTimer <= 0) {
                e.chaseSoundTimer = 20 + Math.floor(distToPlayer / 20); // Schneller bei Annäherung
                const chaseRelAngle = Math.atan2(e.y - player.y, e.x - player.x) - player.angle;
                playMonsterGrowl(Math.max(0.2, 1 - distToPlayer / 800), { pan: Math.sin(chaseRelAngle) });
            }

            e.x += Math.cos(angleToPlayer) * activeSpeed;
            e.y += Math.sin(angleToPlayer) * activeSpeed;

            if (distToPlayer < player.radius + e.radius) {
                triggerJumpscare();
            }
            handleCollision(e);
        } else if (e.state === 'search') {
            e.chaseTime = 0; // Beschleunigung zurücksetzen
            let distToLastKnown = Math.hypot(e.lastKnownX - e.x, e.lastKnownY - e.y);

            if (distToLastKnown > 10) {
                // Gehe zum Ort, an dem der Spieler zuletzt gesehen wurde
                let angleToPoint = Math.atan2(e.lastKnownY - e.y, e.lastKnownX - e.x);
                e.wanderAngle = angleToPoint;
                e.x += Math.cos(angleToPoint) * currentBaseSpeed;
                e.y += Math.sin(angleToPoint) * currentBaseSpeed;
                handleCollision(e);
            } else {
                // Am Ziel angekommen und nichts gefunden? Zurück zum Patrouillieren
                e.state = 'patrol';
            }
        } else {
            e.chaseTime = 0;

            if (Math.random() < 0.02) e.wanderAngle += (Math.random() - 0.5);

            let moveSpeed = currentBaseSpeed * 0.4;
            let prevX = e.x;
            let prevY = e.y;

            e.x += Math.cos(e.wanderAngle) * moveSpeed;
            e.y += Math.sin(e.wanderAngle) * moveSpeed;

            handleCollision(e);

            if (Math.hypot(e.x - prevX, e.y - prevY) < moveSpeed * 0.5) {
                e.wanderAngle += Math.PI / 2 + (Math.random() * Math.PI / 2);
            }
        }
    });
}

function updateSanity() {
    let currentSanityDrain = player.sanityDrainRate;
    let monsterProximityDrain = 0;

    enemiesData.forEach(e => {
        if (e.floor === currentFloor) {
            let d = Math.hypot(player.x - e.x, player.y - e.y);
            if (d < 500) monsterProximityDrain += (1 - d / 500) * 0.2;
            if (e.state === 'chase') monsterProximityDrain += 0.1;
        }
    });
    
    if (window._flashlightFlicker < 0.8) currentSanityDrain += 0.05;
    currentSanityDrain += monsterProximityDrain;

    if (monsterProximityDrain === 0 && !player.isHiding) {
        player.sanity = Math.min(player.maxSanity, player.sanity + player.sanityRegenRate);
    } else {
        player.sanity = Math.max(0, player.sanity - currentSanityDrain);
    }

    player.sanityEffectIntensity = 1 - (player.sanity / player.maxSanity);
    if (player.sanity <= 0 && gameState === 'playing') triggerJumpscare();
}

function updatePickupsAndExit() {
    const pgx = Math.floor(player.x / TILE_SIZE);
    const pgy = Math.floor(player.y / TILE_SIZE);

    keysData.forEach(k => {
        if (!k.collected && k.floor === currentFloor && Math.hypot(player.x - k.x, player.y - k.y) < player.radius + 20) {
            k.collected = true;
            player.keys++;
            playKeyPickup();
            updateMessage();
        }
    });

    if (player.keys >= TOTAL_KEYS && currentFloor === maps.length - 1) {
        if (map[pgy] && map[pgy][pgx] === 'E') {
            const distToExit = Math.hypot(player.x - (pgx * TILE_SIZE + 30), player.y - (pgy * TILE_SIZE + 30));
            if (distToExit < 40) {
                gameState = 'victory';
                if (document.pointerLockElement) document.exitPointerLock();
                document.getElementById('victory').classList.remove('hidden');
            }
        }
    }
}

function drawFirstPersonOverlay() {
    let isMoving = keysPressed['w'] || keysPressed['a'] || keysPressed['s'] || keysPressed['d'];
    let time = Date.now() / 1000;
    let shakeY = Math.sin(time * 6.5) * (isMoving ? 5 : 1.5);
    let shakeX = Math.cos(time * 3.3) * (isMoving ? 4 : 1);
    let flicker = window._flashlightFlicker || 1.0;

    // --- 1. Realistischer runder Lichtkegel (Vignette) ---
    // Der Lichtkegel bewegt sich synchron mit der Taschenlampe
    // Das Licht bleibt nun im Zentrum des Bildschirms (da wo man hinschaut)
    let gazeCenterY = canvas.height / 2 + shakeY * 1.5;
    let gazeCenterX = canvas.width / 2 + canvas.width * 0.02 + shakeX * 2.0;

    // Basis-Vignette (hartes Abfallen am Rand wie bei LED-Taschenlampen) - Jetzt deutlich dunkler außen
    let vig = ctx.createRadialGradient(gazeCenterX, gazeCenterY, canvas.height * 0.12, gazeCenterX, gazeCenterY, canvas.height * 0.75);
    vig.addColorStop(0, 'rgba(0,0,0,0)');
    vig.addColorStop(0.25, `rgba(0,0,0,${0.05 * flicker})`);
    vig.addColorStop(0.4, `rgba(0,0,0,${0.35 * flicker})`);
    vig.addColorStop(0.55, 'rgba(0,0,0,0.92)');
    vig.addColorStop(0.75, 'rgba(0,0,0,1)');
    vig.addColorStop(1, 'rgba(0,0,0,1)');
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Innerer LED-Ring (Hotspot)
    let hotSpot = ctx.createRadialGradient(gazeCenterX, gazeCenterY, 0, gazeCenterX, gazeCenterY, canvas.height * 0.25);
    hotSpot.addColorStop(0, `rgba(255, 250, 240, ${0.12 * flicker})`);
    hotSpot.addColorStop(0.7, `rgba(255, 245, 220, ${0.05 * flicker})`);
    hotSpot.addColorStop(0.8, `rgba(255, 240, 200, 0)`);
    ctx.fillStyle = hotSpot;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Streulicht-Ringe (Lens Flare / Reflektor-Artefakte)
    ctx.strokeStyle = `rgba(255, 250, 230, ${0.02 * flicker})`;
    ctx.lineWidth = canvas.height * 0.02;
    ctx.beginPath();
    ctx.arc(gazeCenterX, gazeCenterY, canvas.height * 0.45, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = `rgba(255, 245, 220, ${0.015 * flicker})`;
    ctx.lineWidth = canvas.height * 0.05;
    ctx.beginPath();

    ctx.globalAlpha = 1.0;

    // --- 2. Realistisches Taschenlampen-Modell ---
    ctx.save();

    let fx = canvas.width * 0.72 + shakeX;
    // Die Taschenlampe bewegt sich leicht vertikal mit dem Blickwinkel mit
    let fy = canvas.height + shakeY - 10 - (player.pitch * 40);

    ctx.translate(fx, fy);

    let modelScale = (canvas.height / 600) * 1.25;
    ctx.scale(modelScale, modelScale);

    // Die Taschenlampe neigt sich jetzt passend zur Blickrichtung (player.pitch)
    let tiltAngle = -0.12 + Math.sin(time * 1.5) * 0.008 - (player.pitch * 0.5); 
    ctx.rotate(tiltAngle);

    // --- Unterarm mit Ärmel ---
    let armGrad = ctx.createLinearGradient(40, 120, 130, 400);
    armGrad.addColorStop(0, '#1a3350');
    armGrad.addColorStop(0.5, '#152a42');
    armGrad.addColorStop(1, '#0f1e30');
    ctx.fillStyle = armGrad;
    ctx.beginPath();
    ctx.moveTo(15, 95);
    ctx.quadraticCurveTo(-10, 180, 80, 400);
    ctx.lineTo(155, 400);
    ctx.quadraticCurveTo(110, 200, 55, 95);
    ctx.closePath();
    ctx.fill();

    // Ärmel-Falten
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(25, 130); ctx.quadraticCurveTo(50, 145, 50, 130);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(30, 160); ctx.quadraticCurveTo(60, 170, 55, 155);
    ctx.stroke();

    // --- Hand (Hautfarbe mit Fingern) ---
    let skinGrad = ctx.createRadialGradient(30, 75, 5, 30, 75, 40);
    skinGrad.addColorStop(0, '#f5c9a0');
    skinGrad.addColorStop(1, '#d4a574');
    ctx.fillStyle = skinGrad;

    // Handfläche (hinter dem Griff)
    ctx.beginPath();
    ctx.ellipse(28, 78, 28, 22, -0.15, 0, Math.PI * 2);
    ctx.fill();

    // Finger um den Griff (4 Finger vorne sichtbar)
    ctx.fillStyle = '#e8b888';
    for (let f = 0; f < 4; f++) {
        let fingerY = 40 + f * 18;
        let fingerCurve = Math.sin(f * 0.7 + 0.3) * 3;
        ctx.beginPath();
        ctx.ellipse(-2 + fingerCurve, fingerY, 7, 9, -0.2, 0, Math.PI * 2);
        ctx.fill();
        // Knöchel-Detail
        ctx.strokeStyle = 'rgba(180, 140, 100, 0.4)';
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        ctx.arc(-2 + fingerCurve, fingerY - 2, 4, 0, Math.PI);
        ctx.stroke();
    }

    // Daumen (seitlich)
    ctx.fillStyle = '#e8b888';
    ctx.beginPath();
    ctx.ellipse(48, 55, 8, 14, 0.4, 0, Math.PI * 2);
    ctx.fill();

    // --- Taschenlampen-Griff (zylindrisch, metallisch) ---
    let handleGrad = ctx.createLinearGradient(0, 20, 42, 20);
    handleGrad.addColorStop(0, '#1a1a1a');
    handleGrad.addColorStop(0.2, '#333');
    handleGrad.addColorStop(0.4, '#2a2a2a');
    handleGrad.addColorStop(0.6, '#444');
    handleGrad.addColorStop(0.8, '#2a2a2a');
    handleGrad.addColorStop(1, '#111');
    ctx.fillStyle = handleGrad;

    // Gerundeter Griff
    ctx.beginPath();
    ctx.moveTo(3, 20);
    ctx.lineTo(3, 115);
    ctx.quadraticCurveTo(3, 125, 10, 125);
    ctx.lineTo(32, 125);
    ctx.quadraticCurveTo(39, 125, 39, 115);
    ctx.lineTo(39, 20);
    ctx.closePath();
    ctx.fill();

    // Gummi-Grip Rillen
    ctx.strokeStyle = 'rgba(80, 80, 80, 0.5)';
    ctx.lineWidth = 1.5;
    for (let gy = 35; gy < 115; gy += 6) {
        ctx.beginPath();
        ctx.moveTo(5, gy);
        ctx.lineTo(37, gy);
        ctx.stroke();
    }

    // Schalter (kleiner Knopf an der Seite)
    ctx.fillStyle = '#555';
    ctx.fillRect(39, 50, 5, 12);
    ctx.fillStyle = '#777';
    ctx.fillRect(40, 52, 3, 8);

    // --- Taschenlampen-Kopf (konisch, Reflektor) ---
    let headGrad = ctx.createLinearGradient(-15, -50, 55, -50);
    headGrad.addColorStop(0, '#0d0d0d');
    headGrad.addColorStop(0.3, '#2a2a2a');
    headGrad.addColorStop(0.5, '#333');
    headGrad.addColorStop(0.7, '#2a2a2a');
    headGrad.addColorStop(1, '#0d0d0d');
    ctx.fillStyle = headGrad;
    ctx.beginPath();
    ctx.moveTo(2, 22);
    ctx.lineTo(-12, -35);
    ctx.quadraticCurveTo(-14, -42, -8, -44);
    ctx.lineTo(50, -44);
    ctx.quadraticCurveTo(56, -42, 54, -35);
    ctx.lineTo(40, 22);
    ctx.closePath();
    ctx.fill();

    // Metallischer Ring zwischen Kopf und Griff
    ctx.fillStyle = '#555';
    ctx.fillRect(-1, 18, 44, 5);
    let ringHighlight = ctx.createLinearGradient(-1, 18, 43, 18);
    ringHighlight.addColorStop(0, 'rgba(100,100,100,0)');
    ringHighlight.addColorStop(0.4, 'rgba(180,180,180,0.3)');
    ringHighlight.addColorStop(0.6, 'rgba(180,180,180,0.3)');
    ringHighlight.addColorStop(1, 'rgba(100,100,100,0)');
    ctx.fillStyle = ringHighlight;
    ctx.fillRect(-1, 18, 44, 5);

    // Reflektor-Ring am Kopfende
    ctx.strokeStyle = '#666';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-10, -40);
    ctx.lineTo(52, -40);
    ctx.stroke();

    // --- Linse (leuchtend, mit Flicker-Effekt) ---
    let lensFlicker = flicker;

    // Linsen-Reflektor (innere Verspiegelung)
    let reflectorGrad = ctx.createLinearGradient(-6, -44, 48, -44);
    reflectorGrad.addColorStop(0, `rgba(200, 190, 170, ${0.3 * lensFlicker})`);
    reflectorGrad.addColorStop(0.5, `rgba(255, 250, 235, ${0.6 * lensFlicker})`);
    reflectorGrad.addColorStop(1, `rgba(200, 190, 170, ${0.3 * lensFlicker})`);
    ctx.fillStyle = reflectorGrad;
    ctx.fillRect(-8, -47, 58, 6);

    // Leuchtende Linse
    ctx.fillStyle = `rgba(255, 252, 240, ${0.95 * lensFlicker})`;
    ctx.fillRect(-8, -47, 58, 4);

    // Glow um die Linse
    let lensGlow = ctx.createRadialGradient(21, -47, 0, 21, -47, 100);
    lensGlow.addColorStop(0, `rgba(255, 250, 230, ${0.8 * lensFlicker})`);
    lensGlow.addColorStop(0.15, `rgba(255, 245, 210, ${0.5 * lensFlicker})`);
    lensGlow.addColorStop(0.4, `rgba(255, 240, 200, ${0.15 * lensFlicker})`);
    lensGlow.addColorStop(1, 'rgba(255, 235, 180, 0)');
    ctx.fillStyle = lensGlow;
    ctx.fillRect(-80, -150, 200, 140);

    // Lens flare (kleine Lichtreflexe)
    ctx.globalAlpha = 0.3 * lensFlicker;
    ctx.fillStyle = '#fffde8';
    ctx.beginPath(); ctx.arc(-5, -48, 3, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(47, -48, 2, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1.0;

    ctx.restore();
}

function render() {
    // Nur rendern, wenn der Context existiert und wir nicht im Jumpscare sind
    if (!ctx) return;

    if (gameState === 'gameover') {
        canvas.style.filter = 'none'; // Filter zurücksetzen bei Game Over
        return;
    }

    // --- ORIENTIERUNGSLOSIGKEIT (Blur-Effekt) ---
    // Erzeugt eine dynamische Unschärfe basierend auf der Intensität des roten Rand-Effekts
    const blurValue = jumpscareEffect.currentRedIntensity * 5; // Ergibt max ca. 3px Blur bei 0.6 Intensität
    canvas.style.filter = blurValue > 0.1 ? `blur(${blurValue}px)` : 'none';

    let time = Date.now() / 1000;

    const pAngle = gameState === 'start' ? 0.05 : player.angle; // Leicht schräger Blick im Startbildschirm
    const pX = gameState === 'start' ? 1.5 * TILE_SIZE : player.x;
    const pY = gameState === 'start' ? 1.5 * TILE_SIZE : player.y;

    const aspectRatio = width / height;
    const FOV = 2 * Math.atan(aspectRatio / 2);
    const dirX = Math.cos(pAngle);
    const dirY = Math.sin(pAngle);
    const planeX = -dirY * (aspectRatio / 2);
    const planeY = dirX * (aspectRatio / 2);
    const pitchOffset = player.pitch * (height * 0.5);

    if (gameState === 'playing' && floorPixels !== null && ceilingPixels !== null) {
        // --- TEXTURIERTER BODEN & DECKE (Performance-Buffer) ---
        if (!cachedScreenImg || cachedScreenImg.width !== width || cachedScreenImg.height !== height) {
            cachedScreenImg = ctx.createImageData(width, height);
            cachedPixels = new Uint32Array(cachedScreenImg.data.buffer);
        }
        const screenImg = cachedScreenImg;
        const pixels = cachedPixels;

        // Loop über den gesamten Bildschirm für Decke UND Boden
        for (let y = 0; y < height; y++) {
            const isFloor = y > height / 2 + pitchOffset;
            // p ist der vertikale Abstand zum Horizont
            const p = isFloor ? (y - height / 2 - pitchOffset) : (height / 2 + pitchOffset - y);
            
            // Sicherheits-Check: p darf nicht 0 oder negativ sein
            if (p < 0.1) continue;

            // Vertikale Distanz synchronisieren (muss exakt zur wallHeight-Logik passen)
            const rowDistance = (height / 2) / p;

            // Welt-Position der Zeile berechnen
            const floorStepX = (rowDistance * planeX * 2) / width;
            const floorStepY = (rowDistance * planeY * 2) / width;

            let floorX = (pX / TILE_SIZE) + rowDistance * (dirX - planeX);
            let floorY = (pY / TILE_SIZE) + rowDistance * (dirY - planeY);

            // Shading einmal pro Zeile berechnen (spart Millionen Kalkulationen)
            const shade = 1 - Math.min(1, rowDistance / 4);

            for (let x = 0; x < width; x++) {
                const tx = ((floorX * 1024) | 0) & 1023;
                const ty = ((floorY * 1024) | 0) & 1023;
                const texPos = ty * 1024 + tx;
                let color = isFloor ? floorPixels[texPos] : ceilingPixels[texPos];

                floorX += floorStepX;
                floorY += floorStepY;

                if (shade < 1) {
                    const r = ((color & 0xFF) * shade) | 0;
                    const g = (((color >> 8) & 0xFF) * shade) | 0;
                    const b = (((color >> 16) & 0xFF) * shade) | 0;
                    color = (color & 0xFF000000) | (b << 16) | (g << 8) | r;
                }

                pixels[y * width + x] = color;
            }
        }
        ctx.putImageData(screenImg, 0, 0);
    } else {
        // Fallback falls Texturen noch laden oder fehlgeschlagen sind
        ctx.fillStyle = '#111'; // Boden
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#050505'; // Decke
        ctx.fillRect(0, 0, width, height / 2 + pitchOffset);
    }
    const STRIP_WIDTH = 2; // Höhere Auflösung
    const NUM_RAYS = Math.ceil(width / STRIP_WIDTH); // Changed from 2 to 3 for performance

    if (!zBuffer || zBuffer.length !== NUM_RAYS) {
        zBuffer = new Float64Array(NUM_RAYS);
    }
    zBuffer.fill(Infinity);

    for (let i = 0; i < NUM_RAYS; i++) {
        // camX ist die Position auf der Bildebene von -1 (links) bis 1 (rechts)
        const camX = (2 * i) / (NUM_RAYS - 1) - 1;
        const dx = dirX + planeX * camX;
        const dy = dirY + planeY * camX;

        let renderMap = gameState === 'start' ? startScreenMap : map;
        let mapW = gameState === 'start' ? renderMap[0].length : MAP_WIDTH;
        let mapH = gameState === 'start' ? renderMap.length : MAP_HEIGHT;

        let mapX = (pX / TILE_SIZE) | 0;
        let mapY = (pY / TILE_SIZE) | 0;

        let deltaDistX = Math.abs(1 / dx);
        let deltaDistY = Math.abs(1 / dy);

        let stepX, stepY;
        let sideDistX, sideDistY;

        if (dx < 0) {
            stepX = -1;
            sideDistX = ((pX / TILE_SIZE) - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - (pX / TILE_SIZE)) * deltaDistX;
        }

        if (dy < 0) {
            stepY = -1;
            sideDistY = ((pY / TILE_SIZE) - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - (pY / TILE_SIZE)) * deltaDistY;
        }

        let hit = false;
        let side = 0;
        let hitTile = null;

        while (!hit && mapX >= 0 && mapX < mapW && mapY >= 0 && mapY < mapH) {
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0;
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1;
            }
            if (renderMap[mapY] && renderMap[mapY][mapX] !== '0') {
                let t = renderMap[mapY][mapX];
                if (t === '1' || t === '2' || t === '4' || t === '5' || t === 'U' || t === 'D' || t === 'E' || 'KSWB'.includes(t)) {
                    hit = true;
                    hitTile = t;
                }
            }
        }

        if (hit) {
            let perpWallDist;
            // Use pX and pY instead of player.x/y to ensure consistency with the start screen and floor transitions
            if (side === 0) perpWallDist = (mapX - (pX / TILE_SIZE) + (1 - stepX) / 2) / dx;
            else perpWallDist = (mapY - (pY / TILE_SIZE) + (1 - stepY) / 2) / dy;

            if (perpWallDist < 0.1) perpWallDist = 0.1;
            let dist = perpWallDist * TILE_SIZE;
            zBuffer[i] = dist;

            // Perspektivisch korrekte Wandhöhe: Wand füllt bei Distanz 1 exakt den Bildschirm
            let wallHeight = canvas.height / perpWallDist;

            // Die Z-Position des Spielers verschiebt die vertikale Zeichnung der Wand
            let zOffset = (player.z / TILE_SIZE) * wallHeight;
            let wallTop = (canvas.height / 2) - (wallHeight / 2) + pitchOffset + zOffset;
            let wallBottom = wallTop + wallHeight;

            let wallX;
            if (side === 0) wallX = (pY / TILE_SIZE) + perpWallDist * dy;
            else wallX = (pX / TILE_SIZE) + perpWallDist * dx;
            wallX -= Math.floor(wallX);

            // Textur-Auswahl mit Fallback-Check
            let tex;
            let roomColor = null;
            let hasPoster = false;
            let baseWallTint = null; // Neue Variable für generische Wandtönung

            if (hitTile === '1' || 'KSWB'.includes(hitTile)) {
                tex = wallImg; // Komposit-Canvas: Web-Textur oder prozeduraler Fallback

                if (hitTile === 'K') roomColor = 'rgba(0, 120, 0, 0.45)'; // Küche: Moosgrün
                if (hitTile === 'S') { roomColor = 'rgba(0, 0, 150, 0.45)'; hasPoster = true; } // Schlafzimmer: Nachtblau
                if (hitTile === 'W') roomColor = 'rgba(150, 0, 0, 0.45)'; // Wohnzimmer: Blutrot
                if (hitTile === 'B') roomColor = 'rgba(180, 160, 0, 0.5)'; // Bad: Krankhaftes Gelb

                // Generische Wandtönung für '1' und andere Raumwände, falls keine spezifische Raumfarbe vorhanden ist
                if (!roomColor) {
                    let hue = (mapX * 47 + mapY * 31 + (currentFloor * 90)) % 360; // Größere Farbsprünge
                    let saturation = 45;
                    let lightness = 35;
                    baseWallTint = `hsla(${hue}, ${saturation}%, ${lightness}%, 0.4)`; // Kräftigerer Tint
                }
            } else if (hitTile === 'U' || hitTile === 'D') {
                if (stairsImg.complete && stairsImg.width > 0) tex = stairsImg;
                else { tex = stairsTexFallback; }
            } else if (hitTile === '2') {
                if (doorImg.complete && doorImg.width > 0) tex = doorImg;
                else { tex = doorTexFallback; }
            } else {
                tex = wallTexFallback; // Standard-Fallback für unbekannte Kacheln
            }

            // Grafik-Fix: Clamp texX um Out-of-Bounds Fehler und schwarze Linien zu vermeiden
            let texX = Math.min(tex.width - 1, Math.floor(wallX * tex.width));

            if (side === 0 && dx > 0) texX = tex.width - texX - 1;
            if (side === 1 && dy < 0) texX = tex.width - texX - 1;

            // Stark reduziertes Umgebungslicht für echtes Horror-Feeling
            let ambientLight = (gameState === 'start') ? 0.2 : 0.01; // Fast pechschwarz
            let shade = Math.pow(Math.max(0, 1 - (dist / 300)), 2) * ambientLight;

            // Oberflächen-Varianz für mehr Realismus (Schmutz-Simulation)
            let surfaceNoise = Math.sin(mapX * 13 + mapY * 7 + wallX * 5) * 0.03;
            shade = Math.max(0, shade + surfaceNoise);

            // RICHTUNGS-SHADING: Hilft extrem bei der Orientierung in Ecken
            if (side === 1) shade *= 0.6; // Seitliche Wände dunkler
            else if (dx < 0) shade *= 0.85; // West-Wände leicht abdunkeln

            // --- REALISTISCHE TASCHENLAMPE mit rundem Kegel ---
            let flicker = window._flashlightFlicker || 1.0;
            let centerDistX = Math.abs(i - NUM_RAYS / 2);
            
            // Optimierte vertikale Lichtberechnung: Prüft die Distanz zum nächsten Punkt der Wand
            let screenCenterY = canvas.height / 2;
            let closestWallY = Math.max(wallTop, Math.min(screenCenterY, wallBottom));
            let centerDistY = Math.abs(closestWallY - screenCenterY) / canvas.height * NUM_RAYS;
            
            // Euklidische Distanz für runden Lichtkegel
            let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);

            // Warmer Farbton-Multiplikator (wird beim Zeichnen angewendet)
            let warmR = 1.0, warmG = 1.0, warmB = 1.0;

            // Taschenlampe immer an (auch im Startbildschirm)
            if (true) {
                let flashlightCone = NUM_RAYS / 2.3;
                let flashlightFactor = Math.max(0, 1 - (centerDist2D / flashlightCone));
                if (flashlightFactor > 0 && dist < 650) {
                    // Realistischer Hotspot mit inverse-square-artigem Abfall
                    let distFalloff = 1 / (1 + (dist / 120) * (dist / 120)) * 2.5;
                    let beamIntensity = Math.pow(flashlightFactor, 2.5) * distFalloff * 4.2 * flicker; // Hellerer Kern
                    shade += beamIntensity;

                    // Breitere Corona (Streulicht)
                    let coronaFactor2D = Math.max(0, 1 - (centerDist2D / (NUM_RAYS / 1.5)));
                    shade += Math.pow(coronaFactor2D, 2) * (1 - (dist / 450)) * 0.3 * flicker; // Dunklerer Rand

                    // Warmer Farbton im Lichtkegel (stärker im Zentrum)
                    let warmth = flashlightFactor * 0.15;
                    warmR = 1.0 + warmth * 0.3;
                    warmG = 1.0 + warmth * 0.15;
                    warmB = 1.0 - warmth * 0.2;
                }
            }

            // --- FENSTER & DONNER-BELEUCHTUNG ---
            let isWindow = false;
            for (let w = 0; w < windowsData.length; w++) {
                if (windowsData[w].floor === currentFloor && windowsData[w].x === mapX && windowsData[w].y === mapY) {
                    isWindow = true;
                    break;
                }
            }
            if (isWindow && thunderState.active) {
                // Blitz erhellt Fenster-Kacheln dramatisch
                shade += thunderState.intensity * 1.5;
            } else if (isWindow) {
                // Fenster haben schwaches bläuliches Mondlicht
                shade += 0.03;
                warmB = Math.min(warmB + 0.1, 1.2);
            }

            // Fackeln beleuchten nahe Wände
            for (let ti = 0; ti < torchesData.length; ti++) {
                let torch = torchesData[ti];
                if (torch.floor !== currentFloor) continue;
                let wallWorldX = mapX * TILE_SIZE + wallX * TILE_SIZE;
                let wallWorldY = mapY * TILE_SIZE + TILE_SIZE / 2;
                let torchDist = Math.hypot(wallWorldX - torch.x, wallWorldY - torch.y);
                if (torchDist < TILE_SIZE * 3) {
                    let torchLight = Math.pow(1 - torchDist / (TILE_SIZE * 3), 2) * 0.3;
                    torch.flickerCounter += 0.07;
                    torchLight *= 0.8 + Math.sin(torch.flickerCounter) * 0.2;
                    shade += torchLight;
                    warmR = Math.min(warmR + torchLight * 0.5, 1.4);
                    warmG = Math.min(warmG + torchLight * 0.2, 1.2);
                }
            }

            // Fog effect: blend with black based on distance
            let fogAmount = Math.min(1, dist / 450); // Sichtweite drastisch reduziert
            shade = shade * (1 - fogAmount);
            
            // Sicherheit: Wand nur zeichnen, wenn sie existiert. Shade wird auf 0 geklammert statt abzubrechen.
            if (wallHeight > 0.1) {
                ctx.globalAlpha = Math.max(0, Math.min(1, shade));
                if (hitTile !== 'E') {
                    // Zeichne Wand (mit Clipping-Schutz)
                    ctx.drawImage(tex, texX, 0, 1, tex.height, i * STRIP_WIDTH, wallTop, STRIP_WIDTH + 0.5, wallHeight);

                    // Warmer Licht-Tint über die Textur (additiv)
                    if (warmR > 1.01 || warmG > 1.01 || warmB < 0.99) {
                        let tintAlpha = Math.min(0.15, shade * 0.12);
                        let tR = Math.floor(Math.min(255, (warmR - 1) * 400));
                        let tG = Math.floor(Math.min(255, (warmG - 1) * 300));
                        ctx.globalAlpha = tintAlpha;
                        ctx.fillStyle = `rgb(${tR}, ${tG}, 0)`;
                        ctx.fillRect(i * STRIP_WIDTH, wallTop, STRIP_WIDTH + 0.6, wallHeight);
                        ctx.globalAlpha = Math.min(1, shade);
                    }

                    // Fenster-Rendering: hellere Fläche mit Rahmen
                    if (isWindow && wallX > 0.15 && wallX < 0.85) {
                        let winTop = wallTop + wallHeight * 0.15;
                        let winH = wallHeight * 0.55;
                        // Hintergrund: dunkles Blau (Nachthimmel)
                        let skyBrightness = thunderState.active ? Math.floor(40 + thunderState.intensity * 180) : 15;
                        ctx.fillStyle = `rgb(${Math.floor(skyBrightness * 0.3)}, ${Math.floor(skyBrightness * 0.35)}, ${skyBrightness})`;
                        ctx.fillRect(i * STRIP_WIDTH, winTop, STRIP_WIDTH + 0.6, winH);
                        // Rahmen
                        if (wallX > 0.14 && wallX < 0.18 || wallX > 0.82 && wallX < 0.86 || wallX > 0.48 && wallX < 0.52) {
                            ctx.fillStyle = 'rgba(20, 15, 10, 0.9)';
                            ctx.fillRect(i * STRIP_WIDTH, winTop, STRIP_WIDTH + 0.6, winH);
                        }
                    }

                    // --- RAUM-DETAILS (Farben & Poster) / Generische Wandfarbe ---
                    if ((roomColor || baseWallTint) && !isWindow) {
                        const baseAlpha = roomColor ? parseFloat(roomColor.split(',')[3]) : 0.4;
                        ctx.globalAlpha = baseAlpha * Math.min(1, shade * 1.2);
                        ctx.fillStyle = roomColor || baseWallTint;
                        ctx.fillRect(i * STRIP_WIDTH, wallTop, STRIP_WIDTH + 0.6, wallHeight);
                    }
                    ctx.globalAlpha = Math.min(1, shade);

                    // Poster-Effekt
                    if (hasPoster && wallX > 0.4 && wallX < 0.6) {
                        ctx.fillStyle = 'rgba(20, 20, 20, 0.85)';
                        ctx.fillRect(i * STRIP_WIDTH, wallTop + wallHeight * 0.25, STRIP_WIDTH + 0.6, wallHeight * 0.4);
                        ctx.fillStyle = 'rgba(120, 0, 0, 0.6)';
                        ctx.fillRect(i * STRIP_WIDTH, wallTop + wallHeight * 0.4, STRIP_WIDTH + 0.6, wallHeight * 0.05);
                    }

                    // Fußleiste und Deckenkante
                    ctx.fillStyle = 'rgba(10, 5, 5, 0.7)';
                    ctx.fillRect(i * STRIP_WIDTH, wallTop + wallHeight * 0.88, STRIP_WIDTH + 0.6, wallHeight * 0.12);
                    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                    ctx.fillRect(i * STRIP_WIDTH, wallTop, STRIP_WIDTH + 0.6, wallHeight * 0.06);
                } else {
                    let color = hitTile === 'E' ? '#115511' : '#444';
                    ctx.fillStyle = color;
                    ctx.fillRect(i * STRIP_WIDTH, wallTop, STRIP_WIDTH, wallHeight);
                }
                ctx.lineWidth = 1;
                ctx.globalAlpha = 1.0;
            }
        }
    }

    // Draw Sprites
    let sprites = [];
    if (gameState === 'start') {
        // Monster-Augen lauern bei der zweiten Tür rechts
        sprites.push({ x: 8.25 * TILE_SIZE, y: 1.95 * TILE_SIZE, type: 'start_eyes', radius: 10 });
    } else {
        enemiesData.forEach(e => { if (e.floor === currentFloor) sprites.push({ x: e.x, y: e.y, type: 'enemy', radius: e.radius, state: e.state }) });
        keysData.forEach(k => { if (!k.collected && k.floor === currentFloor) sprites.push({ x: k.x, y: k.y, type: 'key', radius: 10 }) });
        torchesData.forEach(t => { if (t.floor === currentFloor) sprites.push({ x: t.x, y: t.y, type: 'torch', radius: 10, flick: t.flickerCounter }) });
        bloodSplattersData.forEach(b => { if (b.floor === currentFloor) sprites.push({ x: b.x, y: b.y, z: b.z, type: 'blood', radius: b.size, opacity: b.opacity }) });
    }

    sprites.forEach(s => {
        let dx = s.x - pX;
        let dy = s.y - pY;

        // Manhattan-Distanz Quick-Culling (Performance)
        if (Math.abs(dx) + Math.abs(dy) > 4000) {
            s.dist = 99999;
            s.angle = 0;
            return;
        }

        s.dist = Math.hypot(dx, dy);
        let angleToSprite = Math.atan2(dy, dx);
        s.angle = angleToSprite - pAngle;
        while (s.angle > Math.PI) s.angle -= Math.PI * 2;
        while (s.angle < -Math.PI) s.angle += Math.PI * 2;
    });

    sprites.sort((a, b) => b.dist - a.dist);

    sprites.forEach(s => {
        if (s.dist < 5) return;
        if (Math.abs(s.angle) > FOV / 1.5) return;

        let screenX = (0.5 * (s.angle / (FOV / 2)) + 0.5) * canvas.width;
        let spriteScale = (TILE_SIZE * canvas.height * 0.8) / (s.dist * Math.cos(s.angle));
        if (!isFinite(spriteScale) || spriteScale <= 0) return;

        let spriteHeight = spriteScale * (s.radius / TILE_SIZE) * 2;
        let spriteWidth = spriteHeight;

        // Grafik-Fix: Sprites müssen den vertikalen Z-Offset des Spielers (Treppen) mitmachen
        let spriteZOffset = (player.z / TILE_SIZE) * spriteScale;
        let customZOffset = (s.z || 0) / TILE_SIZE * spriteScale;
        let spriteTop = (canvas.height / 2) - (spriteHeight / 2) + pitchOffset + spriteZOffset + customZOffset;

        if (s.type === 'key') spriteTop += spriteHeight * 0.5;

        let centerIdx = Math.floor(screenX / STRIP_WIDTH);
        let projectedSpriteDist = s.dist * Math.cos(s.angle);
        let visible = (centerIdx >= 0 && centerIdx < NUM_RAYS && zBuffer[centerIdx] > projectedSpriteDist - 5);

        if (visible) {
            // Umgebungslicht für Sprites (pechschwarz)
            let shade = Math.max(0.005, 0.02 - (s.dist / 250));
            let flicker = window._flashlightFlicker || 1.0;
            let centerDistX = Math.abs((screenX / canvas.width) - 0.5) * NUM_RAYS;
            // Vertikale Komponente für Sprites (runder Kegel)
            let spriteCenterY = spriteTop + spriteHeight / 2;
                // Auch für Objekte/Monster bleibt das Licht im Zentrum des Blicks
                let screenCenterY = canvas.height / 2;
            let centerDistY = Math.abs(spriteCenterY - screenCenterY) / canvas.height * NUM_RAYS;
            let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);
            let flashlightRadius = NUM_RAYS / 2.3;

            if (centerDist2D < flashlightRadius * 2 && s.dist < 650) {
                // Realistischer Hotspot mit inverse-square Abfall
                let distFalloff = 1 / (1 + (s.dist / 120) * (s.dist / 120)) * 2.5;
                let spriteFlashLight = Math.pow(Math.max(0, 1 - (centerDist2D / flashlightRadius)), 2.5) * distFalloff * 4.5 * flicker;
                shade += spriteFlashLight;

                // Corona
                let corona = Math.pow(Math.max(0, 1 - (centerDist2D / (NUM_RAYS / 1.5))), 2) * (1 - (s.dist / 450)) * 0.3 * flicker;
                shade += corona;
            }

            // Fackel-Beleuchtung für Sprites
            for (let ti = 0; ti < torchesData.length; ti++) {
                let torch = torchesData[ti];
                if (torch.floor !== currentFloor) continue;
                let torchDist = Math.hypot(s.x - torch.x, s.y - torch.y);
                if (torchDist < TILE_SIZE * 3) {
                    shade += Math.pow(1 - torchDist / (TILE_SIZE * 3), 2) * 0.25;
                }
            }

            // Blitz beleuchtet alle Sprites kurz
            if (thunderState.active) {
                shade += thunderState.intensity * 0.3;
            }

            if (s.type === 'torch') shade = 1;

            shade = shade * (1 - Math.min(1, s.dist / 450)); // Nebel für Sprites

            ctx.globalAlpha = Math.min(1, shade);

            if (s.type === 'start_eyes') {
                // Nur zwei glühende rote Augen im Dunkeln
                let eyeY = spriteTop + spriteHeight * 0.45;
                let eyeSize = Math.max(1, spriteWidth * 0.08);
                let eyeDist = spriteWidth * 0.15;

                ctx.fillStyle = '#ff0000';
                ctx.shadowColor = '#ff0000';
                ctx.shadowBlur = 15 + Math.sin(time * 3) * 5;

                ctx.beginPath();
                ctx.arc(screenX - eyeDist, eyeY, eyeSize, 0, Math.PI * 2);
                ctx.fill();

                ctx.beginPath();
                ctx.arc(screenX + eyeDist, eyeY, eyeSize, 0, Math.PI * 2);
                ctx.fill();

                ctx.shadowBlur = 0;
            } else if (s.type === 'enemy' && spriteWidth > 1) { // Nur zeichnen, wenn groß genug
                let t = Date.now() / 1000;
                let w = spriteWidth;
                let h = spriteHeight;
                let cx = screenX;
                let top = spriteTop;
                let isChase = s.state === 'chase';

                // Ruckartige Zuckungen: springen mehrmals pro Sekunde auf neue Werte
                // (wirkt wie kaputtes Stop-Motion — deutlich unheimlicher als glattes Wackeln)
                const twitchSeed = Math.floor(t * (isChase ? 14 : 7));
                const twitchX = (noise2D(twitchSeed, 1.7) - 0.5) * w * (isChase ? 0.08 : 0.025);
                const twitchTilt = (noise2D(twitchSeed, 9.3) - 0.5) * (isChase ? 0.4 : 0.14);
                const breathing = Math.sin(t * (isChase ? 6 : 2.2)) * 0.02;
                const armSway = Math.sin(t * 3 + s.dist * 0.01) * w * 0.04;

                // Fahle Leichenhaut mit zylindrischer Schattierung
                const skinGrad = ctx.createLinearGradient(cx - w * 0.2, 0, cx + w * 0.2, 0);
                skinGrad.addColorStop(0, isChase ? '#241210' : '#1c1a16');
                skinGrad.addColorStop(0.5, isChase ? '#7a6660' : '#6e6a60');
                skinGrad.addColorStop(1, isChase ? '#1a0c0a' : '#141310');
                const limbColor = isChase ? '#4a3835' : '#403d36';
                const shadowColor = isChase ? '#1c0a08' : '#15130f';

                ctx.save();
                // Ganzer Körper schwankt leicht und zuckt
                ctx.translate(cx + twitchX, top + h * 0.55);
                ctx.rotate(Math.sin(t * 1.3 + s.dist * 0.01) * 0.03 + twitchTilt * 0.25);
                ctx.translate(-(cx + twitchX), -(top + h * 0.55));

                // --- BEINE (nach hinten geknickt, wie ein Tier) ---
                ctx.strokeStyle = limbColor;
                ctx.lineCap = 'round';
                ctx.lineWidth = w * 0.05;
                for (let side = -1; side <= 1; side += 2) {
                    const step = Math.sin(t * (isChase ? 12 : 4) + side * 1.6) * w * 0.03;
                    ctx.beginPath();
                    ctx.moveTo(cx + side * w * 0.08, top + h * 0.62);
                    ctx.lineTo(cx + side * w * 0.16 + step, top + h * 0.78); // Knie nach außen/hinten
                    ctx.lineTo(cx + side * w * 0.07 + step * 0.5, top + h * 0.96);
                    ctx.stroke();
                    // Lange Zehenkrallen
                    ctx.lineWidth = w * 0.015;
                    for (let f = -1; f <= 1; f++) {
                        ctx.beginPath();
                        ctx.moveTo(cx + side * w * 0.07 + step * 0.5, top + h * 0.96);
                        ctx.lineTo(cx + side * w * 0.07 + step * 0.5 + f * w * 0.03 + side * w * 0.04, top + h * 0.995);
                        ctx.stroke();
                    }
                    ctx.lineWidth = w * 0.05;
                }

                // --- TORSO (ausgemergelt, leicht vornübergebeugt) ---
                ctx.fillStyle = skinGrad;
                ctx.beginPath();
                ctx.moveTo(cx - w * (0.13 + breathing), top + h * 0.26);
                ctx.quadraticCurveTo(cx - w * 0.20, top + h * 0.38, cx - w * 0.085, top + h * 0.52); // eingefallene Taille
                ctx.quadraticCurveTo(cx - w * 0.10, top + h * 0.60, cx - w * 0.09, top + h * 0.66);
                ctx.lineTo(cx + w * 0.09, top + h * 0.66);
                ctx.quadraticCurveTo(cx + w * 0.10, top + h * 0.60, cx + w * 0.085, top + h * 0.52);
                ctx.quadraticCurveTo(cx + w * 0.20, top + h * 0.38, cx + w * (0.13 + breathing), top + h * 0.26);
                ctx.closePath();
                ctx.fill();

                // Rippen drücken durch die Haut (dunkle Schatten + helle Knochenkanten)
                for (let r = 0; r < 6; r++) {
                    const ry = top + h * (0.32 + r * 0.045);
                    const ribW = w * (0.115 - r * 0.011);
                    ctx.strokeStyle = 'rgba(0, 0, 0, 0.45)';
                    ctx.lineWidth = w * 0.014;
                    ctx.beginPath();
                    ctx.moveTo(cx - ribW, ry);
                    ctx.quadraticCurveTo(cx, ry + w * 0.025, cx + ribW, ry);
                    ctx.stroke();
                    ctx.strokeStyle = 'rgba(160, 150, 135, 0.25)';
                    ctx.lineWidth = w * 0.008;
                    ctx.beginPath();
                    ctx.moveTo(cx - ribW, ry - w * 0.008);
                    ctx.quadraticCurveTo(cx, ry + w * 0.015, cx + ribW, ry - w * 0.008);
                    ctx.stroke();
                }
                // Eingefallener Bauch (dunkle Höhlung)
                const bellyGrad = ctx.createRadialGradient(cx, top + h * 0.56, 0, cx, top + h * 0.56, w * 0.09);
                bellyGrad.addColorStop(0, 'rgba(0,0,0,0.55)');
                bellyGrad.addColorStop(1, 'rgba(0,0,0,0)');
                ctx.fillStyle = bellyGrad;
                ctx.fillRect(cx - w * 0.09, top + h * 0.48, w * 0.18, h * 0.16);

                // Dunkle Flecken / Wunden auf der Haut
                for (let p = 0; p < 4; p++) {
                    const px = cx + (noise2D(p * 7.7, 3.1) - 0.5) * w * 0.2;
                    const py = top + h * (0.3 + noise2D(p * 3.3, 8.8) * 0.3);
                    ctx.fillStyle = `rgba(${isChase ? '60, 10, 5' : '25, 20, 15'}, 0.5)`;
                    ctx.beginPath();
                    ctx.ellipse(px, py, w * 0.025, w * 0.04, p, 0, Math.PI * 2);
                    ctx.fill();
                }

                // --- ARME (viel zu lang, fast bis zum Boden) ---
                ctx.strokeStyle = limbColor;
                ctx.lineWidth = w * 0.042;
                for (let side = -1; side <= 1; side += 2) {
                    // Bei der Jagd greifen die Arme nach vorne (zur Kamera)
                    const reach = isChase ? w * 0.06 : 0;
                    const handX = cx + side * (w * 0.27 + reach) + armSway * side;
                    const handY = top + h * (isChase ? 0.62 : 0.82) + breathing * h;
                    ctx.beginPath();
                    ctx.moveTo(cx + side * w * 0.13, top + h * 0.28); // Schulter
                    ctx.lineTo(cx + side * w * 0.26 - armSway * side, top + h * 0.48); // Ellbogen weit außen
                    ctx.lineTo(handX, handY); // Handgelenk
                    ctx.stroke();

                    // Hand: gespreizte, viel zu lange Krallenfinger
                    ctx.lineWidth = w * 0.011;
                    ctx.strokeStyle = isChase ? '#5c4a45' : '#4d4a42';
                    for (let f = 0; f < 4; f++) {
                        const fAngle = (f - 1.5) * 0.32 + side * 0.5 + (isChase ? Math.PI * 0.45 : Math.PI * 0.5);
                        const fLen = w * (0.085 + (f === 1 || f === 2 ? 0.025 : 0));
                        const midX = handX + Math.cos(fAngle) * fLen * 0.6;
                        const midY = handY + Math.sin(fAngle) * fLen * 0.6;
                        ctx.beginPath();
                        ctx.moveTo(handX, handY);
                        ctx.quadraticCurveTo(midX, midY, midX + Math.cos(fAngle + 0.5) * fLen * 0.5, midY + Math.sin(fAngle + 0.5) * fLen * 0.5);
                        ctx.stroke();
                    }
                    ctx.lineWidth = w * 0.042;
                    ctx.strokeStyle = limbColor;
                }

                // --- KOPF (kahl, länglich, ruckartig geneigt) ---
                const headY = top + h * 0.155;
                ctx.save();
                ctx.translate(cx, headY);
                ctx.rotate(twitchTilt); // Kopf kippt unnatürlich zur Seite
                ctx.translate(-cx, -headY);

                const headGrad = ctx.createRadialGradient(cx - w * 0.03, headY - w * 0.04, w * 0.01, cx, headY, w * 0.16);
                headGrad.addColorStop(0, isChase ? '#8a7570' : '#7d7868');
                headGrad.addColorStop(0.7, isChase ? '#4a3530' : '#403c33');
                headGrad.addColorStop(1, shadowColor);
                ctx.fillStyle = headGrad;
                ctx.beginPath();
                // Länglicher Schädel mit schmalem Kinn
                ctx.moveTo(cx, headY - w * 0.135);
                ctx.bezierCurveTo(cx + w * 0.115, headY - w * 0.13, cx + w * 0.105, headY + w * 0.04, cx + w * 0.045, headY + w * 0.115);
                ctx.quadraticCurveTo(cx, headY + w * 0.15, cx - w * 0.045, headY + w * 0.115);
                ctx.bezierCurveTo(cx - w * 0.105, headY + w * 0.04, cx - w * 0.115, headY - w * 0.13, cx, headY - w * 0.135);
                ctx.fill();

                // Eingefallene Wangen
                ctx.fillStyle = 'rgba(0,0,0,0.35)';
                ctx.beginPath();
                ctx.ellipse(cx - w * 0.06, headY + w * 0.035, w * 0.025, w * 0.04, 0.3, 0, Math.PI * 2);
                ctx.ellipse(cx + w * 0.06, headY + w * 0.035, w * 0.025, w * 0.04, -0.3, 0, Math.PI * 2);
                ctx.fill();

                // Tiefe schwarze Augenhöhlen
                const eyeY = headY - w * 0.025;
                const eyeSpread = w * 0.052;
                for (let side = -1; side <= 1; side += 2) {
                    const sockGrad = ctx.createRadialGradient(cx + side * eyeSpread, eyeY, 0, cx + side * eyeSpread, eyeY, w * 0.038);
                    sockGrad.addColorStop(0, '#000');
                    sockGrad.addColorStop(0.75, '#050505');
                    sockGrad.addColorStop(1, 'rgba(5,5,5,0)');
                    ctx.fillStyle = sockGrad;
                    ctx.beginPath();
                    ctx.ellipse(cx + side * eyeSpread, eyeY, w * 0.035, w * 0.042, side * 0.2, 0, Math.PI * 2);
                    ctx.fill();
                }

                // Winzige glühende Pupillen tief in den Höhlen (rot bei Jagd)
                const pupilR = Math.max(0.4, w * (isChase ? 0.011 : 0.008));
                ctx.fillStyle = isChase ? '#ff2200' : '#d8d4c4';
                ctx.shadowColor = isChase ? '#ff2200' : '#999';
                ctx.shadowBlur = isChase ? 14 : 5;
                ctx.beginPath(); ctx.arc(cx - eyeSpread, eyeY + w * 0.005, pupilR, 0, Math.PI * 2); ctx.fill();
                ctx.beginPath(); ctx.arc(cx + eyeSpread, eyeY + w * 0.005, pupilR, 0, Math.PI * 2); ctx.fill();
                ctx.shadowBlur = 0;

                // Nasenlöcher (keine Nase, nur zwei Schlitze)
                ctx.fillStyle = 'rgba(0,0,0,0.7)';
                ctx.beginPath();
                ctx.ellipse(cx - w * 0.008, headY + w * 0.035, w * 0.005, w * 0.011, 0.15, 0, Math.PI * 2);
                ctx.ellipse(cx + w * 0.008, headY + w * 0.035, w * 0.005, w * 0.011, -0.15, 0, Math.PI * 2);
                ctx.fill();

                // Ausgerenkter, klaffender Kiefer (bei Jagd weit offen)
                const jawDrop = w * (isChase ? 0.085 + Math.sin(t * 9) * 0.012 : 0.045 + breathing * 0.5);
                const mouthY = headY + w * 0.085;
                ctx.fillStyle = '#020101';
                ctx.beginPath();
                ctx.ellipse(cx, mouthY + jawDrop * 0.5, w * 0.038, jawDrop, 0, 0, Math.PI * 2);
                ctx.fill();

                // Schiefe, nadelartige Zähne
                ctx.fillStyle = 'rgba(190, 180, 155, 0.9)';
                for (let tooth = -3; tooth <= 3; tooth++) {
                    if (tooth === 0) continue;
                    const tx = cx + tooth * w * 0.01;
                    const tLen = w * (0.012 + Math.abs(noise2D(tooth, 5.5)) * 0.014);
                    // obere Reihe
                    ctx.beginPath();
                    ctx.moveTo(tx - w * 0.004, mouthY - jawDrop * 0.4);
                    ctx.lineTo(tx, mouthY - jawDrop * 0.4 + tLen);
                    ctx.lineTo(tx + w * 0.004, mouthY - jawDrop * 0.4);
                    ctx.fill();
                    // untere Reihe
                    ctx.beginPath();
                    ctx.moveTo(tx - w * 0.004, mouthY + jawDrop * 1.35);
                    ctx.lineTo(tx, mouthY + jawDrop * 1.35 - tLen);
                    ctx.lineTo(tx + w * 0.004, mouthY + jawDrop * 1.35);
                    ctx.fill();
                }

                // Schwarzer Speichel läuft aus dem Mund
                ctx.strokeStyle = 'rgba(10, 5, 5, 0.75)';
                ctx.lineWidth = Math.max(0.5, w * 0.006);
                for (let d = -1; d <= 1; d++) {
                    const dx = cx + d * w * 0.018;
                    const dLen = w * (0.04 + Math.abs(noise2D(d, twitchSeed)) * 0.05);
                    ctx.beginPath();
                    ctx.moveTo(dx, mouthY + jawDrop * 1.3);
                    ctx.quadraticCurveTo(dx + d * w * 0.005, mouthY + jawDrop * 1.3 + dLen * 0.6, dx, mouthY + jawDrop * 1.3 + dLen);
                    ctx.stroke();
                }

                ctx.restore(); // Kopf-Neigung
                ctx.restore(); // Körper-Schwanken
                ctx.lineCap = 'butt';
            } else if (s.type === 'key') {
                let t = Date.now() / 1000;
                let w = spriteWidth * 0.6; // Schlüssel etwas schmaler
                let h = spriteHeight * 0.6;
                let cx = screenX;
                let floatingY = spriteTop + spriteHeight * 0.5 + Math.sin(t * 4) * 10; // Schweb-Effekt

                ctx.fillStyle = '#ffd700'; // Gold
                ctx.strokeStyle = '#b8860b'; // Dunkles Gold für Outlines
                ctx.lineWidth = 2;

                // Schlüssel-Kopf (Ring oben)
                ctx.beginPath();
                ctx.arc(cx, floatingY, w * 0.2, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Loch im Kopf
                ctx.globalCompositeOperation = 'destination-out';
                ctx.beginPath();
                ctx.arc(cx, floatingY, w * 0.08, 0, Math.PI * 2);
                ctx.fill();
                ctx.globalCompositeOperation = 'source-over';

                // Schaft (Stab)
                ctx.fillRect(cx - w * 0.05, floatingY + w * 0.2, w * 0.1, h * 0.5);

                // Bart (die Zacken unten)
                ctx.fillRect(cx + w * 0.05, floatingY + w * 0.2 + h * 0.35, w * 0.15, h * 0.06);
                ctx.fillRect(cx + w * 0.05, floatingY + w * 0.2 + h * 0.45, w * 0.12, h * 0.06);
            } else if (s.type === 'torch') {
                ctx.fillStyle = '#ff6600'; // Feste Farbe, da kein Flackern mehr durch Blitz
                ctx.beginPath(); ctx.arc(screenX, spriteTop, spriteWidth / 2, 0, Math.PI * 2); ctx.fill();
            }
            ctx.globalAlpha = 1.0;
        }
    });

    // --- 3D STAUB PARTIKEL (Performance-optimierter Wrap-Around) ---
    if (!window._dustParticles3D) {
        window._dustParticles3D = [];
        for (let i = 0; i < 150; i++) {
            window._dustParticles3D.push({
                x: player.x + (Math.random() - 0.5) * 600,
                y: player.y + (Math.random() - 0.5) * 600,
                z: Math.random() * TILE_SIZE, // 0 (Boden) bis TILE_SIZE (Decke)
                vx: (Math.random() - 0.5) * 0.4,
                vy: (Math.random() - 0.5) * 0.4,
                vz: (Math.random() - 0.5) * 0.2 - 0.1, // Leichtes Sinken
                size: Math.random() * 2 + 0.5,
                phase: Math.random() * Math.PI * 2
            });
        }
    }

    let flicker = window._flashlightFlicker || 1.0;
    let flashlightRadius = NUM_RAYS / 2.3;
    // Staubpartikel werden nun auch im Zentrum des Blicks beleuchtet
    let screenCenterY = canvas.height / 2;

    window._dustParticles3D.forEach(p => {
        // Bewegung
        p.x += p.vx + Math.sin(time + p.phase) * 0.3;
        p.y += p.vy + Math.cos(time + p.phase) * 0.3;
        p.z += p.vz;

        // Wrap-around um den Spieler
        if (p.x - pX > 300) p.x -= 600;
        if (p.x - pX < -300) p.x += 600;
        if (p.y - pY > 300) p.y -= 600;
        if (p.y - pY < -300) p.y += 600;
        if (p.z < 0) p.z += TILE_SIZE;
        if (p.z > TILE_SIZE) p.z -= TILE_SIZE;

        let dx = p.x - pX;
        let dy = p.y - pY;
        let dist = Math.hypot(dx, dy);

        // Nur rendern wenn vor dem Spieler und im Sichtfeld
        if (dist > 10 && dist < 650) {
            let angleToDust = Math.atan2(dy, dx);
            let dAngle = angleToDust - pAngle;
            while (dAngle > Math.PI) dAngle -= Math.PI * 2;
            while (dAngle < -Math.PI) dAngle += Math.PI * 2;

            if (Math.abs(dAngle) < FOV / 1.3) {
                let screenX = (0.5 * (dAngle / (FOV / 2)) + 0.5) * canvas.width;
                let projectedDist = dist * Math.cos(dAngle);

                let centerIdx = Math.floor(screenX / STRIP_WIDTH);
                // Z-Buffer check (wird hinter Wänden versteckt)
                if (centerIdx >= 0 && centerIdx < NUM_RAYS && zBuffer[centerIdx] > projectedDist - 5) {

                    let spriteScale = (TILE_SIZE * canvas.height * 0.8) / projectedDist;
                    // Z-Koordinate auf Bildschirm-Y abbilden
                    let dustY = (canvas.height / 2) + (spriteScale / 2) + pitchOffset - (p.z / TILE_SIZE) * spriteScale;

                    let centerDistX = Math.abs((screenX / canvas.width) - 0.5) * NUM_RAYS;
                    let centerDistY = Math.abs(dustY - screenCenterY) / canvas.height * NUM_RAYS;
                    let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);

                    // Nur rendern wenn im runden Taschenlampenkegel
                    if (centerDist2D < flashlightRadius * 2) {
                        let distFalloff = 1 / (1 + (dist / 120) * (dist / 120)) * 2.5;
                        let intensity = Math.pow(Math.max(0, 1 - (centerDist2D / flashlightRadius)), 2.5) * distFalloff * 6.0 * flicker;

                        if (intensity > 0.05) {
                            let alpha = Math.min(1, intensity);
                            let sSize = Math.max(0.5, Math.min(8, p.size * (150 / projectedDist))); // Partikel kleiner

                            let dustGlow = ctx.createRadialGradient(screenX, dustY, 0, screenX, dustY, sSize * 2);
                            dustGlow.addColorStop(0, `rgba(200, 220, 255, ${alpha})`);
                            dustGlow.addColorStop(1, 'rgba(200, 220, 255, 0)');

                            ctx.fillStyle = dustGlow;
                            ctx.fillRect(screenX - sSize * 2, dustY - sSize * 2, sSize * 4, sSize * 4);
                        }
                    }
                }
            }
        }
    });
    ctx.globalAlpha = 1.0;

    drawFirstPersonOverlay();

    // --- FILMKORN (analoges Rauschen für mehr Unbehagen) ---
    if (gameState === 'playing') {
        if (!window._grainPattern) {
            const gcv = document.createElement('canvas');
            gcv.width = 256; gcv.height = 256;
            const gctx = gcv.getContext('2d');
            const gd = gctx.createImageData(256, 256);
            for (let i = 0; i < gd.data.length; i += 4) {
                const v = (Math.random() * 255) | 0;
                gd.data[i] = gd.data[i + 1] = gd.data[i + 2] = v;
                gd.data[i + 3] = 26; // sehr subtil
            }
            gctx.putImageData(gd, 0, 0);
            window._grainPattern = ctx.createPattern(gcv, 'repeat');
        }
        ctx.save();
        // Zufälliger Offset pro Frame lässt das Korn "leben"
        ctx.translate(-((Math.random() * 256) | 0), -((Math.random() * 256) | 0));
        ctx.fillStyle = window._grainPattern;
        ctx.fillRect(0, 0, width + 256, height + 256);
        ctx.restore();
    }

    // Treppen-Fade Animation
    if (fadeAlpha > 0.01) {
        ctx.fillStyle = `rgba(0,0,0,${fadeAlpha})`;
        ctx.fillRect(0, 0, width, height);
    }

    // Red screen effect (drawn last, on top of everything else)
    if (jumpscareEffect.currentRedIntensity > 0.001) { // Check for a small threshold
        ctx.globalAlpha = jumpscareEffect.currentRedIntensity;

        // Add a red vignette for more intensity at edges
        let redVignette = ctx.createRadialGradient(width / 2, height / 2, width / 4, width / 2, height / 2, width / 2);
        redVignette.addColorStop(0, 'rgba(255,0,0,0)');
        redVignette.addColorStop(0.7, 'rgba(150,0,0,0.2)');
        redVignette.addColorStop(1, 'rgba(139,0,0,0.8)'); // Dunkles Blutrot am Rand
        ctx.fillStyle = redVignette;
        ctx.fillRect(0, 0, width, height);
        ctx.globalAlpha = 1.0; // Reset globalAlpha
    }
}

// --- FNAF-STYLE TV-STATIC für das Hauptmenü ---
function drawMenuStatic() {
    const sc = document.getElementById('menu-static');
    if (!sc) return;
    if (sc.width !== 160) { sc.width = 160; sc.height = 90; }
    const sctx = sc.getContext('2d');
    const id = sctx.createImageData(160, 90);
    for (let i = 0; i < id.data.length; i += 4) {
        const v = (Math.random() * 255) | 0;
        id.data[i] = id.data[i + 1] = id.data[i + 2] = v;
        id.data[i + 3] = 255;
    }
    sctx.putImageData(id, 0, 0);
}

function gameLoop() {
    update();
    render();
    // TV-Rauschen im Menü animieren
    if (gameState === 'start') {
        drawMenuStatic();
    }
    // HUD Minimap jedes Frame aktualisieren
    if (gameState === 'playing') {
        drawHudMinimap();
    }
    // Große Minimap aktualisieren wenn offen
    if (minimapOpen) {
        drawMinimap();
    }
    // Interaktionstaste gilt immer nur für einen Frame
    interactPressed = false;
    requestAnimationFrame(gameLoop);
}

// --- MINIMAP FUNKTIONEN ---

function toggleMinimap() {
    minimapOpen = !minimapOpen;
    const overlay = document.getElementById('minimap-overlay');
    if (minimapOpen) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

// HUD Minimap ein-/ausblenden bei Spielstart
function showHudMinimap() {
    const hud = document.getElementById('minimap-hud');
    if (hud) hud.classList.remove('hidden-hud');
}
function hideHudMinimap() {
    const hud = document.getElementById('minimap-hud');
    if (hud) hud.classList.add('hidden-hud');
}

function updateExploration() {
    if (!exploredTiles[currentFloor]) return;
    const pgx = Math.floor(player.x / TILE_SIZE);
    const pgy = Math.floor(player.y / TILE_SIZE);
    const set = exploredTiles[currentFloor];

    for (let dy = -EXPLORE_RADIUS; dy <= EXPLORE_RADIUS; dy++) {
        for (let dx = -EXPLORE_RADIUS; dx <= EXPLORE_RADIUS; dx++) {
            // Kreisförmiger Radius
            if (dx * dx + dy * dy > EXPLORE_RADIUS * EXPLORE_RADIUS) continue;
            const tx = pgx + dx;
            const ty = pgy + dy;
            if (tx >= 0 && tx < MAP_WIDTH && ty >= 0 && ty < MAP_HEIGHT) {
                // Nur erkunden, wenn Sichtlinie besteht (nicht durch Wände)
                const key = ty * MAP_WIDTH + tx;
                if (!set.has(key)) {
                    // Einfacher Sichtlinien-Check: Prüfe ob Weg frei ist
                    let blocked = false;
                    const steps = Math.max(Math.abs(dx), Math.abs(dy));
                    if (steps > 1) {
                        for (let s = 1; s < steps; s++) {
                            const cx = pgx + Math.round(dx * s / steps);
                            const cy = pgy + Math.round(dy * s / steps);
                            if (cx >= 0 && cx < MAP_WIDTH && cy >= 0 && cy < MAP_HEIGHT) {
                                const tile = maps[currentFloor][cy][cx];
                                if ('1KSWB'.includes(tile)) {
                                    blocked = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (!blocked) {
                        set.add(key);
                    }
                }
            }
        }
    }
}

let minimapCache = document.createElement('canvas');
let minimapCacheCtx = minimapCache.getContext('2d', { alpha: false });
let minimapCacheFloor = -1;
let minimapCacheExploredSize = -1;

function updateMinimapCache() {
    if (!exploredTiles[currentFloor]) return;
    if (minimapCacheFloor === currentFloor && minimapCacheExploredSize === exploredTiles[currentFloor].size) return;
    
    minimapCacheFloor = currentFloor;
    minimapCacheExploredSize = exploredTiles[currentFloor].size;
    
    const CELL = 8;
    if (minimapCache.width !== MAP_WIDTH * CELL) {
        minimapCache.width = MAP_WIDTH * CELL;
        minimapCache.height = MAP_HEIGHT * CELL;
    }
    
    minimapCacheCtx.fillStyle = '#111115';
    minimapCacheCtx.fillRect(0, 0, minimapCache.width, minimapCache.height);
    
    const grid = maps[currentFloor];
    const explored = exploredTiles[currentFloor];
    if (!grid || !explored) return;
    
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const key = y * MAP_WIDTH + x;
            if (!explored.has(key)) continue;
            
            const tile = grid[y][x];
            let color = '';
            
            if (tile === '0') color = '#333340';
            else if (tile === '1') color = '#5c4b38';
            else if (tile === 'K') color = '#2e522e';
            else if (tile === 'S') color = '#2e2e52';
            else if (tile === 'W') color = '#522626';
            else if (tile === 'B') color = '#525226';
            else if (tile === '2') color = '#8c541d';
            else if (tile === 'U' || tile === 'D') color = '#33bbff';
            else if (tile === 'E') color = player.keys >= TOTAL_KEYS ? '#00ff00' : '#ff4444';
            else color = '#222222';
            
            minimapCacheCtx.fillStyle = color;
            minimapCacheCtx.fillRect(x * CELL, y * CELL, CELL, CELL);
        }
    }
    
    minimapCacheCtx.strokeStyle = 'rgba(255, 0, 0, 0.5)';
    minimapCacheCtx.lineWidth = 1;
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const key = y * MAP_WIDTH + x;
            if (!explored.has(key)) continue;
            
            const neighbors = [[0,-1],[0,1],[-1,0],[1,0]];
            for (const [ndx, ndy] of neighbors) {
                const nx = x + ndx;
                const ny = y + ndy;
                if (nx >= 0 && nx < MAP_WIDTH && ny >= 0 && ny < MAP_HEIGHT) {
                    if (!explored.has(ny * MAP_WIDTH + nx)) {
                        minimapCacheCtx.beginPath();
                        if (ndx === 1) { minimapCacheCtx.moveTo((x+1)*CELL, y*CELL); minimapCacheCtx.lineTo((x+1)*CELL, (y+1)*CELL); }
                        if (ndx === -1) { minimapCacheCtx.moveTo(x*CELL, y*CELL); minimapCacheCtx.lineTo(x*CELL, (y+1)*CELL); }
                        if (ndy === 1) { minimapCacheCtx.moveTo(x*CELL, (y+1)*CELL); minimapCacheCtx.lineTo((x+1)*CELL, (y+1)*CELL); }
                        if (ndy === -1) { minimapCacheCtx.moveTo(x*CELL, y*CELL); minimapCacheCtx.lineTo((x+1)*CELL, y*CELL); }
                        minimapCacheCtx.stroke();
                    }
                }
            }
        }
    }
}

// --- GROßE MINIMAP (Overlay, volle Karte) ---
function drawMinimap() {
    updateMinimapCache();
    
    const mmCanvas = document.getElementById('minimapCanvas');
    if (!mmCanvas) return;
    const mmCtx = mmCanvas.getContext('2d', { alpha: false });

    if (mmCanvas.width !== minimapCache.width) {
        mmCanvas.width = minimapCache.width;
        mmCanvas.height = minimapCache.height;
    }

    mmCtx.drawImage(minimapCache, 0, 0);

    const CELL = 8;
    const explored = exploredTiles[currentFloor];
    if (!explored) return;

    keysData.forEach(k => {
        if (k.collected || k.floor !== currentFloor) return;
        const kx = Math.floor(k.x / TILE_SIZE);
        const ky = Math.floor(k.y / TILE_SIZE);
        if (!explored.has(ky * MAP_WIDTH + kx)) return;

        const pulse = Math.sin(Date.now() / 200) * 0.3 + 0.7;
        mmCtx.fillStyle = `rgba(255, 215, 0, ${pulse})`;
        mmCtx.shadowColor = '#ffd700';
        mmCtx.shadowBlur = 6;
        mmCtx.beginPath();
        mmCtx.arc(kx * CELL + CELL / 2, ky * CELL + CELL / 2, CELL * 0.5, 0, Math.PI * 2);
        mmCtx.fill();
        mmCtx.shadowBlur = 0;
    });

    const playerScreenX = (player.x / TILE_SIZE) * CELL;
    const playerScreenY = (player.y / TILE_SIZE) * CELL;

    const arrowLen = CELL * 2;
    const arrowAngle = player.angle;
    mmCtx.fillStyle = 'rgba(0, 255, 0, 0.6)';
    mmCtx.beginPath();
    mmCtx.moveTo(playerScreenX + Math.cos(arrowAngle) * arrowLen, playerScreenY + Math.sin(arrowAngle) * arrowLen);
    mmCtx.lineTo(playerScreenX + Math.cos(arrowAngle + 2.5) * arrowLen * 0.5, playerScreenY + Math.sin(arrowAngle + 2.5) * arrowLen * 0.5);
    mmCtx.lineTo(playerScreenX + Math.cos(arrowAngle - 2.5) * arrowLen * 0.5, playerScreenY + Math.sin(arrowAngle - 2.5) * arrowLen * 0.5);
    mmCtx.closePath();
    mmCtx.fill();

    const playerPulse = Math.sin(Date.now() / 250) * 0.3 + 0.7;
    mmCtx.fillStyle = `rgba(0, 255, 0, ${playerPulse})`;
    mmCtx.shadowColor = '#00ff00';
    mmCtx.shadowBlur = 10;
    mmCtx.beginPath();
    mmCtx.arc(playerScreenX, playerScreenY, CELL * 0.7, 0, Math.PI * 2);
    mmCtx.fill();
    mmCtx.shadowBlur = 0;

    const vigGrad = mmCtx.createRadialGradient(
        playerScreenX, playerScreenY, mmCanvas.width * 0.15,
        playerScreenX, playerScreenY, mmCanvas.width * 0.55
    );
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.7, 'rgba(0,0,0,0.2)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    mmCtx.fillStyle = vigGrad;
    mmCtx.fillRect(0, 0, mmCanvas.width, mmCanvas.height);

    const titleEl = document.getElementById('minimap-title');
    if (titleEl) {
        const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
        let name = floorNames[currentFloor] || (currentFloor + ". Floor");
        if (currentFloor === maps.length - 1) name = "Attic";
        titleEl.textContent = name.toUpperCase();
    }
}

// --- KLEINE HUD MINIMAP (dauerhaft rechts unten, flüssig zentriert) ---
const HUD_SIZE = 240; 
const HUD_CELL = 8;   

function drawHudMinimap() {
    updateMinimapCache();

    const hudCanvas = document.getElementById('minimapHudCanvas');
    if (!hudCanvas) return;
    const hCtx = hudCanvas.getContext('2d', { alpha: false });

    if (hudCanvas.width !== HUD_SIZE) {
        hudCanvas.width = HUD_SIZE;
        hudCanvas.height = HUD_SIZE;
    }

    const explored = exploredTiles[currentFloor];
    if (!explored) return;

    // Weiche Kamera-Bewegung (Sub-Pixel genau)
    const pxInCells = player.x / TILE_SIZE;
    const pyInCells = player.y / TILE_SIZE;
    
    const viewHalf = HUD_SIZE / 2;
    const cacheX = pxInCells * HUD_CELL - viewHalf;
    const cacheY = pyInCells * HUD_CELL - viewHalf;

    hCtx.fillStyle = '#060608';
    hCtx.fillRect(0, 0, HUD_SIZE, HUD_SIZE);

    hCtx.save();
    hCtx.translate(-cacheX, -cacheY);
    hCtx.drawImage(minimapCache, 0, 0);

    // Schlüssel zeichnen
    keysData.forEach(k => {
        if (k.collected || k.floor !== currentFloor) return;
        const kx = Math.floor(k.x / TILE_SIZE);
        const ky = Math.floor(k.y / TILE_SIZE);
        if (!explored.has(ky * MAP_WIDTH + kx)) return;

        const pulse = Math.sin(Date.now() / 200) * 0.3 + 0.7;
        hCtx.fillStyle = `rgba(255, 215, 0, ${pulse})`;
        hCtx.shadowColor = '#ffd700';
        hCtx.shadowBlur = 4;
        hCtx.beginPath();
        hCtx.arc(kx * HUD_CELL + HUD_CELL / 2, ky * HUD_CELL + HUD_CELL / 2, HUD_CELL * 0.45, 0, Math.PI * 2);
        hCtx.fill();
        hCtx.shadowBlur = 0;
    });

    hCtx.restore();

    // Spieler immer exakt in der Mitte
    const playerHudX = viewHalf;
    const playerHudY = viewHalf;

    const arrowLen = HUD_CELL * 1.5;
    const angle = player.angle;
    hCtx.fillStyle = 'rgba(0, 255, 0, 0.7)';
    hCtx.beginPath();
    hCtx.moveTo(playerHudX + Math.cos(angle) * arrowLen, playerHudY + Math.sin(angle) * arrowLen);
    hCtx.lineTo(playerHudX + Math.cos(angle + 2.5) * arrowLen * 0.4, playerHudY + Math.sin(angle + 2.5) * arrowLen * 0.4);
    hCtx.lineTo(playerHudX + Math.cos(angle - 2.5) * arrowLen * 0.4, playerHudY + Math.sin(angle - 2.5) * arrowLen * 0.4);
    hCtx.closePath();
    hCtx.fill();

    const pp = Math.sin(Date.now() / 250) * 0.3 + 0.7;
    hCtx.fillStyle = `rgba(0, 255, 0, ${pp})`;
    hCtx.shadowColor = '#00ff00';
    hCtx.shadowBlur = 6;
    hCtx.beginPath();
    hCtx.arc(playerHudX, playerHudY, HUD_CELL * 0.5, 0, Math.PI * 2);
    hCtx.fill();
    hCtx.shadowBlur = 0;

    // Runde Schatten-Vignette
    const vigGrad = hCtx.createRadialGradient(viewHalf, viewHalf, HUD_SIZE * 0.15, viewHalf, viewHalf, HUD_SIZE * 0.5);
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.6, 'rgba(0,0,0,0.15)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    hCtx.fillStyle = vigGrad;
    hCtx.fillRect(0, 0, HUD_SIZE, HUD_SIZE);

    const floorEl = document.getElementById('minimap-hud-floor');
    if (floorEl) {
        const floorNames = ["GF", "1st", "2nd", "3rd", "Attic"];
        let name = floorNames[currentFloor] || (currentFloor + "th");
        if (currentFloor === maps.length - 1) name = "Attic";
        floorEl.textContent = name;
    }
}

gameLoop();