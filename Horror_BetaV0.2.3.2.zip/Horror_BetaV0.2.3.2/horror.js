// ==========================================
// GAME CONFIGURATION
// ==========================================
const CURRENT_VERSION = "0.2.3.2";
const DOWNLOAD_URL = "https://github.com/TOBI0458/Horror-game"; // Fallback, falls version.json keinen download_url hat
// "HEAD" zeigt immer auf den Default-Branch — funktioniert also auch,
// wenn der Branch nicht "main" heißt (z.B. "V0.2.1.1")
const VERSION_CHECK_URL = "https://raw.githubusercontent.com/TOBI0458/Horror-game/HEAD/version.json";

// Hier kannst du neue Updates einfach eintragen:
// Layout: NEW THINGS, CHANGES, FIXES, UPCOMING
const CHANGELOG_DATA = [
    {
        version: "0.2.3.2",
        changes: [
            "<span class='log-tag new'>NEW</span> Hide in closets! While the monster is chasing, a tense A/D timing minigame decides your fate — miss 3 times and it drags you out (it stares through the door crack the whole time)",
            "<span class='log-tag new'>NEW</span> Furniture in the rooms: tables, crates, barrels, bookshelves and chairs make the house feel lived-in",
            "<span class='log-tag fix'>FIX</span> Corpses no longer turn transparent when you look up or down",
            "<span class='log-tag fix'>FIX</span> Changelog has a proper X button (top-right) and closes when you click outside it",
            "<span class='log-tag change'>CHG</span> Fewer connecting doors for clearer orientation",
            "<span class='log-tag change'>CHG</span> Reduced film-grain noise so textures look cleaner, less 'pixelated'",
            "<span class='log-tag new'>NEW</span> Complex new floor layouts: a corridor network with side passages, varied room sizes and pillars",
            "<span class='log-tag new'>NEW</span> The exit is now a glowing white door that only appears at a random spot once ALL keys are collected",
            "<span class='log-tag new'>NEW</span> Realistic wooden doors that swing open on their hinge — opening from the knob inwards",
            "<span class='log-tag fix'>FIX</span> Randomized layouts now guarantee escape routes: a monster can never block the only way to a key or the stairs",
            "<span class='log-tag change'>CHG</span> Map (M) is more compact and opens with a zoom animation",
            "<span class='log-tag change'>CHG</span> The map now works like a scanner: it only reveals what you can actually see and never scans through walls",
            "<span class='log-tag new'>NEW</span> The monster now has a real walk cycle — it stomps along the floor instead of floating",
            "<span class='log-tag new'>NEW</span> Smarter monster: it now hunts you with real pathfinding, stalking around walls instead of bumping into them",
            "<span class='log-tag fix'>FIX</span> Fixed the bug where walls/textures turned see-through — walls are now always solid, darkness no longer makes them transparent",
            "<span class='log-tag change'>CHG</span> More realistic teeth: curved, stained fangs with an enamel sheen and a fleshy gum line",
            "<span class='log-tag change'>CHG</span> Scarier atmosphere: cinematic vignette that pulses dark red when the monster closes in",
            "<span class='log-tag change'>CHG</span> Tighter, smaller map scanner — you reveal less of the building, so it stays claustrophobic",
            "<span class='log-tag change'>CHG</span> Main menu now shows the lit hallway and its doors, with the figure lurking at the dark far end",
            "<span class='log-tag change'>CHG</span> Stairs are now real 3D objects rising from the floor (lit treads, shadowed risers, carpet runner) instead of a flat textured wall",
            "<span class='log-tag new'>NEW</span> Corpses everywhere: torn-apart bodies and skeletons lying flat in random rooms (now properly on the ground and smaller)",
            "<span class='log-tag fix'>FIX</span> The main-menu hallway with its doors is now clearly visible, the monster waits at the far end",
            "<span class='log-tag fix'>FIX</span> Performance pass for a steady 60 FPS: faster auto-resolution, fewer dust particles",
            "<span class='log-tag change'>CHG</span> Grimier textures: creeping moss and blood now spread across walls, floors and ceilings",
            "<span class='log-tag change'>CHG</span> Fully procedural art — removed the last image files (treppe.png, tuer.png) for faster loading",
            "<span class='log-tag change'>CHG</span> Sharper, smoother graphics: higher render resolution with soft upscaling instead of the blocky look",
            "<span class='log-tag change'>CHG</span> More detailed walls: water streaks, creeping moss and lime stains for grime and depth",
            "<span class='log-tag fix'>FIX</span> A flickering flashlight now darkens the WHOLE scene evenly — walls never turn see-through anymore",
            "<span class='log-tag change'>CHG</span> Performance: adaptive resolution scales from crisp on strong PCs down to smooth on low-end laptops",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.3.1",
        changes: [
            "<span class='log-tag change'>CHG</span> The jumpscare now shows the real ingame monster lunging at you (motion blur, VHS glitches, shock flashes)",
            "<span class='log-tag change'>CHG</span> Realistic death screen: the actual monster stares at you in a dying flashlight beam",
            "<span class='log-tag new'>NEW</span> Modern victory screen with run statistics",
            "<span class='log-tag new'>NEW</span> Redesigned main menu: keyboard navigation, controls list, red accents",
            "<span class='log-tag fix'>FIX</span> Monsters now roam towards you instead of getting lost on the huge map",
            "<span class='log-tag fix'>FIX</span> Jumpscare overlay was invisible due to missing styles",
            "<span class='log-tag fix'>FIX</span> Changelog shows all versions, no more HUD bleeding into menus and end screens",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.3",
        changes: [
            "<span class='log-tag new'>NEW</span> Real recorded sounds from the web (thunder, growls, screams, creaking doors, howling wind)",
            "<span class='log-tag change'>CHG</span> Completely redesigned monster: pale skin, visible ribs, unhinged jaw, jerky twitching",
            "<span class='log-tag new'>NEW</span> FNAF-style main menu: TV static, scanlines, flickering title and a '>>' selection list",
            "<span class='log-tag new'>NEW</span> Modern, minimalist death screen with run statistics",
            "<span class='log-tag change'>CHG</span> More realistic death portrait: skin pores, veins, corpse blotches, asymmetric skull, wet teeth",
            "<span class='log-tag new'>NEW</span> You can faintly hear the monster roaming in the distance (stereo direction + muffled by distance)",
            "<span class='log-tag change'>CHG</span> Scarier layered jumpscare scream with sub-bass impact",
            "<span class='log-tag change'>CHG</span> Wind is much quieter, whispering sound removed",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.2",
        changes: [
            "<span class='log-tag new'>NEW</span> Real photo textures (bricks & wood) loaded from the web, with horror post-processing",
            "<span class='log-tag new'>NEW</span> Full sound overhaul: thunder, ambient drone, monster growls, heartbeat, whispers, door creaks, jumpscare scream",
            "<span class='log-tag fix'>FIX</span> Stairs finally work: press E once and you climb automatically (all difficulties are finishable now)",
            "<span class='log-tag change'>CHG</span> Scarier atmosphere: film grain, flashlight blackouts, exhausted breathing",
            "<strong>Upcoming:</strong>",
            "• More monster types",
            "• And much more....."
        ]
    },
    {
        version: "0.2.1.1",
        changes: [
            "<span class='log-tag change'>CHG</span> Version update to 0.2.1.1",
            "<span class='log-tag fix'>FIX</span> Corrected vertical look sensitivity and light synchronization",
            "<span class='log-tag new'>NEW</span> Sounds for the ground.",
            "<span class='log-tag fix'>FIX</span> Fixed bugs.",
            "<strong>Upcoming:</strong>",
            "• Fixing Stairs (Only Easy Gamemode is finishable)",
            "• More sounds",
            "• And much more....."
        ]
    },
    {
        version: "0.2.1",
        changes: [
            "<span class='log-tag new'>NEW</span> Integrated an 'Update Available' notification system",
            "<span class='log-tag new'>NEW</span> Added a dedicated, scrollable Changelog modal",
            "<span class='log-tag change'>CHG</span> Centralized version management and UI sync",
            "<span class='log-tag change'>CHG</span> Enhanced legibility with high-contrast text shadows",
            "<span class='log-tag change'>CHG</span> Migrated the entire interface to English",
            "<span class='log-tag change'>CHG</span> Adjusted color palette for better menu visibility",
            "<span class='log-tag fix'>FIX</span> Resolved UI listener lockout when skipping intro"
        ]
    },
    {
        version: "0.2.0",
        changes: [
            "Initial Beta release",
            "Added monster AI and floor generation",
            "Implemented key collection mechanics"
        ]
    },
];

const canvas = document.getElementById('gameCanvas');
const ctx = canvas ? canvas.getContext('2d', { alpha: false }) : null;

if (!canvas)
{
    console.error("Fehler: 'gameCanvas' nicht im HTML gefunden! Das Spiel kann nicht starten.");
}

let width, height;

let cachedScreenImg = null;
let cachedPixels = null;
let zBuffer = null;

window.addEventListener('load', () =>
{
    // Sync the top-right version display with the actual version variable
    const versionDisplay = document.getElementById('game-version');
    if (versionDisplay)
    {
        versionDisplay.textContent = 'V' + CURRENT_VERSION;
    }

    const intro = document.getElementById('intro-screen');
    const introText = document.querySelector('#intro-screen h2');

    // Prüfen, ob das Intro in dieser Sitzung bereits gezeigt wurde
    if (sessionStorage.getItem('introPlayed'))
    {
        if (intro)
        {
            intro.classList.add('hidden');
        }
    }
    else
    {
        // Starte die Text-Animation erst, wenn alles geladen ist
        if (introText)
        {
            introText.classList.add('start-anim');
        }

        setTimeout(() =>
        {
            if (intro)
            {
                intro.style.opacity = '0';
                setTimeout(() =>
                {
                    intro.classList.add('hidden');
                    // Marker setzen, damit es beim nächsten Reload übersprungen wird
                    sessionStorage.setItem('introPlayed', 'true');
                }, 1500);
            }
        }, 4000); 
    }

    // Changelog Initialisierung
    const trigger = document.getElementById('changelog-trigger');
    const modal = document.getElementById('changelog-modal');
    const closeBtn = document.getElementById('changelog-close-btn');
    const list = document.getElementById('changelog-list');

    // Update Button Logic
    const updateBtn = document.getElementById('update-btn');
    console.log("Update-Button im HTML gefunden?", updateBtn ? "Ja" : "Nein, ID prüfen!");

    // Vergleicht Versionen zahlenweise: "0.2.10" ist neuer als "0.2.3"
    function isNewerVersion(remote, local) {
        const r = String(remote).split('.').map(Number);
        const l = String(local).split('.').map(Number);
        for (let i = 0; i < Math.max(r.length, l.length); i++) {
            const a = r[i] || 0, b = l[i] || 0;
            if (a !== b) return a > b;
        }
        return false;
    }

    if (updateBtn) {
        // Zeitstempel + no-store, damit nicht eine alte gecachte version.json geprüft wird
        fetch(VERSION_CHECK_URL + '?t=' + Date.now(), { cache: 'no-store' })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`version.json nicht gefunden (${response.status})! URL: ${VERSION_CHECK_URL}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("Update Check:", { lokal: CURRENT_VERSION, remote: data.version });

                if (data.version && isNewerVersion(data.version, CURRENT_VERSION)) {
                    console.log("Neue Version gefunden. Button wird eingeblendet.");
                    updateBtn.textContent = `UPDATE AVAILABLE (V${data.version})`;
                    updateBtn.classList.remove('hidden');
                    updateBtn.style.display = "block"; // Sicherstellen, dass er nicht per CSS versteckt bleibt
                    updateBtn.addEventListener('click', () => {
                        let msg = `A new version (${data.version}) is available. Download now?`;
                        if (Array.isArray(data.changelog) && data.changelog.length) {
                            msg += '\n\nWhat\'s new:\n- ' + data.changelog.join('\n- ');
                        }
                        if (confirm(msg)) {
                            window.open(data.download_url || DOWNLOAD_URL, '_blank');
                        }
                    });
                } else {
                    console.log("Kein Update nötig — Version ist aktuell.");
                }
            })
            .catch(err => console.error("Fehler beim Update-Check:", err.message));
    }

    if (trigger && modal && closeBtn && list)
    {
        trigger.addEventListener('click', () =>
        {
            // Alle Versionen anzeigen — das Modal heißt "Show Changelogs" und ist scrollbar
            list.innerHTML = CHANGELOG_DATA
                .map(entry =>
                {
                    return `
                    <div class="changelog-entry">
                        <h3>Version ${entry.version}</h3>
                        <ul>${entry.changes.map(c => `<li>${c}</li>`).join('')}</ul>
                    </div>
                `;
                }).join('');
            modal.classList.remove('hidden');
        });
        closeBtn.addEventListener('click', () => modal.classList.add('hidden'));
        // X oben rechts schließt ebenfalls; Klick auf den dunklen Hintergrund auch
        const xBtn = document.getElementById('changelog-x');
        if (xBtn) xBtn.addEventListener('click', () => modal.classList.add('hidden'));
        modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.add('hidden'); });
    }
});

// Adaptive Auflösung: startet bei halber Auflösung (flüssig auch auf schwachen
// Geräten). Der Performance-Monitor in gameLoop() regelt den Teiler dann live
// nach: auf starken PCs schärfer (bis 1.25), auf langsamen gröber (bis 4),
// Ziel sind konstant ~60 FPS.
let renderScale = 2;

function resize()
{
    if (!canvas) return;
    width = Math.floor(window.innerWidth / renderScale);
    height = Math.floor(window.innerHeight / renderScale);
    canvas.style.width = window.innerWidth + 'px';
    canvas.style.height = window.innerHeight + 'px';
    canvas.width = width;
    canvas.height = height;
}
window.addEventListener('resize', resize);
resize();

// --- TEXTUR LADEN (OPTIMIERT) ---
function loadExternalImage(url)
{
    const img = new Image();
    img.crossOrigin = "anonymous"; // Erlaubt die Verwendung auf dem Canvas (CORS)
    img.src = url;
    return img;
}

// --- PROZEDURAL GENERIERTE TEXTUREN (keine externen Abhängigkeiten) ---

// Gemeinsame Hilfsfunktionen für Textur-Generierung
function noise2D(x, y)
{
    const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
    return n - Math.floor(n);
}

function smoothNoise(x, y)
{
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const fx = x - ix;
    const fy = y - iy;
    // Smoothstep
    const sfx = fx * fx * (3 - 2 * fx);
    const sfy = fy * fy * (3 - 2 * fy);
    const a = noise2D(ix, iy);
    const b = noise2D(ix + 1, iy);
    const cc = noise2D(ix, iy + 1);
    const d = noise2D(ix + 1, iy + 1);
    return a + (b - a) * sfx + (cc - a) * sfy + (a - b - cc + d) * sfx * sfy;
}

function fbm(x, y, octaves)
{
    let val = 0, amp = 0.5, freq = 1;
    for (let i = 0; i < octaves; i++)
    {
        val += amp * smoothNoise(x * freq, y * freq);
        amp *= 0.5;
        freq *= 2;
    }
    return val;
}

function makeSeededRandom(startSeed)
{
    let s = startSeed;
    return function ()
    {
        s = (s * 16807 + 0) % 2147483647;
        return (s - 1) / 2147483646;
    };
}

// --- 1. WAND-TEXTUR: Alte Steinmauer / rissiger Putz ---
function createWallTexture()
{
    const size = 1024;
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const c = cv.getContext('2d');
    const imgData = c.createImageData(size, size);
    const data = imgData.data;
    const rand = makeSeededRandom(54321);

    // Ziegelmuster-Parameter
    const brickH = 32, brickW = 64, mortarSize = 3;

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Welcher Ziegel?
            const row = Math.floor(py / brickH);
            const offset = (row % 2 === 0) ? 0 : brickW / 2;
            const bx = ((px + offset) % brickW);
            const by = py % brickH;

            // Fuge?
            const isMortar = bx < mortarSize || by < mortarSize;

            let r, g, b;
            if (isMortar)
            {
                // Dunkelgrauer Mörtel
                const n = noise2D(px * 0.1, py * 0.1) * 15;
                r = 25 + n; g = 22 + n; b = 20 + n;
            }
            else
            {
                // Stein-Basis: dunkler Grau-Braun
                const brickSeed = row * 37 + Math.floor((px + offset) / brickW) * 53;
                const brickVariation = noise2D(brickSeed, 0) * 30 - 15;

                const baseR = 55 + brickVariation;
                const baseG = 48 + brickVariation * 0.8;
                const baseB = 42 + brickVariation * 0.5;

                // Stein-Textur
                const stoneTex = fbm(px * 0.03, py * 0.03, 4) * 20 - 10;
                // Feinstruktur
                const micro = (noise2D(px * 0.3, py * 0.3) - 0.5) * 12;

                r = baseR + stoneTex + micro;
                g = baseG + stoneTex * 0.8 + micro * 0.8;
                b = baseB + stoneTex * 0.5 + micro * 0.6;

                // Kanten der Ziegel: leicht dunkler
                const edgeDist = Math.min(bx - mortarSize, brickW - bx, by - mortarSize, brickH - by);
                if (edgeDist < 4)
                {
                    const edgeDarken = (1 - edgeDist / 4) * 0.2;
                    r *= (1 - edgeDarken);
                    g *= (1 - edgeDarken);
                    b *= (1 - edgeDarken);
                }

                // Feuchtigkeitsflecken
                const damp = fbm(px * 0.005 + 3.3, py * 0.008 + 1.7, 3);
                if (damp > 0.6)
                {
                    const dampAmt = (damp - 0.6) * 2;
                    r *= (1 - dampAmt * 0.3);
                    g *= (1 - dampAmt * 0.2);
                    b *= (1 - dampAmt * 0.1);
                }
            }

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);

    // Risse
    c.globalCompositeOperation = 'multiply';
    for (let crack = 0; crack < 5; crack++)
    {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 15; s++)
        {
            cx += (rand() - 0.5) * 20;
            cy += rand() * 15 + 3;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(5, 3, 2, ${0.4 + rand() * 0.3})`;
        c.lineWidth = 0.5 + rand() * 1;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';

    // --- ZUSÄTZLICHE DETAILS (einmalig bei Ladezeit, kein Laufzeit-Kosten) ---
    // Vertikale Wasserläufer / dunkle Schlieren, die die Wand herunterlaufen
    c.globalCompositeOperation = 'multiply';
    for (let s = 0; s < 16; s++) {
        const x0 = rand() * size;
        const w0 = 5 + rand() * 26;
        const grad = c.createLinearGradient(x0, 0, x0, size);
        grad.addColorStop(0, 'rgba(18,14,9,0)');
        grad.addColorStop(0.25, `rgba(16,12,7,${0.22 + rand() * 0.32})`);
        grad.addColorStop(1, 'rgba(9,7,4,0.05)');
        c.fillStyle = grad;
        c.fillRect(x0, rand() * size * 0.3, w0, size);
    }
    c.globalCompositeOperation = 'source-over';

    // Schimmel-/Moosflecken (dunkelgrün), bevorzugt im unteren Wandbereich
    for (let s = 0; s < 32; s++) {
        const mx = rand() * size, my = size * 0.45 + rand() * size * 0.55;
        const mr = 7 + rand() * 42;
        const mg = c.createRadialGradient(mx, my, 0, mx, my, mr);
        mg.addColorStop(0, `rgba(${20 + rand() * 16 | 0}, ${30 + rand() * 26 | 0}, ${14 + rand() * 10 | 0}, ${0.10 + rand() * 0.18})`);
        mg.addColorStop(1, 'rgba(20,30,15,0)');
        c.fillStyle = mg;
        c.beginPath(); c.arc(mx, my, mr, 0, Math.PI * 2); c.fill();
    }

    // Helle Kalk-Ausblühungen (subtile Aufhellungen für mehr Tiefe)
    c.globalCompositeOperation = 'screen';
    for (let s = 0; s < 20; s++) {
        const mx = rand() * size, my = rand() * size, mr = 6 + rand() * 24;
        const mg = c.createRadialGradient(mx, my, 0, mx, my, mr);
        mg.addColorStop(0, `rgba(120,115,102,${0.05 + rand() * 0.09})`);
        mg.addColorStop(1, 'rgba(120,115,102,0)');
        c.fillStyle = mg;
        c.beginPath(); c.arc(mx, my, mr, 0, Math.PI * 2); c.fill();
    }
    c.globalCompositeOperation = 'source-over';

    return cv;
}

// --- 2. DECKEN-TEXTUR: Alter Putz mit Wasserflecken und Schimmel ---
function createCeilingTexture()
{
    const size = 1024;
    const cv = document.createElement('canvas');
    cv.width = size; cv.height = size;
    const c = cv.getContext('2d');
    const imgData = c.createImageData(size, size);
    const data = imgData.data;
    const rand = makeSeededRandom(99887);

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Basis: schmutzig-weißer Putz
            const baseVal = 38;
            const plasterNoise = fbm(px * 0.02, py * 0.02, 4) * 15 - 7;
            const micro = (noise2D(px * 0.2, py * 0.2) - 0.5) * 8;

            let r = baseVal + plasterNoise + micro;
            let g = baseVal + plasterNoise * 0.95 + micro * 0.9;
            let b = baseVal + plasterNoise * 0.85 + micro * 0.85;

            // Wasserflecken (gelblich-braun)
            const water = fbm(px * 0.006 + 7.7, py * 0.006 + 2.3, 4);
            if (water > 0.55)
            {
                const wAmt = (water - 0.55) * 3;
                r += wAmt * 18;
                g += wAmt * 10;
                b -= wAmt * 5;
            }

            // Schimmelflecken (dunkelgrün/schwarz)
            const mold = fbm(px * 0.008 + 44.1, py * 0.008 + 22.5, 3);
            if (mold > 0.68)
            {
                const mAmt = (mold - 0.68) * 4;
                r *= (1 - mAmt * 0.6);
                g *= (1 - mAmt * 0.3);
                b *= (1 - mAmt * 0.5);
                g += mAmt * 4; // leichter Grünstich
            }

            // Putzrisse / Abblättern
            const crackNoise = fbm(px * 0.015 + 11.1, py * 0.015 + 33.3, 5);
            if (crackNoise > 0.72)
            {
                const cAmt = (crackNoise - 0.72) * 5;
                r -= cAmt * 12;
                g -= cAmt * 12;
                b -= cAmt * 10;
            }

            // Spinnweben-Simulation (helle Streifen)
            const web = Math.sin(px * 0.02 + py * 0.015 + noise2D(px * 0.005, py * 0.005) * 8);
            if (Math.abs(web) > 0.98)
            {
                r += 8; g += 8; b += 8;
            }

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);
    return cv;
}

// --- 3. BODEN-TEXTUR: Alte Holzdielen ---
function createDetailedFloorTexture()
{
    const size = 1024;
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = size;
    floorCanvas.height = size;
    const c = floorCanvas.getContext('2d');
    const rand = makeSeededRandom(12345);

    // Basis-Holzfarbe (dunkles, altes Holz)
    const baseR = 45, baseG = 30, baseB = 18;

    // Dielen-Layout
    const plankWidth = 50 + (rand() * 20 | 0);
    const numPlanks = Math.ceil(size / plankWidth) + 1;
    const planks = [];
    let currentX = 0;
    for (let i = 0; i < numPlanks; i++)
    {
        const w = plankWidth + (rand() * 16 - 8 | 0);
        planks.push({ x: currentX, w: w, hue: rand() * 18 - 9, brightness: rand() * 22 - 11, grainSeed: rand() * 1000 });
        currentX += w;
    }

    const imgData = c.createImageData(size, size);
    const data = imgData.data;

    for (let py = 0; py < size; py++)
    {
        for (let px = 0; px < size; px++)
        {
            const idx = (py * size + px) * 4;

            // Welche Diele?
            let plank = planks[0], plankIdx = 0;
            for (let i = 0; i < planks.length; i++)
            {
                if (px >= planks[i].x && px < planks[i].x + planks[i].w)
                {
                    plank = planks[i]; plankIdx = i; break;
                }
            }

            const localX = px - plank.x;
            const plankEdgeDist = Math.min(localX, plank.w - localX);

            // Holzmaserung
            const grainY = py * 0.02 + plank.grainSeed;
            const grain = Math.sin(grainY * 3.5 + smoothNoise(px * 0.01, py * 0.04) * 5) * 0.5 + 0.5;
            const grainFine = Math.sin(grainY * 12 + noise2D(px * 0.02, py * 0.05) * 3) * 0.12;

            // Astlöcher (mehr als vorher)
            let knotDark = 0;
            const knots = [
                { cx: (plank.x + plank.w * 0.3) % size, cy: (150 + plankIdx * 317) % size },
                { cx: (plank.x + plank.w * 0.7) % size, cy: (400 + plankIdx * 251) % size },
                { cx: (plank.x + plank.w * 0.5) % size, cy: (50 + plankIdx * 113) % size },
                { cx: (plank.x + plank.w * 0.2) % size, cy: (280 + plankIdx * 401) % size }
            ];
            for (let k of knots)
            {
                const kd = Math.hypot(px - k.cx, py - k.cy);
                if (kd < 14) knotDark = Math.max(knotDark, (1 - kd / 14) * 0.5 + Math.sin(kd * 0.9) * 0.1);
            }

            let r = baseR + plank.hue + plank.brightness;
            let g = baseG + plank.hue * 0.5 + plank.brightness * 0.7;
            let b = baseB + plank.brightness * 0.3;

            // Maserung
            const ge = grain * 14 + grainFine * 9;
            r += ge; g += ge * 0.7; b += ge * 0.3;

            // Knoten
            r *= (1 - knotDark); g *= (1 - knotDark); b *= (1 - knotDark);

            // Fugen
            if (plankEdgeDist <= 2)
            {
                const f = plankEdgeDist / 2 * 0.3 + 0.05;
                r *= f; g *= f; b *= f;
            }

            // Abnutzung
            const age = fbm(px * 0.01, py * 0.01, 3);
            const af = 1 - age * 0.22;
            r *= af; g *= af; b *= af;

            // Dreck
            const stain = fbm(px * 0.005 + 5.7, py * 0.005 + 3.2, 3);
            if (stain > 0.6)
            {
                const si = (stain - 0.6) * 3;
                r *= (1 - si * 0.5); g *= (1 - si * 0.45); b *= (1 - si * 0.3);
            }

            // Wasser/Feuchtigkeitspützen
            const water = fbm(px * 0.007 + 12.3, py * 0.007 + 45.6, 3);
            if (water > 0.65)
            {
                const wi = (water - 0.65) * 4;
                r *= (1 - wi * 0.7);
                g *= (1 - wi * 0.7);
                b *= (1 - wi * 0.6); // Leicht bläuliche/dunkle Spiegelung
            }

            // Schimmel (grünlich) in den Ecken oder feuchten Stellen
            const mold = fbm(px * 0.01 + 88.2, py * 0.01 + 22.1, 4);
            if (mold > 0.7)
            {
                const mi = (mold - 0.7) * 5;
                r *= (1 - mi * 0.8);
                g *= (1 - mi * 0.3); // Erhält mehr Grün
                b *= (1 - mi * 0.8);
                g += mi * 18; // Grünstich hinzufügen
            }

            // Blut-Suggestion (gewischt)
            const blood = fbm(px * 0.006 + 99.1, py * 0.006 + 77.3, 3);
            if (blood > 0.78)
            {
                const bi = (blood - 0.78) * 5;
                r = r * (1 - bi * 0.3) + 40 * bi;
                g *= (1 - bi * 0.7); b *= (1 - bi * 0.6);
            }

            // Nägel und Rost
            const nailY = py % 120;
            if (nailY < 5)
            {
                const n1 = Math.hypot(px - (plank.x + plank.w * 0.15), nailY - 2.5);
                const n2 = Math.hypot(px - (plank.x + plank.w * 0.85), nailY - 2.5);
                const nd = Math.min(n1, n2);
                if (nd < 2.5) { const ns = 0.2 + nd / 2.5 * 0.2; r *= ns; g *= ns; b *= ns; }
            }
            else if (nailY >= 5 && nailY < 20)
            {
                // Rost läuft von den Nägeln herunter
                const rx_dist = Math.min(Math.abs(px - (plank.x + plank.w * 0.15)), Math.abs(px - (plank.x + plank.w * 0.85)));
                if (rx_dist < 3)
                {
                    const rust_amt = (1 - rx_dist / 3) * (1 - (nailY - 5) / 15) * (noise2D(px * 0.1, py * 0.1) * 0.5 + 0.5);
                    r = r * (1 - rust_amt * 0.4) + 50 * rust_amt; // Rost-Rot/Orange
                    g = g * (1 - rust_amt * 0.5) + 20 * rust_amt;
                    b *= (1 - rust_amt * 0.8);
                }
            }

            // Mikro-Rauschen
            const mn = (noise2D(px * 0.5, py * 0.5) - 0.5) * 7;
            r += mn; g += mn * 0.8; b += mn * 0.5;

            data[idx] = Math.max(0, Math.min(255, r | 0));
            data[idx + 1] = Math.max(0, Math.min(255, g | 0));
            data[idx + 2] = Math.max(0, Math.min(255, b | 0));
            data[idx + 3] = 255;
        }
    }
    c.putImageData(imgData, 0, 0);

    // --- Post-Processing Details auf dem Canvas ---

    // 1. Risse (Längs)
    c.globalCompositeOperation = 'multiply';
    for (let crack = 0; crack < 10; crack++)
    { // Mehr Risse
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 12 + (rand() * 10 | 0); s++)
        {
            cx += (rand() - 0.5) * 12; cy += rand() * 18 + 3;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(10, 5, 2, ${0.3 + rand() * 0.35})`;
        c.lineWidth = 0.4 + rand() * 1.2;
        c.stroke();
    }

    // 2. Horizontale Kratzer (Quer zu den Dielen)
    for (let i = 0; i < 25; i++)
    {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        let scratchLength = 2 + (rand() * 4 | 0);
        for (let j = 0; j < scratchLength; j++)
        {
            cx += (rand() - 0.5) * 25 + 10; // Querbewegung
            cy += (rand() - 0.5) * 4;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(8, 4, 2, ${0.4 + rand() * 0.5})`;
        c.lineWidth = 0.3 + rand() * 0.8;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';

    // 3. Frische Blutstropfen und Spritzer
    c.fillStyle = 'rgba(80, 0, 0, 0.85)';
    for (let i = 0; i < 40; i++)
    {
        let bx = rand() * size, by = rand() * size;
        let bSize = rand() * 3 + 0.5;

        c.beginPath();
        c.arc(bx, by, bSize, 0, Math.PI * 2);
        c.fill();

        // Laufspur/Schmierspur
        if (rand() > 0.6) {
            c.beginPath();
            c.moveTo(bx, by);
            // Spur zieht sich in eine Richtung
            let dx = (rand() - 0.5) * 15;
            let dy = rand() * 20;
            c.lineTo(bx + dx, by + dy);
            c.lineWidth = bSize * 0.6;
            c.strokeStyle = 'rgba(60, 0, 0, 0.7)';
            c.stroke();
        }
    }

    return floorCanvas;
}

// ==========================================
// TEXTUREN: Echte Foto-Texturen aus dem Netz (CORS-frei, three.js CDN)
// mit Horror-Nachbearbeitung. Prozedurale Texturen dienen als Offline-Fallback.
// ==========================================
const TEXTURE_URLS = {
    wall: 'https://threejs.org/examples/textures/brick_diffuse.jpg',
    floor: 'https://threejs.org/examples/textures/hardwood2_diffuse.jpg',
    ceiling: 'https://threejs.org/examples/textures/hardwood2_diffuse.jpg' // wird rotiert & stark abgedunkelt (Holzbalkendecke)
};

// Prozedurale Fallbacks zuerst generieren
const proceduralWall = createWallTexture();
const proceduralCeiling = createCeilingTexture();
const proceduralFloor = createDetailedFloorTexture();

function makeCompositeCanvas(source) {
    const cv = document.createElement('canvas');
    cv.width = 1024; cv.height = 1024;
    cv.getContext('2d').drawImage(source, 0, 0, 1024, 1024);
    return cv;
}

// Die Render-Pipeline nutzt diese Canvases. Sie starten mit dem Fallback
// und werden überschrieben, sobald die Web-Texturen geladen sind.
const wallImg = makeCompositeCanvas(proceduralWall);
const ceilingImg = makeCompositeCanvas(proceduralCeiling);
const floorImg = makeCompositeCanvas(proceduralFloor);

// Horror-Nachbearbeitung: abdunkeln, entsättigen, Schmutz- und Schimmelflecken
function applyHorrorGrunge(cv, opts) {
    const c = cv.getContext('2d');
    const size = cv.width;
    const rand = makeSeededRandom(opts.seed);

    // Entsättigen (kaltes, totes Grau)
    if (opts.desat > 0) {
        c.globalCompositeOperation = 'saturation';
        c.fillStyle = `rgba(128, 128, 128, ${opts.desat})`;
        c.fillRect(0, 0, size, size);
    }

    // Abdunkeln
    c.globalCompositeOperation = 'source-over';
    c.fillStyle = `rgba(0, 0, 0, ${opts.darken})`;
    c.fillRect(0, 0, size, size);

    // Feuchtigkeits- und Schimmelflecken
    c.globalCompositeOperation = 'multiply';
    for (let i = 0; i < 16; i++) {
        const x = rand() * size, y = rand() * size, r = 60 + rand() * 200;
        const g = c.createRadialGradient(x, y, 0, x, y, r);
        const tone = opts.moldGreen ? '90, 110, 80' : '90, 75, 60';
        g.addColorStop(0, `rgba(${tone}, ${0.45 + rand() * 0.35})`);
        g.addColorStop(1, 'rgba(255, 255, 255, 0)');
        c.fillStyle = g;
        c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }

    // Kratzer / Risse
    for (let i = 0; i < 12; i++) {
        c.beginPath();
        let cx = rand() * size, cy = rand() * size;
        c.moveTo(cx, cy);
        for (let s = 0; s < 10; s++) {
            cx += (rand() - 0.5) * 30;
            cy += rand() * 25 + 5;
            c.lineTo(cx, cy);
        }
        c.strokeStyle = `rgba(15, 10, 8, ${0.3 + rand() * 0.4})`;
        c.lineWidth = 0.5 + rand() * 1.5;
        c.stroke();
    }
    c.globalCompositeOperation = 'source-over';

    // --- MOOS / organischer Bewuchs (kriechendes Grün, unregelmäßige Flecken) ---
    if (opts.moss) {
        for (let i = 0; i < 12; i++) {
            const x = rand() * size, y = rand() * size;
            const spread = 40 + rand() * 110;
            const blobs = 8 + (rand() * 10 | 0);
            for (let b = 0; b < blobs; b++) {
                const ox = x + (rand() - 0.5) * spread, oy = y + (rand() - 0.5) * spread;
                const br = spread * (0.15 + rand() * 0.35);
                const gg = c.createRadialGradient(ox, oy, 0, ox, oy, br);
                const grn = 55 + rand() * 45;
                gg.addColorStop(0, `rgba(${(grn * 0.45) | 0}, ${grn | 0}, ${(grn * 0.4) | 0}, ${0.16 + rand() * 0.22})`);
                gg.addColorStop(1, 'rgba(40,60,30,0)');
                c.fillStyle = gg;
                c.beginPath(); c.arc(ox, oy, br, 0, Math.PI * 2); c.fill();
            }
            // dunkle Sporen-Sprenkel im Moos
            for (let s = 0; s < 26; s++) {
                c.fillStyle = `rgba(${15 + rand() * 15 | 0}, ${45 + rand() * 30 | 0}, ${15 + rand() * 10 | 0}, ${0.2 + rand() * 0.35})`;
                c.fillRect(x + (rand() - 0.5) * spread, y + (rand() - 0.5) * spread, 1 + rand() * 2.5, 1 + rand() * 2.5);
            }
        }
    }

    // Blutspuren (kleine Tropfen)
    if (opts.blood) {
        for (let i = 0; i < 30; i++) {
            const bx = rand() * size, by = rand() * size;
            const bSize = rand() * 4 + 1;
            c.fillStyle = `rgba(70, 0, 0, ${0.5 + rand() * 0.35})`;
            c.beginPath(); c.arc(bx, by, bSize, 0, Math.PI * 2); c.fill();
            if (rand() > 0.6) {
                c.strokeStyle = 'rgba(55, 0, 0, 0.6)';
                c.lineWidth = bSize * 0.6;
                c.beginPath();
                c.moveTo(bx, by);
                c.lineTo(bx + (rand() - 0.5) * 20, by + rand() * 30);
                c.stroke();
            }
        }
        // Große getrocknete Blutlachen + Spritzkranz
        for (let i = 0; i < 5; i++) {
            const bx = rand() * size, by = rand() * size, br = 24 + rand() * 80;
            const gg = c.createRadialGradient(bx, by, 0, bx, by, br);
            gg.addColorStop(0, `rgba(${48 + rand() * 28 | 0}, 3, 4, 0.62)`);
            gg.addColorStop(0.7, 'rgba(40, 0, 0, 0.42)');
            gg.addColorStop(1, 'rgba(28, 0, 0, 0)');
            c.fillStyle = gg;
            c.beginPath(); c.arc(bx, by, br, 0, Math.PI * 2); c.fill();
            for (let s = 0; s < 16; s++) {
                const a = rand() * Math.PI * 2, d = br * (0.7 + rand() * 0.9);
                c.fillStyle = `rgba(${40 + rand() * 25 | 0}, 0, 0, ${0.35 + rand() * 0.4})`;
                c.beginPath(); c.arc(bx + Math.cos(a) * d, by + Math.sin(a) * d, rand() * 3 + 0.5, 0, Math.PI * 2); c.fill();
            }
        }
    }
}

function loadTextureInto(targetCv, url, compose) {
    return new Promise(resolve => {
        const img = loadExternalImage(url);
        const timeout = setTimeout(() => resolve(false), 8000);
        img.onload = () => {
            clearTimeout(timeout);
            try {
                compose(targetCv, img);
                console.log("Web-Textur geladen:", url);
                resolve(true);
            } catch (e) {
                console.warn("Web-Textur konnte nicht verarbeitet werden (Fallback aktiv):", e);
                resolve(false);
            }
        };
        img.onerror = () => {
            clearTimeout(timeout);
            console.warn("Web-Textur nicht erreichbar (Fallback aktiv):", url);
            resolve(false);
        };
    });
}

const texturesReady = Promise.all([
    // Wände: alte Ziegelmauer
    loadTextureInto(wallImg, TEXTURE_URLS.wall, (cv, img) => {
        const c = cv.getContext('2d');
        c.drawImage(img, 0, 0, 1024, 1024);
        applyHorrorGrunge(cv, { darken: 0.45, desat: 0.45, seed: 777, moldGreen: false, moss: true, blood: true });
    }),
    // Boden: alte Holzdielen mit Blutspuren & Moos
    loadTextureInto(floorImg, TEXTURE_URLS.floor, (cv, img) => {
        const c = cv.getContext('2d');
        c.drawImage(img, 0, 0, 1024, 1024);
        applyHorrorGrunge(cv, { darken: 0.55, desat: 0.35, seed: 1234, moldGreen: false, blood: true, moss: true });
    }),
    // Decke: rotierte, fast schwarze Holzbalken mit Schimmel & Moos
    loadTextureInto(ceilingImg, TEXTURE_URLS.ceiling, (cv, img) => {
        const c = cv.getContext('2d');
        c.save();
        c.translate(512, 512);
        c.rotate(Math.PI / 2);
        c.drawImage(img, -512, -512, 1024, 1024);
        c.restore();
        applyHorrorGrunge(cv, { darken: 0.72, desat: 0.6, seed: 4242, moldGreen: true, moss: true });
    })
]);

// ==========================================
// MÖBEL-/REQUISITEN-TEXTUREN (für die echten 3D-Boxen).
// Prozedurale Texturen als sofortiger Fallback, danach werden – wie bei den
// Wänden – realistische Foto-Texturen aus dem Netz nachgeladen (CORS-frei).
// ==========================================
function createWoodPlankTexture(darker) {
    const cv = document.createElement('canvas');
    cv.width = cv.height = 256;
    const c = cv.getContext('2d');
    const rand = makeSeededRandom(darker ? 7 : 13);
    c.fillStyle = darker ? '#2d1d10' : '#4a3119';
    c.fillRect(0, 0, 256, 256);
    const planks = 4, pw = 256 / planks;
    for (let p = 0; p < planks; p++) {
        const x = p * pw;
        const sh = 0.8 + rand() * 0.4;
        const base = darker ? [70, 46, 24] : [104, 70, 38];
        c.fillStyle = `rgb(${(base[0] * sh) | 0},${(base[1] * sh) | 0},${(base[2] * sh) | 0})`;
        c.fillRect(x, 0, pw - 1, 256);
        // Maserung
        for (let g = 0; g < 9; g++) {
            c.strokeStyle = `rgba(28,16,7,${0.12 + rand() * 0.22})`;
            c.lineWidth = 0.5 + rand();
            let gx = x + rand() * pw;
            c.beginPath(); c.moveTo(gx, 0);
            for (let s = 1; s <= 8; s++) c.lineTo(gx + (rand() - 0.5) * 7, s * 32);
            c.stroke();
        }
        // Astknoten
        if (rand() > 0.5) {
            const kx = x + pw * (0.3 + rand() * 0.4), ky = rand() * 256;
            const kg = c.createRadialGradient(kx, ky, 0, kx, ky, 7 + rand() * 6);
            kg.addColorStop(0, 'rgba(20,12,5,0.8)'); kg.addColorStop(1, 'rgba(20,12,5,0)');
            c.fillStyle = kg; c.beginPath(); c.arc(kx, ky, 13, 0, Math.PI * 2); c.fill();
        }
        // Brettfuge
        c.fillStyle = 'rgba(0,0,0,0.55)'; c.fillRect(x, 0, 1.5, 256);
    }
    return cv;
}

function createMetalTexture() {
    const cv = document.createElement('canvas');
    cv.width = cv.height = 256;
    const c = cv.getContext('2d');
    const rand = makeSeededRandom(99);
    const grad = c.createLinearGradient(0, 0, 256, 256);
    grad.addColorStop(0, '#3a3d42'); grad.addColorStop(0.5, '#23262b'); grad.addColorStop(1, '#33363b');
    c.fillStyle = grad; c.fillRect(0, 0, 256, 256);
    // Rost & Kratzer
    for (let i = 0; i < 40; i++) {
        const x = rand() * 256, y = rand() * 256, r = 4 + rand() * 22;
        const g = c.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(${90 + rand() * 50 | 0},${40 + rand() * 25 | 0},20,${0.3 + rand() * 0.4})`);
        g.addColorStop(1, 'rgba(80,40,20,0)');
        c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }
    for (let i = 0; i < 30; i++) {
        c.strokeStyle = `rgba(${rand() > 0.5 ? 200 : 10},${rand() > 0.5 ? 200 : 10},200,${0.05 + rand() * 0.12})`;
        c.lineWidth = 0.5 + rand();
        c.beginPath(); c.moveTo(rand() * 256, rand() * 256);
        c.lineTo(rand() * 256, rand() * 256); c.stroke();
    }
    return cv;
}

const propTex = {
    wood: makeCompositeCanvas(createWoodPlankTexture(false)),
    crate: makeCompositeCanvas(createWoodPlankTexture(true)),
    metal: makeCompositeCanvas(createMetalTexture())
};

// Die Grunge-Texturen werden in 1024px erzeugt (damit der Effekt stimmt), aber die
// 3D-Boxen zeichnen pro Bild ein verkleinertes 256px-Abbild → deutlich schneller
// (kein wiederholtes Herunterskalieren riesiger Bilder pro Frame). Wird nach dem
// Laden der Web-Textur aktualisiert.
function shrinkTex(src) {
    const cv = document.createElement('canvas');
    cv.width = cv.height = 256;
    cv.getContext('2d').drawImage(src, 0, 0, 256, 256);
    return cv;
}
const propTexSmall = {
    wood: shrinkTex(propTex.wood),
    crate: shrinkTex(propTex.crate),
    metal: shrinkTex(propTex.metal)
};

// Web-Texturen nicht-blockierend nachladen (Fallback bleibt aktiv, bis sie da sind)
loadTextureInto(propTex.wood, 'https://threejs.org/examples/textures/hardwood2_diffuse.jpg', (cv, img) => {
    cv.getContext('2d').drawImage(img, 0, 0, 1024, 1024);
    applyHorrorGrunge(cv, { darken: 0.5, desat: 0.4, seed: 321, moldGreen: false, moss: false, blood: false });
    propTexSmall.wood = shrinkTex(cv);
});
loadTextureInto(propTex.crate, 'https://threejs.org/examples/textures/crate.gif', (cv, img) => {
    cv.getContext('2d').drawImage(img, 0, 0, 1024, 1024);
    applyHorrorGrunge(cv, { darken: 0.42, desat: 0.45, seed: 654, moldGreen: false, moss: false, blood: false });
    propTexSmall.crate = shrinkTex(cv);
});

// Hilfsfunktion um Pixeldaten aus Bildern zu extrahieren
let floorPixels = null, ceilingPixels = null, wallPixels = null;

const assetList = [
    { img: wallImg, setter: (p) => wallPixels = p, name: "Wand" },
    { img: floorImg, setter: (p) => floorPixels = p, name: "Boden" },
    { img: ceilingImg, setter: (p) => ceilingPixels = p, name: "Decke" }
];

function extractPixels(img, callback)
{
    return new Promise((resolve) =>
    {
        const process = () =>
        {
            try
            {
                const off = document.createElement('canvas');
                off.width = 1024; off.height = 1024;
                const octx = off.getContext('2d');
                octx.drawImage(img, 0, 0, 1024, 1024);
                const data = octx.getImageData(0, 0, 1024, 1024).data;
                callback(new Uint32Array(data.buffer));
                resolve();
            }
            catch (e)
            {
                console.error("Fehler bei Pixel-Extraktion:", e);
                resolve(); // Trotzdem weiter, um den Ladebildschirm nicht zu blockieren
            }
        };

        // Canvas-Elemente (prozedural generiert) sofort verarbeiten
        if (img instanceof HTMLCanvasElement) {
            process();
            return;
        }

        // Sicherheits-Timeout: Falls ein Bild gar nicht reagiert, nach 5 Sek. weitermachen
        const timeout = setTimeout(() =>
        {
            console.warn("Lade-Timeout für Bild:", img.src);
            resolve();
        }, 5000);

        const wrappedProcess = () =>
        {
            clearTimeout(timeout);
            process();
        };

        if (img.complete)
        {
            if (img.naturalWidth > 0)
            {
                wrappedProcess();
            }
            else
            {
                // Bild ist 'complete', aber kaputt -> nicht hängen bleiben
                clearTimeout(timeout);
                resolve();
            }
        }
        else
        {
            img.onload = wrappedProcess;
            img.onerror = () =>
            {
                clearTimeout(timeout);
                console.error("Bild konnte nicht geladen werden:", img.src);
                resolve();
            };
        }
    });
}

// (treppe.png & tuer.png entfernt — Treppe & Türen sind jetzt prozedural,
//  siehe createStairsTexture() / createDoorTexture())

let floorPattern, ceilingPattern;

// --- TEXTUR-GENERATOR FÜR FALLBACKS (Gegen unsichtbare Objekte) ---
function createFallbackTex(color1, color2, type) {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 256;
    const c = canvas.getContext('2d');
    c.fillStyle = color1;
    c.fillRect(0, 0, 256, 256);
    if (type === 'door') {
        c.strokeStyle = color2;
        c.lineWidth = 4;
        c.strokeRect(20, 20, 216, 216);
        c.strokeRect(40, 40, 176, 80);
        c.strokeRect(40, 140, 176, 80);
        c.fillStyle = color2;
        c.beginPath(); c.arc(200, 128, 10, 0, Math.PI * 2); c.fill();
    } else {
        // Prozedurale Rausch-Textur für Wände/Boden
        for (let i = 0; i < 2000; i++) {
            let x = Math.random() * 256;
            let y = Math.random() * 256;
            let size = Math.random() * 2;
            c.fillStyle = Math.random() > 0.5 ? color2 : 'rgba(0,0,0,0.2)';
            c.fillRect(x, y, size, size);
        }
        c.strokeStyle = color2;
        c.strokeRect(0, 0, 256, 256);
    }
    return canvas;
}

const wallTexFallback = createFallbackTex('#222', '#111', 'wall');
const doorTexFallback = createFallbackTex('#3d2b1f', '#1a0f00', 'door');
const stairsTexFallback = createFallbackTex('#333', '#222', 'stairs');

// --- REALISTISCHE HOLZTÜR (prozedural: Maserung, Paneele, Messinggriff) ---
function createDoorTexture() {
    const w = 256, h = 512;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const c = cv.getContext('2d');
    const rand = makeSeededRandom(31337);

    // Türrahmen (fast schwarzes Holz)
    c.fillStyle = '#171009';
    c.fillRect(0, 0, w, h);

    // Türblatt: altes, dunkles Holz
    const dx0 = 16, dy0 = 10, dw = w - 32, dh = h - 20;
    const base = c.createLinearGradient(dx0, 0, dx0 + dw, 0);
    base.addColorStop(0, '#2b1c10');
    base.addColorStop(0.5, '#43301c');
    base.addColorStop(1, '#241608');
    c.fillStyle = base;
    c.fillRect(dx0, dy0, dw, dh);

    // Vertikale Holzmaserung
    for (let x = dx0; x < dx0 + dw; x += 2) {
        const n = fbm(x * 0.05, 0, 3);
        c.strokeStyle = `rgba(0, 0, 0, ${0.08 + n * 0.15})`;
        c.lineWidth = 1;
        c.beginPath();
        c.moveTo(x + Math.sin(x * 0.3) * 1.5, dy0);
        c.bezierCurveTo(x + 3, dy0 + dh * 0.3, x - 3, dy0 + dh * 0.7, x + Math.sin(x) * 2, dy0 + dh);
        c.stroke();
    }

    // Zwei eingelassene Paneele (Schattenkante oben/links = vertieft)
    const panel = (px, py, pw, ph) => {
        c.fillStyle = 'rgba(0, 0, 0, 0.55)';
        c.fillRect(px, py, pw, 6);
        c.fillRect(px, py, 6, ph);
        c.fillStyle = 'rgba(120, 90, 55, 0.25)';
        c.fillRect(px, py + ph - 5, pw, 5);
        c.fillRect(px + pw - 5, py, 5, ph);
        c.fillStyle = 'rgba(95, 70, 40, 0.18)';
        c.fillRect(px + 6, py + 6, pw - 12, ph - 12);
    };
    panel(dx0 + 26, dy0 + 36, dw - 52, dh * 0.36);
    panel(dx0 + 26, dy0 + dh * 0.52, dw - 52, dh * 0.36);

    // Messing-Türknauf mit Beschlagplatte und Schlüsselloch
    const hx = dx0 + dw - 30, hy = dy0 + dh * 0.5;
    c.fillStyle = '#1a1208';
    c.beginPath(); c.ellipse(hx, hy, 13, 22, 0, 0, Math.PI * 2); c.fill();
    const knob = c.createRadialGradient(hx - 3, hy - 3, 1, hx, hy, 9);
    knob.addColorStop(0, '#e8c878');
    knob.addColorStop(0.5, '#9a7a3a');
    knob.addColorStop(1, '#4a3514');
    c.fillStyle = knob;
    c.beginPath(); c.arc(hx, hy, 8, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#000';
    c.beginPath(); c.arc(hx, hy + 16, 2.5, 0, Math.PI * 2); c.fill();
    c.fillRect(hx - 1.2, hy + 16, 2.4, 6);

    // Kratzer (unten stärker — als hätte etwas an der Tür gescharrt)
    for (let i = 0; i < 26; i++) {
        c.strokeStyle = `rgba(10, 6, 3, ${0.25 + rand() * 0.3})`;
        c.lineWidth = 0.5 + rand();
        c.beginPath();
        const sx = dx0 + rand() * dw, sy = dy0 + dh * 0.45 + rand() * dh * 0.5;
        c.moveTo(sx, sy);
        c.lineTo(sx + (rand() - 0.5) * 50, sy + rand() * 35);
        c.stroke();
    }
    const dirt = c.createLinearGradient(0, h - 130, 0, h);
    dirt.addColorStop(0, 'rgba(0,0,0,0)');
    dirt.addColorStop(1, 'rgba(8, 5, 2, 0.75)');
    c.fillStyle = dirt;
    c.fillRect(0, h - 130, w, 130);

    return cv;
}
const doorTex = createDoorTexture();

// --- EXIT-TÜR: strahlend weiß leuchtend (erscheint erst nach allen Schlüsseln) ---
function createExitDoorTexture() {
    const w = 256, h = 512;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const c = cv.getContext('2d');

    // Dunkler Rahmen, damit die Tür im Mauerwerk sitzt
    c.fillStyle = '#0a0a0c';
    c.fillRect(0, 0, w, h);

    // Weißes Türblatt mit kaltem Glühen
    const dx0 = 18, dy0 = 12, dw = w - 36, dh = h - 24;
    const glow = c.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, h * 0.65);
    glow.addColorStop(0, '#ffffff');
    glow.addColorStop(0.55, '#f2f4ff');
    glow.addColorStop(1, '#b9c2dd');
    c.fillStyle = glow;
    c.fillRect(dx0, dy0, dw, dh);

    // Lichtkranz, der den Rahmen überstrahlt
    c.shadowColor = '#ffffff';
    c.shadowBlur = 40;
    c.strokeStyle = 'rgba(255, 255, 255, 0.95)';
    c.lineWidth = 6;
    c.strokeRect(dx0, dy0, dw, dh);
    c.shadowBlur = 0;

    // Dezente Paneel-Linien
    c.strokeStyle = 'rgba(150, 160, 200, 0.5)';
    c.lineWidth = 3;
    c.strokeRect(dx0 + 28, dy0 + 40, dw - 56, dh * 0.34);
    c.strokeRect(dx0 + 28, dy0 + dh * 0.52, dw - 56, dh * 0.34);

    // Griff als dunkle Silhouette
    c.fillStyle = 'rgba(40, 45, 70, 0.9)';
    c.beginPath(); c.arc(dx0 + dw - 26, dy0 + dh * 0.5, 9, 0, Math.PI * 2); c.fill();

    // Lichtschlieren, als würde Licht durch Spalten dringen
    for (let i = 0; i < 5; i++) {
        const ly = dy0 + (i + 1) * dh / 6;
        const ray = c.createLinearGradient(dx0, ly, dx0 + dw, ly);
        ray.addColorStop(0, 'rgba(255,255,255,0)');
        ray.addColorStop(0.5, 'rgba(255,255,255,0.35)');
        ray.addColorStop(1, 'rgba(255,255,255,0)');
        c.fillStyle = ray;
        c.fillRect(dx0, ly - 2, dw, 4);
    }
    return cv;
}
const exitDoorTex = createExitDoorTexture();

// --- NEUE TREPPE (prozedural): perspektivische Steinstufen mit altem Teppichläufer,
//     Geländer, Moos, Spinnweben und kaltem Licht aus der nächsten Etage. ---
function createStairsTexture(goingUp) {
    const w = 256, h = 512;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const c = cv.getContext('2d');
    const rand = makeSeededRandom(goingUp ? 8051 : 6042);

    const cxm = w / 2;
    const yTop = h * 0.17, yBot = h - 10;
    const halfNear = w * 0.46, halfFar = w * 0.11;
    const N = 15;
    const yAt = t => yBot - (yBot - yTop) * Math.pow(t, 0.62); // nahe Stufen weiter auseinander
    const halfAt = t => halfNear + (halfFar - halfNear) * t;

    // Hintergrund des Treppenhauses
    c.fillStyle = '#0a0908';
    c.fillRect(0, 0, w, h);

    // Kaltes Licht aus der oberen Etage (bzw. Dunkelheit beim Hinabsteigen)
    if (goingUp) {
        const g = c.createRadialGradient(cxm, yTop, 4, cxm, yTop, h * 0.45);
        g.addColorStop(0, 'rgba(150, 160, 185, 0.55)');
        g.addColorStop(0.5, 'rgba(70, 78, 95, 0.25)');
        g.addColorStop(1, 'rgba(70, 78, 95, 0)');
        c.fillStyle = g;
        c.fillRect(0, 0, w, h);
    } else {
        const g = c.createRadialGradient(cxm, yTop, 4, cxm, yTop, h * 0.4);
        g.addColorStop(0, 'rgba(0, 0, 0, 0.9)');
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        c.fillStyle = g;
        c.fillRect(0, 0, w, h);
    }

    // Seitenwände (konvergierend), dunkles Mauerwerk mit Verlauf
    const sideGrad = c.createLinearGradient(0, 0, cxm, 0);
    sideGrad.addColorStop(0, '#060504');
    sideGrad.addColorStop(1, '#241c14');
    c.fillStyle = sideGrad;
    c.beginPath();
    c.moveTo(0, yBot); c.lineTo(cxm - halfNear, yBot);
    c.lineTo(cxm - halfFar, yTop); c.lineTo(0, yTop);
    c.closePath(); c.fill();
    const sideGrad2 = c.createLinearGradient(w, 0, cxm, 0);
    sideGrad2.addColorStop(0, '#060504');
    sideGrad2.addColorStop(1, '#241c14');
    c.fillStyle = sideGrad2;
    c.beginPath();
    c.moveTo(w, yBot); c.lineTo(cxm + halfNear, yBot);
    c.lineTo(cxm + halfFar, yTop); c.lineTo(w, yTop);
    c.closePath(); c.fill();

    // Stufen von FERN nach NAH zeichnen (nähere überdecken fernere)
    for (let i = N - 1; i >= 0; i--) {
        const tf = i / N, tb = (i + 1) / N;
        const yF = yAt(tf), yB = yAt(tb);
        const hwF = halfAt(tf), hwB = halfAt(tb);
        const riserH = (yAt(tf - 1 / N) - yF) || (yF - yB);

        // Setzstufe (Vorderseite, im Schatten)
        const shade = 26 + i * 1.2;
        c.fillStyle = `rgb(${shade | 0},${(shade * 0.92) | 0},${(shade * 0.82) | 0})`;
        c.beginPath();
        c.moveTo(cxm - hwF, yF);
        c.lineTo(cxm + hwF, yF);
        c.lineTo(cxm + hwF, yF + Math.max(2, riserH * 0.5));
        c.lineTo(cxm - hwF, yF + Math.max(2, riserH * 0.5));
        c.closePath(); c.fill();

        // Trittfläche (Oberseite, beleuchtet) — Trapez von Vorder- zu Hinterkante
        const lit = 70 + i * 3.2 + rand() * 10;
        c.fillStyle = `rgb(${Math.min(150, lit) | 0},${Math.min(140, lit * 0.93) | 0},${Math.min(125, lit * 0.82) | 0})`;
        c.beginPath();
        c.moveTo(cxm - hwF, yF);
        c.lineTo(cxm + hwF, yF);
        c.lineTo(cxm + hwB, yB);
        c.lineTo(cxm - hwB, yB);
        c.closePath(); c.fill();

        // helle Vorderkante der Stufe
        c.strokeStyle = `rgba(190,185,170,${0.25 + (i / N) * 0.2})`;
        c.lineWidth = 1.2;
        c.beginPath(); c.moveTo(cxm - hwF, yF); c.lineTo(cxm + hwF, yF); c.stroke();

        // alter Teppichläufer in der Mitte (dunkelrot, abgenutzt)
        const carpF = hwF * 0.4, carpB = hwB * 0.4;
        c.fillStyle = `rgb(${(48 + i) | 0}, ${(12 + i * 0.4) | 0}, ${(12 + i * 0.4) | 0})`;
        c.beginPath();
        c.moveTo(cxm - carpF, yF); c.lineTo(cxm + carpF, yF);
        c.lineTo(cxm + carpB, yB); c.lineTo(cxm - carpB, yB);
        c.closePath(); c.fill();
    }

    // Geländer rechts: schräge Handlauf-Linie + Pfosten
    c.strokeStyle = 'rgba(20,14,8,0.9)';
    c.lineWidth = 5;
    c.beginPath(); c.moveTo(cxm + halfNear * 0.92, yBot); c.lineTo(cxm + halfFar * 0.9, yTop + 6); c.stroke();
    for (let i = 0; i < N; i += 2) {
        const t = i / N, y = yAt(t), hw = halfAt(t);
        c.lineWidth = Math.max(1, 4 * (1 - t));
        c.beginPath(); c.moveTo(cxm + hw * 0.92, y); c.lineTo(cxm + hw * 0.9, y - 26 * (1 - t)); c.stroke();
    }

    // Moos in den unteren Ecken
    for (let s = 0; s < 26; s++) {
        const mx = (rand() < 0.5 ? rand() * w * 0.25 : w - rand() * w * 0.25);
        const my = h * 0.55 + rand() * h * 0.45;
        const mr = 5 + rand() * 22;
        const mg = c.createRadialGradient(mx, my, 0, mx, my, mr);
        mg.addColorStop(0, `rgba(${30 + rand() * 20 | 0}, ${55 + rand() * 35 | 0}, ${25 + rand() * 15 | 0}, ${0.18 + rand() * 0.22})`);
        mg.addColorStop(1, 'rgba(30,55,25,0)');
        c.fillStyle = mg;
        c.beginPath(); c.arc(mx, my, mr, 0, Math.PI * 2); c.fill();
    }

    // Spinnweben in den oberen Ecken
    c.strokeStyle = 'rgba(200,200,200,0.10)';
    c.lineWidth = 0.8;
    for (const corner of [[8, yTop + 6], [w - 8, yTop + 6]]) {
        for (let r2 = 10; r2 < 70; r2 += 12) {
            c.beginPath(); c.arc(corner[0], corner[1], r2, 0, Math.PI / 2 * (corner[0] < cxm ? 1 : 1)); c.stroke();
        }
    }

    // dunkler Rahmen
    c.strokeStyle = '#000';
    c.lineWidth = 8;
    c.strokeRect(0, 0, w, h);
    return cv;
}
// Hinweis: Treppen werden jetzt als echtes 3D-Objekt gezeichnet (drawStairs3D),
// nicht mehr als flache Wandtextur. createStairsTexture() bleibt ungenutzt.

// Vorgerenderter Staub-Glow (ersetzt teure createRadialGradient-Aufrufe pro Partikel & Frame)
const dustSprite = (() => {
    const cv = document.createElement('canvas');
    cv.width = 32; cv.height = 32;
    const c = cv.getContext('2d');
    const g = c.createRadialGradient(16, 16, 0, 16, 16, 16);
    g.addColorStop(0, 'rgba(200, 220, 255, 1)');
    g.addColorStop(1, 'rgba(200, 220, 255, 0)');
    c.fillStyle = g;
    c.fillRect(0, 0, 32, 32);
    return cv;
})();

const TILE_SIZE = 60;
const MAP_WIDTH = 80;  // Riesige Map
const MAP_HEIGHT = 60; // Riesige Map

// --- SCHWIERIGKEITSGRADE ---
const DIFFICULTY_SETTINGS = {
    leicht: { floors: 1, keys: 5, enemiesPerFloor: 1, speed: 1.2, visionRange: 350, searchDist: 400, intelligence: 0, desc: "Gentle start. The monster is slow and forgetful." },
    normal: { floors: 2, keys: 10, enemiesPerFloor: 1, speed: 2.2, visionRange: 500, searchDist: 800, intelligence: 1, desc: "The standard experience. Balanced challenge." },
    schwer: { floors: 3, keys: 15, enemiesPerFloor: 1.7, speed: 3.0, visionRange: 750, searchDist: 1500, intelligence: 2, desc: "Persistent monsters that barely let you out of their sight." },
    impossible: { floors: 5, keys: 25, enemiesPerFloor: 3, speed: 4.2, visionRange: 1200, searchDist: 3000, intelligence: 3, desc: "Your death is certain. The monsters smell your fear." }
};
let currentDifficulty = 'normal';

let maps = [];
let currentFloor = 0;
// Langer Flur, an dessen Wänden links/rechts Türen sitzen. Die Kamera steht am
// unteren Ende und blickt nach Norden — so sieht man den Gang mit den Türen.
const startScreenMap = [
    "11111111111".split(''), // 0  ferne Wand
    "11110001111".split(''), // 1
    "11120001111".split(''), // 2  Tür links
    "11110002111".split(''), // 3  Tür rechts
    "11110001111".split(''), // 4
    "11120001111".split(''), // 5  Tür links
    "11110001111".split(''), // 6
    "11110002111".split(''), // 7  Tür rechts
    "11110001111".split(''), // 8
    "11120001111".split(''), // 9  Tür links
    "11110002111".split(''), // 10 Tür rechts
    "11110001111".split(''), // 11 Kamera steht hier
    "11111111111".split('')  // 12 Wand hinter der Kamera
];
let map = [];

let keysData = [];
let TOTAL_KEYS = 10;
let enemiesData = [];
let bloodSplattersData = [];
let doorsData = []; // Neues Array für Tür-Objekte
let torchesData = [];
let windowsData = [];
let corpsesData = []; // Leichen/Skelette als Grusel-Deko in einigen Räumen
let stairsData = [];  // Treppen-Positionen (für die 3D-Treppen-Sprites)
let furnitureData = []; // Möbel (Deko) in den Räumen
let closetsData = [];   // Schränke zum Verstecken
// Cache der soliden Requisiten (Möbel+Schränke) der aktuellen Etage für die Kollision
let _collProps = null, _collPropsFloor = -1;

// Versteck-/Minispiel-Zustand
let hideState = {
    active: false,    // Spieler hockt im Schrank
    closet: null,
    minigame: false,  // QTE läuft (Monster jagt in der Nähe)
    strikes: 0,
    successes: 0,
    key: 'A',         // geforderte Taste dieser Runde
    marker: 0,        // Position 0..1 des Laufbalkens
    markerDir: 1,
    markerSpeed: 0.02,
    roundTimer: 0,    // Frames bis zur erzwungenen Fehlrunde
    flashTimer: 0,    // Feedback-Blitz (grün/rot)
    flashGood: false,
    savedX: 0, savedY: 0,
    // Panik beim zu langen Verstecken: Herzschlag pocht, Bild wird rot, dann Tod
    hideTimer: 0,     // Frames im Schrank (ohne aktives QTE)
    panic: 0,         // 0..1 Panikstärke (Herzschlag/Rotfärbung)
    beat: 0,          // aktuelle Herzschlag-Hüllkurve (für das Pochen)
    beatPhase: 0      // Phase des Herzschlags 0..1
};

// Schnelle Lookups (Performance) und neue Spielsysteme
let doorLookup = [];      // pro Etage: Map(key -> Tür-Objekt) für Raycaster/Kollision
let windowLookup = [];    // pro Etage: Set mit Fenster-Kacheln
let floorRooms = [];      // pro Etage: bewohnbare Räume (für Exit-Spawn)
let floorRegions = [];    // pro Etage: Region-ID je Kachel (Raum-basierte Minimap)
let revealedRegions = []; // pro Etage: Set bereits betretener Regionen
let exitSpawned = false, exitFloor = -1, exitTileX = -1, exitTileY = -1, exitFloorName = '';

// Minimap-Cache-Status (muss VOR dem ersten initGameWorld()-Aufruf deklariert sein)
let minimapCacheFloor = -1;
let minimapCacheExploredSize = -1;

function getDoorAt(gx, gy) {
    const lk = doorLookup[currentFloor];
    return lk ? lk.get(gy * MAP_WIDTH + gx) : undefined;
}

let audioCtx = null;

// ==========================================
// AUDIO SYSTEM (komplett mit WebAudio synthetisiert)
// ==========================================
let masterGain = null, reverbSend = null;

function getAudio() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    if (!masterGain) {
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.9;
        masterGain.connect(audioCtx.destination);

        // Prozeduraler Hall: lässt alles klingen wie in einem leeren alten Haus
        const convolver = audioCtx.createConvolver();
        const len = Math.floor(audioCtx.sampleRate * 2.2);
        const ir = audioCtx.createBuffer(2, len, audioCtx.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
            const d = ir.getChannelData(ch);
            for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5);
        }
        convolver.buffer = ir;
        reverbSend = audioCtx.createGain();
        reverbSend.gain.value = 0.35;
        reverbSend.connect(convolver);
        convolver.connect(masterGain);
    }
    return audioCtx;
}

// Routet eine Node trocken zum Master und anteilig in den Hall
function routeOut(node, wet) {
    node.connect(masterGain);
    if (wet > 0) {
        const w = audioCtx.createGain();
        w.gain.value = wet;
        node.connect(w);
        w.connect(reverbSend);
    }
}

// Herzschlag (Lub-Dub) — tiefer, schnell abklingender Puls; lauter mit der Panik
function playHeartbeat(intensity) {
    const ac = getAudio(); if (!ac || !masterGain) return;
    const now = ac.currentTime;
    const peak = 0.12 + Math.min(1, intensity) * 0.55;
    const thump = (t, gainPeak, freq) => {
        const o = ac.createOscillator();
        const g = ac.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, t);
        o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * 0.5), t + 0.18);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(gainPeak, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.24);
        o.connect(g); g.connect(masterGain);
        o.start(t); o.stop(t + 0.28);
    };
    thump(now, peak, 62);          // "lub"
    thump(now + 0.15, peak * 0.7, 50); // "dub"
}

function createNoiseBuffer(seconds) {
    const ac = getAudio();
    const len = Math.floor(ac.sampleRate * seconds);
    const buf = ac.createBuffer(1, len, ac.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return buf;
}

// ==========================================
// ECHTE SOUND-SAMPLES AUS DEM NETZ (Wikimedia Commons, frei lizenziert)
// Werden im Hintergrund geladen; bis dahin (oder offline) greifen
// die synthetisierten Fallback-Sounds.
// ==========================================
const SOUND_URLS = {
    thunder: [
        'https://upload.wikimedia.org/wikipedia/commons/f/fa/Thunder_01.ogg',
        'https://upload.wikimedia.org/wikipedia/commons/7/75/Thunder_crack_2B.ogg'
    ],
    growl: [
        'https://upload.wikimedia.org/wikipedia/commons/7/71/Monster_growls.ogg',
        'https://upload.wikimedia.org/wikipedia/commons/3/36/Monster_growls_2.ogg'
    ],
    scream: [
        'https://upload.wikimedia.org/wikipedia/commons/9/92/Scream-e.wav',
        'https://upload.wikimedia.org/wikipedia/commons/d/dc/Scream-c.wav'
    ],
    doorCreak: [
        'https://upload.wikimedia.org/wikipedia/commons/7/74/Door_handle_creaking.ogg'
    ],
    wind: [
        'https://upload.wikimedia.org/wikipedia/commons/2/2d/Howling_wind.ogg'
    ]
};
const soundBank = {}; // name -> Array dekodierter AudioBuffer

function loadSoundBank() {
    try { getAudio(); } catch (e) { return; }
    Object.entries(SOUND_URLS).forEach(([name, urls]) => {
        soundBank[name] = [];
        urls.forEach(url => {
            fetch(url)
                .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
                .then(buf => audioCtx.decodeAudioData(buf))
                .then(decoded => {
                    soundBank[name].push(decoded);
                    console.log('Sound-Sample geladen:', name);
                })
                .catch(err => console.warn('Sample nicht ladbar (Synth-Fallback aktiv):', name, err.message));
        });
    });
}

// Spielt ein geladenes Sample ab. Gibt false zurück, wenn (noch) keines
// verfügbar ist — dann übernimmt der synthetisierte Fallback.
function playSample(name, opts = {}) {
    const bank = soundBank[name];
    if (!bank || bank.length === 0) return false;
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const buf = bank[(Math.random() * bank.length) | 0];
        const src = ac.createBufferSource();
        src.buffer = buf;
        src.playbackRate.value = opts.rate || 1;
        const vol = opts.volume != null ? opts.volume : 1;
        const g = ac.createGain();

        // Optionale Kette: Tiefpass (Distanz-Dämpfung) und Stereo-Panning (Richtungsortung)
        let chainEnd = src;
        if (opts.lowpass) {
            const lp = ac.createBiquadFilter();
            lp.type = 'lowpass';
            lp.frequency.value = opts.lowpass;
            chainEnd.connect(lp);
            chainEnd = lp;
        }
        if (opts.pan != null && ac.createStereoPanner) {
            const p = ac.createStereoPanner();
            p.pan.value = Math.max(-1, Math.min(1, opts.pan));
            chainEnd.connect(p);
            chainEnd = p;
        }

        if (opts.loop) {
            src.loop = true;
            g.gain.setValueAtTime(0.0001, now);
            g.gain.linearRampToValueAtTime(vol, now + 3); // langsam einblenden
            chainEnd.connect(g);
            routeOut(g, opts.wet != null ? opts.wet : 0.4);
            src.start(now);
            return src;
        }

        // Bei langen Aufnahmen einen zufälligen Ausschnitt spielen (mit Fades)
        let offset = 0, dur = buf.duration / (opts.rate || 1);
        if (opts.maxDur && dur > opts.maxDur) {
            dur = opts.maxDur;
            offset = Math.random() * (buf.duration - dur * (opts.rate || 1));
        }
        const fadeIn = Math.min(0.06, dur * 0.15);
        const fadeOut = Math.min(0.3, dur * 0.3);
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(vol, now + fadeIn);
        g.gain.setValueAtTime(vol, now + dur - fadeOut);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        chainEnd.connect(g);
        routeOut(g, opts.wet != null ? opts.wet : 0.4);
        src.start(now, offset);
        src.stop(now + dur + 0.1);
        return src;
    } catch (e) { return false; }
}

function playMonsterGrowl(intensity, opts = {}) {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.9 + Math.random() * 0.5;
        const vol = 0.45 * Math.max(0.1, Math.min(1, intensity));

        // Echtes Monster-Knurren (Sample), leicht heruntergepitcht für mehr Masse.
        // pan/lowpass erlauben Richtungsortung und Distanz-Dämpfung.
        if (playSample('growl', {
            volume: vol * 1.4, maxDur: 2.4,
            rate: 0.78 + Math.random() * 0.2,
            wet: opts.wet != null ? opts.wet : 0.5,
            pan: opts.pan,
            lowpass: opts.lowpass
        })) return;

        // Kehliges Knurren: tiefer Sägezahn mit Vibrato
        const o = ac.createOscillator();
        o.type = 'sawtooth';
        o.frequency.setValueAtTime(55 + Math.random() * 25, now);
        o.frequency.linearRampToValueAtTime(40, now + dur);
        const lfo = ac.createOscillator();
        lfo.frequency.value = 9 + Math.random() * 6;
        const lfoG = ac.createGain();
        lfoG.gain.value = 14;
        lfo.connect(lfoG); lfoG.connect(o.frequency);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass'; lp.frequency.value = 350;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(vol, now + 0.1);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        o.connect(lp); lp.connect(g); routeOut(g, 0.5);
        o.start(now); o.stop(now + dur);
        lfo.start(now); lfo.stop(now + dur);

        // Atem-Rauschen dazu
        const br = ac.createBufferSource();
        br.buffer = createNoiseBuffer(dur);
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 600; bp.Q.value = 1.5;
        const bg = ac.createGain();
        bg.gain.setValueAtTime(0.0001, now);
        bg.gain.exponentialRampToValueAtTime(vol * 0.4, now + 0.15);
        bg.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        br.connect(bp); bp.connect(bg); routeOut(bg, 0.5);
        br.start(now);
    } catch (e) { }
}

function playHeartbeat(intensity) {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const vol = 0.25 + intensity * 0.45;
        // "Lub-Dub": zwei tiefe Schläge
        [[0, vol], [0.16, vol * 0.6]].forEach(([off, v]) => {
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(60, now + off);
            o.frequency.exponentialRampToValueAtTime(35, now + off + 0.1);
            const g = ac.createGain();
            g.gain.setValueAtTime(v, now + off);
            g.gain.exponentialRampToValueAtTime(0.0001, now + off + 0.13);
            o.connect(g); g.connect(masterGain);
            o.start(now + off); o.stop(now + off + 0.15);
        });
    } catch (e) { }
}

function playDoorCreak() {
    try {
        // Echtes Türknarren (Sample) mit zufälliger Tonhöhe
        if (playSample('doorCreak', { volume: 0.35, maxDur: 1.8, rate: 0.7 + Math.random() * 0.4, wet: 0.6 })) return;

        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.8 + Math.random() * 0.4;
        const o = ac.createOscillator();
        o.type = 'sawtooth';
        // Knarrende, ruckelige Frequenzkurve
        let f = 120 + Math.random() * 80;
        o.frequency.setValueAtTime(f, now);
        let t = now;
        while (t < now + dur) {
            t += 0.05 + Math.random() * 0.1;
            f += (Math.random() - 0.35) * 90;
            f = Math.max(70, Math.min(450, f));
            o.frequency.linearRampToValueAtTime(f, t);
        }
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 700; bp.Q.value = 2;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(0.07, now + 0.1);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        o.connect(bp); bp.connect(g); routeOut(g, 0.6);
        o.start(now); o.stop(now + dur + 0.05);
    } catch (e) { }
}

function playKeyPickup() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        // Kleines metallisches Klimpern
        [880, 1318.5].forEach((f, i) => {
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.value = f;
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now + i * 0.07);
            g.gain.exponentialRampToValueAtTime(0.12, now + i * 0.07 + 0.02);
            g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.07 + 0.5);
            o.connect(g); routeOut(g, 0.6);
            o.start(now + i * 0.07); o.stop(now + i * 0.07 + 0.55);
        });
    } catch (e) { }
}

function playStairStep() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        // Schwerer Schritt auf alter Holzstufe
        const o = ac.createOscillator();
        o.type = 'sine';
        o.frequency.setValueAtTime(70 + Math.random() * 15, now);
        o.frequency.exponentialRampToValueAtTime(28, now + 0.07);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.8, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
        o.connect(g); routeOut(g, 0.4);
        o.start(now); o.stop(now + 0.1);

        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(0.12);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass'; lp.frequency.value = 250 + Math.random() * 100;
        const ng = ac.createGain();
        ng.gain.setValueAtTime(0.6, now);
        ng.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        src.connect(lp); lp.connect(ng); routeOut(ng, 0.5);
        src.start(now);
    } catch (e) { }
}

function playExhaustedBreath() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 0.5;
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const bp = ac.createBiquadFilter();
        bp.type = 'bandpass'; bp.frequency.value = 500; bp.Q.value = 1.2;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(0.08, now + dur * 0.4);
        g.gain.linearRampToValueAtTime(0.0001, now + dur);
        src.connect(bp); bp.connect(g); g.connect(masterGain);
        src.start(now);
    } catch (e) { }
}

function playJumpscareScream() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;

        // Mehrschichtiger Schrei: tiefer dämonischer Layer + schriller Layer
        // + Knurren direkt am Ohr + Sub-Bass-Schlag in der Brust
        if (playSample('scream', { volume: 1.0, rate: 0.58 + Math.random() * 0.08, wet: 0.85 })) {
            playSample('scream', { volume: 0.65, rate: 1.05, wet: 0.6 });
            playSample('growl', { volume: 0.9, maxDur: 2.0, rate: 0.62, wet: 0.6 });

            // Sub-Bass-Impact (spürbarer Schlag)
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(70, now);
            o.frequency.exponentialRampToValueAtTime(24, now + 0.5);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.9, now);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);
            o.connect(g); g.connect(masterGain);
            o.start(now); o.stop(now + 0.65);
            return;
        }

        const dur = 1.3;
        // Drei verstimmte, schrille Stimmen
        for (let i = 0; i < 3; i++) {
            const det = 1 + (i - 1) * 0.04;
            const o = ac.createOscillator();
            o.type = 'sawtooth';
            o.frequency.setValueAtTime(350 * det, now);
            o.frequency.exponentialRampToValueAtTime(1100 * det, now + 0.18);
            o.frequency.exponentialRampToValueAtTime(600 * det, now + dur);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.exponentialRampToValueAtTime(0.35, now + 0.04);
            g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
            o.connect(g); routeOut(g, 0.8);
            o.start(now); o.stop(now + dur);
        }
        // Schrilles Rauschen obendrauf
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const hp = ac.createBiquadFilter();
        hp.type = 'highpass'; hp.frequency.value = 1500;
        const g = ac.createGain();
        g.gain.setValueAtTime(0.45, now);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        src.connect(hp); hp.connect(g); routeOut(g, 0.7);
        src.start(now);
    } catch (e) { }
}

let ambientStarted = false;
function startAmbientSound() {
    if (ambientStarted) return;
    try {
        const ac = getAudio();
        ambientStarted = true;
        const now = ac.currentTime;

        // Tiefer Drone: zwei leicht verstimmte Sinus-Oszillatoren erzeugen
        // eine langsam schwebende, bedrohliche Grundstimmung
        [[55, 0.04], [55.8, 0.04], [110.3, 0.015]].forEach(([f, v], i) => {
            const o = ac.createOscillator();
            o.type = i === 2 ? 'triangle' : 'sine';
            o.frequency.value = f;
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.linearRampToValueAtTime(v, now + 4); // langsam einblenden
            o.connect(g); routeOut(g, 0.9);
            o.start(now);
        });

        // Wind: bevorzugt echte Aufnahme (heulender Wind, geloopt),
        // sonst gefiltertes Rauschen mit langsamer Lautstärke-Modulation
        if (!playSample('wind', { volume: 0.07, loop: true, rate: 0.85, wet: 0.4 })) {
            const src = ac.createBufferSource();
            src.buffer = createNoiseBuffer(4);
            src.loop = true;
            const lp = ac.createBiquadFilter();
            lp.type = 'lowpass'; lp.frequency.value = 420; lp.Q.value = 0.8;
            const g = ac.createGain();
            g.gain.value = 0.018;
            const lfo = ac.createOscillator();
            lfo.frequency.value = 0.07;
            const lfoG = ac.createGain();
            lfoG.gain.value = 0.012;
            lfo.connect(lfoG); lfoG.connect(g.gain);
            src.connect(lp); lp.connect(g); routeOut(g, 0.6);
            src.start(now); lfo.start(now);
        }
    } catch (e) { ambientStarted = false; }
}

function playFootstepSound() {
    try {
        getAudio();

        const now = audioCtx.currentTime;

        // 1. Heel Impact (The Thump)
        let heel = audioCtx.createOscillator();
        let heelGain = audioCtx.createGain();
        heel.type = 'sine';
        heel.frequency.setValueAtTime(80 + Math.random() * 20, now);
        // Kürzere Ramp-Zeit (0.05 statt 0.08) verhindert den Laser-Effekt
        heel.frequency.exponentialRampToValueAtTime(30, now + 0.05);
        heelGain.gain.setValueAtTime(0.7, now);
        heelGain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
        heel.connect(heelGain);
        heelGain.connect(masterGain);
        heel.start(); heel.stop(now + 0.06);

        // 2. Hollow Wood Resonance (Filtered Noise)
        let resonance = audioCtx.createBufferSource();
        let bufferSize = audioCtx.sampleRate * 0.1;
        let buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        let data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        resonance.buffer = buffer;

        let filter = audioCtx.createBiquadFilter();
        filter.type = "lowpass"; // Lowpass macht den Sound dumpfer/holziger als Bandpass
        filter.frequency.value = 300 + Math.random() * 100;
        filter.Q.value = 1;

        let resGain = audioCtx.createGain();
        resGain.gain.setValueAtTime(0.8, now);
        resGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        resonance.connect(filter);
        filter.connect(resGain);
        resGain.connect(masterGain);
        resonance.start();

        // 3. Subtle Plank Creak (Occasional detail)
        if (Math.random() > 0.85) {
            let creak = audioCtx.createOscillator();
            let creakGain = audioCtx.createGain();
            creak.type = 'triangle';
            creak.frequency.setValueAtTime(150 + Math.random() * 50, now);
            creak.frequency.linearRampToValueAtTime(60, now + 0.1);
            creakGain.gain.setValueAtTime(0.12, now);
            creakGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
            creak.connect(creakGain); creakGain.connect(masterGain);
            creak.start(); creak.stop(now + 0.1);
        }
    } catch (e) { }
}

let thunderState = { active: false, intensity: 0, timer: 0, nextThunder: 300 };
let stingTimer = 500;

// --- MINIMAP SYSTEM ---
let minimapOpen = false;
let exploredTiles = []; // Array of Sets, one per floor (aufgedeckte Kacheln je Etage)

function playScarySting() {
    try {
        const ac = getAudio();
        const now = ac.currentTime;
        const type = Math.random();

        if (type < 0.35) {
            // Metallisches Kratzen (wie Krallen an einem Rohr)
            const src = ac.createBufferSource();
            src.buffer = createNoiseBuffer(1.4);
            const bp = ac.createBiquadFilter();
            bp.type = 'bandpass'; bp.Q.value = 18;
            bp.frequency.setValueAtTime(2600, now);
            bp.frequency.exponentialRampToValueAtTime(500, now + 1.3);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.0001, now);
            g.gain.exponentialRampToValueAtTime(0.15, now + 0.25);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 1.4);
            src.connect(bp); bp.connect(g); routeOut(g, 0.7);
            src.start(now);
        } else if (type < 0.7) {
            // Dissonante Streicher (kleine Sekunde, schwillt langsam an)
            [138.6, 146.8].forEach(f => {
                const o = ac.createOscillator();
                o.type = 'sawtooth';
                o.frequency.value = f;
                const lp = ac.createBiquadFilter();
                lp.type = 'lowpass'; lp.frequency.value = 900;
                const g = ac.createGain();
                g.gain.setValueAtTime(0.0001, now);
                g.gain.linearRampToValueAtTime(0.06, now + 1.2);
                g.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);
                o.connect(lp); lp.connect(g); routeOut(g, 0.8);
                o.start(now); o.stop(now + 3);
            });
        } else {
            // Dumpfer Schlag in der Ferne (als käme er aus einer anderen Etage)
            const o = ac.createOscillator();
            o.type = 'sine';
            o.frequency.setValueAtTime(85, now);
            o.frequency.exponentialRampToValueAtTime(35, now + 0.4);
            const g = ac.createGain();
            g.gain.setValueAtTime(0.3, now);
            g.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);
            o.connect(g); routeOut(g, 0.9);
            o.start(now); o.stop(now + 0.55);
        }
    } catch (e) { }
}

function playThunderSound() {
    try {
        // Echter Donner (Sample), leicht heruntergepitcht für mehr Wucht
        if (playSample('thunder', { volume: 0.8, rate: 0.8 + Math.random() * 0.3, wet: 0.5 })) return;

        const ac = getAudio();
        const now = ac.currentTime;
        const dur = 2.5 + Math.random() * 1.5;

        // Grollen: Rauschen durch absinkenden Tiefpass
        const src = ac.createBufferSource();
        src.buffer = createNoiseBuffer(dur);
        const lp = ac.createBiquadFilter();
        lp.type = 'lowpass';
        lp.frequency.setValueAtTime(350, now);
        lp.frequency.exponentialRampToValueAtTime(45, now + dur);
        const g = ac.createGain();
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(0.7, now + 0.08);
        g.gain.exponentialRampToValueAtTime(0.2, now + dur * 0.4);
        g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
        src.connect(lp); lp.connect(g); routeOut(g, 0.5);
        src.start(now);

        // Sub-Bass-Grollen darunter
        const sub = ac.createOscillator();
        sub.type = 'sine';
        sub.frequency.setValueAtTime(50, now);
        sub.frequency.exponentialRampToValueAtTime(28, now + dur);
        const sg = ac.createGain();
        sg.gain.setValueAtTime(0.0001, now);
        sg.gain.exponentialRampToValueAtTime(0.4, now + 0.15);
        sg.gain.exponentialRampToValueAtTime(0.0001, now + dur * 0.8);
        sub.connect(sg); sg.connect(masterGain);
        sub.start(now); sub.stop(now + dur);
    } catch (e) { }
}

const player = {
    x: 0,
    y: 0,
    radius: 12,
    isExhausted: false,
    speed: 2.3,
    runSpeed: 5.0,
    angle: 0,
    stamina: 100,
    maxStamina: 100,
    keys: 0,
    footstepTimer: 0,
    pitch: 0,
    z: 0 // Vertikale Position für Treppen
};

let fadeAlpha = 0; // Für Treppen-Animation

// --- STATIC TEXTURES ---
// --- PROCEDURAL GENERATION ---
function createRandomFloor() {
    // Mehrere Versuche: das Layout mit den meisten Räumen gewinnt
    let best = null;
    for (let attempt = 0; attempt < 4; attempt++) {
        const gen = generateFloorLayout();
        const count = gen.rooms.filter(r => r.label !== "Hauptflur").length;
        if (!best || count > best.count) best = { gen, count };
        if (count >= 12) break;
    }
    return best.gen;
}

function generateFloorLayout() {
    const grid = Array(MAP_HEIGHT).fill(0).map(() => Array(MAP_WIDTH).fill('1'));
    const rooms = [];
    const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

    // --- 1. KORRIDOR-NETZ: Ring aus 2 vertikalen + 2 horizontalen Fluren,
    //     optional zusätzliche Mittelflure — jede Etage bekommt ein anderes Layout ---
    const vHalls = [rnd(12, 24), rnd(MAP_WIDTH - 25, MAP_WIDTH - 13)];
    const hHalls = [rnd(9, 16), rnd(MAP_HEIGHT - 17, MAP_HEIGHT - 10)];
    if (Math.random() < 0.65) vHalls.push(rnd(32, MAP_WIDTH - 33));
    if (Math.random() < 0.65) hHalls.push(rnd(22, MAP_HEIGHT - 23));

    const vMin = Math.min(...vHalls), vMax = Math.max(...vHalls);
    const hMin = Math.min(...hHalls), hMax = Math.max(...hHalls);

    vHalls.forEach(hx => {
        const yA = Math.max(2, hMin - rnd(0, 4)), yB = Math.min(MAP_HEIGHT - 3, hMax + rnd(0, 4));
        for (let y = yA; y <= yB; y++) grid[y][hx] = '0';
        rooms.push({ x: hx, y: yA, w: 1, h: yB - yA + 1, centerX: hx, centerY: (yA + yB) >> 1, label: "Hauptflur" });
    });
    hHalls.forEach(hy => {
        const xA = Math.max(2, vMin - rnd(0, 4)), xB = Math.min(MAP_WIDTH - 3, vMax + rnd(0, 4));
        for (let x = xA; x <= xB; x++) grid[hy][x] = '0';
        rooms.push({ x: xA, y: hy, w: xB - xA + 1, h: 1, centerX: (xA + xB) >> 1, centerY: hy, label: "Hauptflur" });
    });

    // --- 2. HILFSFUNKTIONEN ---
    const addRoom = (x, y, w, h, label) => {
        // Wand-Typ je nach Raum-Label für unterschiedliche Optik
        let wallChar = '1';
        if (label === "Küche") wallChar = 'K';
        else if (label.startsWith("Schlafzimmer")) wallChar = 'S';
        else if (label === "Wohnzimmer") wallChar = 'W';
        else if (label === "Bad") wallChar = 'B';

        for (let iy = y - 1; iy <= y + h; iy++)
            for (let ix = x - 1; ix <= x + w; ix++)
                if (iy >= 0 && iy < MAP_HEIGHT && ix >= 0 && ix < MAP_WIDTH && grid[iy][ix] === '1') grid[iy][ix] = wallChar;

        for (let iy = y; iy < y + h; iy++)
            for (let ix = x; ix < x + w; ix++)
                grid[iy][ix] = '0';

        const roomObj = { x, y, w, h, centerX: Math.floor(x + w / 2), centerY: Math.floor(y + h / 2), label };
        rooms.push(roomObj);
        return roomObj;
    };

    const isWallChar = ch => ch === '1' || 'KSWB'.includes(ch);

    const addDoor = (x, y) => {
        if (y < 1 || y >= MAP_HEIGHT - 1 || x < 1 || x >= MAP_WIDTH - 1) return;
        if (vHalls.includes(x) || hHalls.includes(y)) return; // nie direkt im Hauptflur

        // Tür nur in einem 1 Kachel breiten Engpass (Wände links/rechts oder oben/unten)
        const hasWallH = isWallChar(grid[y][x - 1]) && isWallChar(grid[y][x + 1]);
        const hasWallV = isWallChar(grid[y - 1][x]) && isWallChar(grid[y + 1][x]);
        if (!hasWallH && !hasWallV) return;

        // Keine Türen direkt nebeneinander
        for (let dy = -1; dy <= 1; dy++)
            for (let dx = -1; dx <= 1; dx++)
                if (grid[y + dy][x + dx] === '2') return;
        grid[y][x] = '2';
    };

    // Raum + 1 Kachel Puffer dürfen keine bestehenden Böden/Türen berühren
    const isCarvable = (rx, ry, rw, rh) => {
        if (rx < 2 || ry < 2 || rx + rw > MAP_WIDTH - 2 || ry + rh > MAP_HEIGHT - 2) return false;
        for (let y = ry - 1; y <= ry + rh; y++)
            for (let x = rx - 1; x <= rx + rw; x++)
                if (grid[y][x] === '0' || grid[y][x] === '2') return false;
        return true;
    };

    // --- 3. VERBINDUNGSPUNKTE entlang aller Flure sammeln und mischen ---
    const conns = [];
    vHalls.forEach(hx => {
        for (let y = 3; y < MAP_HEIGHT - 3; y += 2) {
            if (grid[y][hx] !== '0') continue;
            conns.push({ x: hx - 1, y: y, dx: -1, dy: 0 });
            conns.push({ x: hx + 1, y: y, dx: 1, dy: 0 });
        }
    });
    hHalls.forEach(hy => {
        for (let x = 3; x < MAP_WIDTH - 3; x += 2) {
            if (grid[hy][x] !== '0') continue;
            conns.push({ x: x, y: hy - 1, dx: 0, dy: -1 });
            conns.push({ x: x, y: hy + 1, dx: 0, dy: 1 });
        }
    });
    for (let i = conns.length - 1; i > 0; i--) {
        const j = (Math.random() * (i + 1)) | 0;
        [conns[i], conns[j]] = [conns[j], conns[i]];
    }

    // --- 4. RÄUME mit Stichfluren + Türen an die Flure hängen ---
    const labelPool = ["Bibliothek", "Wohnzimmer", "Küche", "Speisesaal", "Schlafzimmer 1", "Lagerraum", "Bibliothek", "Schlafzimmer 2", "Bad", "Lagerraum", "Schlafzimmer 3"];
    let placed = 0;
    for (const conn of conns) {
        if (placed >= 34) break;
        const rw = rnd(2, 6), rh = rnd(2, 5);
        const gap = rnd(1, 2); // Länge des Stichflurs zwischen Flur und Raum
        let rx, ry;
        if (conn.dx !== 0) {
            rx = conn.dx < 0 ? conn.x - gap - rw + 1 : conn.x + gap;
            ry = conn.y - rnd(0, rh - 1);
        } else {
            ry = conn.dy < 0 ? conn.y - gap - rh + 1 : conn.y + gap;
            rx = conn.x - rnd(0, rw - 1);
        }

        if (!isCarvable(rx, ry, rw, rh)) continue;

        // Stichflur muss durch massive Wand führen (keine Doppel-Durchbrüche)
        let ok = true;
        for (let k = 0; k < gap && ok; k++) {
            const sx = conn.x + conn.dx * k, sy = conn.y + conn.dy * k;
            if (!isWallChar(grid[sy][sx])) ok = false;
            const lx = conn.dx !== 0 ? 0 : 1, ly = conn.dx !== 0 ? 1 : 0;
            if (grid[sy + ly][sx + lx] === '0' || grid[sy - ly][sx - lx] === '0') ok = false;
        }
        if (!ok) continue;

        const label = (labelPool.length && Math.random() < 0.55) ? labelPool.shift() : "Kammer";
        const room = addRoom(rx, ry, rw, rh, label);

        // Stichflur carven, Tür direkt am Raumeingang
        for (let k = 0; k < gap; k++) grid[conn.y + conn.dy * k][conn.x + conn.dx * k] = '0';
        addDoor(conn.x + conn.dx * (gap - 1), conn.y + conn.dy * (gap - 1));

        // Säule / Möbel-Block in großen Räumen (mehr Deckung, mehr Grusel)
        if (rw >= 4 && rh >= 4 && Math.random() < 0.4) {
            const px2 = rx + rnd(1, rw - 2), py2 = ry + rnd(1, rh - 2);
            // Raum-Mitte freihalten (dort spawnen Schlüssel/Monster)
            if (px2 !== room.centerX || py2 !== room.centerY) grid[py2][px2] = '1';
        }
        placed++;
    }

    // --- 5. LOOP-TÜREN: direkt benachbarte Räume verbinden (gegen Sackgassen) ---
    const habitable = rooms.filter(r => r.label !== "Hauptflur");
    for (let i = 0; i < habitable.length; i++) {
        for (let j = i + 1; j < habitable.length; j++) {
            // Weniger Schleifen-Türen (0.3) → übersichtlicher, bessere Orientierung
            if (Math.random() > 0.3) continue;
            const a = habitable[i], b = habitable[j];
            if (b.x === a.x + a.w + 1 || a.x === b.x + b.w + 1) {
                // Genau 1 Wand zwischen den Räumen (vertikal geteilt)
                const wallX = b.x === a.x + a.w + 1 ? a.x + a.w : b.x + b.w;
                const oS = Math.max(a.y, b.y), oE = Math.min(a.y + a.h, b.y + b.h);
                if (oE - oS >= 2) addDoor(wallX, (oS + oE) >> 1);
            } else if (b.y === a.y + a.h + 1 || a.y === b.y + b.h + 1) {
                const wallY = b.y === a.y + a.h + 1 ? a.y + a.h : b.y + b.h;
                const oS = Math.max(a.x, b.x), oE = Math.min(a.x + a.w, b.x + b.w);
                if (oE - oS >= 2) addDoor((oS + oE) >> 1, wallY);
            }
        }
    }

    // --- 6. FLUCHTWEGE GARANTIEREN ---
    // Jeder Raum bekommt nach Möglichkeit eine ZWEITE Verbindung. Dadurch kann
    // ein Monster nie den einzigen Zugang zu einem Raum (und damit zu Schlüssel
    // oder Treppe) dauerhaft versperren — es gibt immer einen Ausweichweg.
    const isWalkTile = ch => ch === '0' || ch === '2';

    const analyseRoom = (r) => {
        const border = [];
        for (let ix = r.x; ix < r.x + r.w; ix++) {
            border.push([ix, r.y - 1, 0, -1]);     // obere Wand, Öffnung nach oben
            border.push([ix, r.y + r.h, 0, 1]);    // untere Wand, Öffnung nach unten
        }
        for (let iy = r.y; iy < r.y + r.h; iy++) {
            border.push([r.x - 1, iy, -1, 0]);     // linke Wand
            border.push([r.x + r.w, iy, 1, 0]);    // rechte Wand
        }
        let exits = 0;
        const candidates = [];
        for (const [bx, by, ox, oy] of border) {
            if (bx < 1 || by < 1 || bx >= MAP_WIDTH - 1 || by >= MAP_HEIGHT - 1) continue;
            if (isWalkTile(grid[by][bx])) { exits++; continue; } // bereits offen / Tür
            // Kandidat: Wand mit Raumboden innen, begehbarer Fläche außen
            // und Wänden seitlich (sauberer 1-Kachel-Durchgang).
            const ax = bx + ox, ay = by + oy;
            if (ax < 0 || ay < 0 || ax >= MAP_WIDTH || ay >= MAP_HEIGHT) continue;
            if (!isWalkTile(grid[ay][ax])) continue;
            if (grid[by - oy][bx - ox] !== '0') continue;
            const sx = oy, sy = ox; // senkrecht zur Öffnungsrichtung
            if (!isWallChar(grid[by + sy][bx + sx]) || !isWallChar(grid[by - sy][bx - sx])) continue;
            candidates.push([bx, by]);
        }
        return { exits, candidates };
    };

    for (const r of habitable) {
        let { exits, candidates } = analyseRoom(r);
        for (let c = 0; c < candidates.length && exits < 2; c++) {
            const [bx, by] = candidates[c];
            let nearDoor = false;
            for (let dy = -1; dy <= 1 && !nearDoor; dy++)
                for (let dx2 = -1; dx2 <= 1; dx2++)
                    if (grid[by + dy][bx + dx2] === '2') { nearDoor = true; break; }
            if (nearDoor) continue;
            grid[by][bx] = '2';
            exits++;
        }
    }

    return { grid: grid, rooms: rooms };
}

function initGameWorld() {
    maps = [];
    keysData = [];
    enemiesData = [];
    bloodSplattersData = [];
    doorsData = []; // doorsData bei jedem Start zurücksetzen
    torchesData = [];
    windowsData = [];
    corpsesData = [];
    stairsData = [];
    furnitureData = [];
    closetsData = [];
    _collProps = null; _collPropsFloor = -1;
    hideState.active = false; hideState.minigame = false; hideState.closet = null;
    floorRooms = [];

    // Reset Player Stats
    player.keys = 0;
    player.stamina = player.maxStamina;
    stairsCooldown = 0; // Sicherstellen, dass Treppen sofort benutzbar sind

    const settings = DIFFICULTY_SETTINGS[currentDifficulty];
    TOTAL_KEYS = settings.keys;
    const floorCount = settings.floors;

    for (let f = 0; f < floorCount; f++) {
        let gen = createRandomFloor();
        let grid = gen.grid;
        let rooms = gen.rooms;

        // Filtert Flure aus, damit Treppen und Startpunkte nur in "echten" Räumen landen
        let habitableRooms = rooms.filter(r => r.label !== "Hauptflur");
        floorRooms[f] = habitableRooms; // für den späteren Exit-Spawn merken

        if (f === 0) {
            let rStart = habitableRooms[0];
            player.x = rStart.centerX * TILE_SIZE;
            player.y = rStart.centerY * TILE_SIZE;
        }

        // Treppe nach oben (überall außer in der letzten Etage)
        if (f < floorCount - 1) {
            let rUp = habitableRooms[Math.floor(Math.random() * (habitableRooms.length - 2)) + 1];
            grid[rUp.y + Math.floor(Math.random() * rUp.h)][rUp.x + Math.floor(Math.random() * rUp.w)] = 'U';
        }

        // Treppe nach unten (überall außer in der ersten Etage)
        if (f > 0) {
            let rDown = habitableRooms[0];
            grid[rDown.y + Math.floor(Math.random() * rDown.h)][rDown.x + Math.floor(Math.random() * rDown.w)] = 'D';
        }

        // Der Ausgang wird NICHT mehr hier platziert — die weiße Exit-Tür
        // erscheint erst zufällig auf der Karte, wenn alle Schlüssel gesammelt sind
        // (siehe spawnExitDoor)

        let availableRooms = habitableRooms.slice(1, habitableRooms.length - 1);
        for (let i = availableRooms.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [availableRooms[i], availableRooms[j]] = [availableRooms[j], availableRooms[i]];
        }

        // Schlüssel gleichmäßig auf Etagen verteilen
        let numKeys = Math.ceil(TOTAL_KEYS / floorCount);
        if (f === floorCount - 1) numKeys = Math.max(1, TOTAL_KEYS - (numKeys * (floorCount - 1))); // Rest für letzte Etage (mindestens 1)

        let keysPlacedThisFloor = 0;
        // Mindestabstand zwischen Schlüsseln (ca. 18 Kacheln), um sie weit zu verteilen
        const MIN_KEY_DIST = TILE_SIZE * 18;

        for (let r of availableRooms) {
            if (keysPlacedThisFloor >= numKeys) break;

            let kx = r.centerX * TILE_SIZE;
            let ky = r.centerY * TILE_SIZE;

            // Prüfe Abstand zu bereits platzierten Schlüsseln auf DIESER Etage
            let tooClose = false;
            for (let i = keysData.length - keysPlacedThisFloor; i < keysData.length; i++) {
                let otherKey = keysData[i];
                if (Math.hypot(kx - otherKey.x, ky - otherKey.y) < MIN_KEY_DIST) {
                    tooClose = true;
                    break;
                }
            }

            if (!tooClose) {
                keysData.push({
                    x: kx + (Math.random() * 20 - 10),
                    y: ky + (Math.random() * 20 - 10),
                    floor: f,
                    collected: false
                });
                keysPlacedThisFloor++;
            }
        }

        // Fallback: Falls wegen des Abstands-Checks nicht genug Schlüssel platziert werden konnten
        if (keysPlacedThisFloor < numKeys) {
            for (let r of availableRooms) {
                if (keysPlacedThisFloor >= numKeys) break;
                let hasKey = keysData.some(k => k.floor === f && Math.abs(k.x - r.centerX * TILE_SIZE) < 10);
                if (!hasKey) {
                    keysData.push({ x: r.centerX * TILE_SIZE, y: r.centerY * TILE_SIZE, floor: f, collected: false });
                    keysPlacedThisFloor++;
                }
            }
        }

        let numEnemies = Math.round(settings.enemiesPerFloor);
        for (let e = 0; e < numEnemies; e++) {
            // Wähle einen zufälligen Raum, aber vermeide den Start- und Zielraum jeder Etage
            let r = null;
            let attempts = 0;
            const MIN_DIST = TILE_SIZE * 10; // Erhöht auf 10 Kacheln Sicherheitsabstand
            const spawnX = habitableRooms[0].centerX * TILE_SIZE;
            const spawnY = habitableRooms[0].centerY * TILE_SIZE;

            while (attempts < 100) { // Versuche, einen geeigneten Raum zu finden
                // Wähle einen zufälligen Raum, der nicht der Startraum ist
                let roomIdx = Math.floor(Math.random() * habitableRooms.length);
                let potentialRoom = habitableRooms[roomIdx];

                // Vermeide den Startraum des Spielers
                if (potentialRoom === habitableRooms[0]) {
                    attempts++;
                    continue;
                }

                let dist = Math.hypot(potentialRoom.centerX * TILE_SIZE - player.x, potentialRoom.centerY * TILE_SIZE - player.y);

                // Prüfe den Mindestabstand zum Spieler
                if (dist >= MIN_DIST) {
                    r = potentialRoom;
                    break;
                }
                attempts++;
            }
            // Fallback: Wenn nach vielen Versuchen kein geeigneter Raum gefunden wurde, nimm einen zufälligen, der nicht der Startraum ist.
            if (!r) {
                r = habitableRooms[Math.floor(Math.random() * habitableRooms.length)];
                if (r === habitableRooms[0] && habitableRooms.length > 1) r = habitableRooms[1]; // Nimm den nächsten, wenn es der Startraum ist
            }

            enemiesData.push({
                x: r.centerX * TILE_SIZE,
                y: r.centerY * TILE_SIZE,
                floor: f,
                baseSpeed: settings.speed + (f * 0.3),
                radius: 26 + f * 2, // Größer = bedrohlichere Erscheinung

                state: 'patrol',
                targetX: 0,
                targetY: 0,
                chaseTime: 0,
                wanderAngle: Math.random() * Math.PI * 2,
                lastKnownX: r.centerX * TILE_SIZE,
                lastKnownY: r.centerY * TILE_SIZE,
                chaseSoundTimer: 0
            });
        }

        // Türen + Treppen dieser Etage erfassen
        for (let y = 0; y < MAP_HEIGHT; y++) {
            for (let x = 0; x < MAP_WIDTH; x++) {
                if (grid[y][x] === '2') {
                    // open: 0 = zu, 1 = komplett aufgeschoben (Schiebe-Animation)
                    doorsData.push({ x: x, y: y, floor: f, state: 'closed', open: 0, timer: 0 });
                } else if (grid[y][x] === 'U' || grid[y][x] === 'D') {
                    stairsData.push({ x: x, y: y, floor: f, dir: grid[y][x] });
                }
            }
        }

        // Generate Torches
        for (let y = 1; y < MAP_HEIGHT - 1; y++) {
            for (let x = 1; x < MAP_WIDTH - 1; x++) {
                if (grid[y][x] === '1') {
                    let floorAdjacent = 0;
                    if (grid[y + 1][x] === '0') floorAdjacent++;
                    if (grid[y - 1][x] === '0') floorAdjacent++;
                    if (grid[y][x + 1] === '0') floorAdjacent++;
                    if (grid[y][x - 1] === '0') floorAdjacent++;

                    if (floorAdjacent > 0) {
                        if (Math.random() < 0.04) {
                            torchesData.push({
                                x: x * TILE_SIZE + TILE_SIZE / 2,
                                y: y * TILE_SIZE + TILE_SIZE / 2,
                                floor: f,
                                flickerCounter: Math.random() * 100
                            });
                        } else if (Math.random() < 0.008) {
                            // Only make it a window if it's not a torch
                            windowsData.push({
                                x: x,
                                y: y,
                                floor: f
                            });
                        }
                    }
                }
            }
        }

        // Leichen / Skelette in einige Räume legen (Grusel-Deko, ~30% der Räume).
        // Nicht im Startraum (i=0), damit der Spieler nicht direkt auf einer Leiche steht.
        for (let ri = 1; ri < habitableRooms.length; ri++) {
            if (Math.random() > 0.30) continue;
            const room = habitableRooms[ri];
            // Position innerhalb des Raums, leicht aus der Mitte versetzt
            const tx = room.x + Math.floor(Math.random() * room.w);
            const ty = room.y + Math.floor(Math.random() * room.h);
            if (grid[ty] && grid[ty][tx] === '0') {
                const type = Math.random() < 0.5 ? 'skeleton' : 'gore';
                corpsesData.push({
                    x: tx * TILE_SIZE + TILE_SIZE / 2 + (Math.random() * 20 - 10),
                    y: ty * TILE_SIZE + TILE_SIZE / 2 + (Math.random() * 20 - 10),
                    floor: f,
                    type: type,
                    seed: Math.random() * 1000,
                    angle: Math.random() * Math.PI * 2
                });
            }
        }

        // ----------------------------------------------------------------------
        // KONTEXT-MÖBEL: Jeder Raum bekommt zu seiner Funktion passende Möbel.
        // (Bibliothek → viele Bücherregale an den Wänden, Lager → Kisten/Fässer,
        //  Speisesaal/Wohnzimmer → Tisch mit Stühlen, Schlafzimmer → Stuhl/Regal …)
        // ----------------------------------------------------------------------
        const COLL_BY_TYPE = {
            table: [0.33, 0.21], crate: [0.24, 0.24], barrel: [0.22, 0.22],
            shelf: [0.26, 0.15], chair: [0.17, 0.17]
        };
        const addFurn = (tx, ty, type, angle) => {
            if (!tileFreeForProp(grid, tx, ty)) return false;
            const wx = tx * TILE_SIZE + TILE_SIZE / 2, wy = ty * TILE_SIZE + TILE_SIZE / 2;
            // doppelte Belegung derselben Kachel vermeiden
            for (const fu of furnitureData) {
                if (fu.floor === f && Math.abs(fu.x - wx) < TILE_SIZE * 0.5 && Math.abs(fu.y - wy) < TILE_SIZE * 0.5) return false;
            }
            // niemals auf einen Schlüssel stellen (sonst ist er hinter einem soliden Möbel)
            for (const k of keysData) {
                if (k.floor === f && Math.abs(k.x - wx) < TILE_SIZE * 0.6 && Math.abs(k.y - wy) < TILE_SIZE * 0.6) return false;
            }
            const cbt = COLL_BY_TYPE[type] || [0.24, 0.24];
            furnitureData.push({
                x: wx + (Math.random() * 8 - 4),
                y: wy + (Math.random() * 8 - 4),
                floor: f, type, seed: Math.random() * 1000,
                angle: (angle === undefined) ? Math.random() * Math.PI * 2 : angle,
                collHW: cbt[0] * TILE_SIZE, collHD: cbt[1] * TILE_SIZE
            });
            return true;
        };
        // Rand-(Wand-)Kacheln eines Raums mit empfohlener Ausrichtung (Breite längs der Wand)
        const edgeTilesOf = (room) => {
            const t = [];
            for (let x = room.x; x < room.x + room.w; x++) {
                t.push([x, room.y, 0]);
                if (room.h > 1) t.push([x, room.y + room.h - 1, 0]);
            }
            for (let y = room.y + 1; y < room.y + room.h - 1; y++) {
                t.push([room.x, y, Math.PI / 2]);
                if (room.w > 1) t.push([room.x + room.w - 1, y, Math.PI / 2]);
            }
            for (let i = t.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0;[t[i], t[j]] = [t[j], t[i]]; }
            return t;
        };

        for (let ri = 1; ri < habitableRooms.length; ri++) {
            const room = habitableRooms[ri];
            const label = room.label || "";
            let theme = 'misc';
            if (label.startsWith("Bibliothek")) theme = 'library';
            else if (label === "Küche") theme = 'kitchen';
            else if (label === "Wohnzimmer") theme = 'living';
            else if (label === "Speisesaal") theme = 'dining';
            else if (label.startsWith("Schlafzimmer")) theme = 'bedroom';
            else if (label === "Bad") theme = 'bath';
            else if (label === "Lagerraum") theme = 'storage';
            else if (label === "Kammer") theme = Math.random() < 0.6 ? 'storage' : 'misc';

            const cx = room.x + (room.w >> 1), cy = room.y + (room.h >> 1);
            const edges = edgeTilesOf(room);
            const isCenter = (tx, ty) => (tx === cx && ty === cy);

            if (theme === 'library') {
                // Viele Bücherregale entlang der Wände
                let want = Math.max(3, Math.floor(edges.length * 0.7));
                for (const [tx, ty, ang] of edges) {
                    if (want <= 0) break;
                    if (isCenter(tx, ty)) continue;
                    if (addFurn(tx, ty, 'shelf', ang)) want--;
                }
                // Lesetisch + Stuhl in der Mitte
                if (room.w >= 3 && room.h >= 3) {
                    addFurn(cx, cy, 'table');
                    addFurn(cx + (cx + 1 < room.x + room.w ? 1 : -1), cy, 'chair', Math.PI);
                }
            } else if (theme === 'storage') {
                let want = Math.max(3, Math.floor(edges.length * 0.55));
                for (const [tx, ty, ang] of edges) {
                    if (want <= 0) break;
                    if (isCenter(tx, ty)) continue;
                    const r = Math.random();
                    const t = r < 0.45 ? 'crate' : (r < 0.8 ? 'barrel' : 'shelf');
                    if (addFurn(tx, ty, t, ang)) want--;
                }
                for (let k = 0; k < 2; k++) {
                    const tx = room.x + (Math.random() * room.w | 0), ty = room.y + (Math.random() * room.h | 0);
                    if (!isCenter(tx, ty)) addFurn(tx, ty, Math.random() < 0.5 ? 'crate' : 'barrel');
                }
            } else if (theme === 'kitchen') {
                addFurn(cx, cy, 'table');
                let want = Math.max(2, Math.floor(edges.length * 0.4));
                for (const [tx, ty, ang] of edges) {
                    if (want <= 0) break;
                    if (isCenter(tx, ty)) continue;
                    if (addFurn(tx, ty, Math.random() < 0.5 ? 'crate' : 'barrel', ang)) want--;
                }
            } else if (theme === 'dining' || theme === 'living') {
                addFurn(cx, cy, 'table');
                const around = [[cx - 1, cy], [cx + 1, cy], [cx, cy - 1], [cx, cy + 1]];
                let chairs = theme === 'dining' ? 4 : 2;
                for (const [tx, ty] of around) {
                    if (chairs <= 0) break;
                    if (tx >= room.x && tx < room.x + room.w && ty >= room.y && ty < room.y + room.h) {
                        if (addFurn(tx, ty, 'chair', Math.atan2(cy - ty, cx - tx))) chairs--;
                    }
                }
                for (const [tx, ty, ang] of edges) { if (!isCenter(tx, ty) && addFurn(tx, ty, 'shelf', ang)) break; }
            } else if (theme === 'bedroom') {
                addFurn(cx, cy, 'chair');
                let put = 0;
                for (const [tx, ty, ang] of edges) {
                    if (put >= 2) break;
                    if (isCenter(tx, ty)) continue;
                    if (addFurn(tx, ty, Math.random() < 0.5 ? 'shelf' : 'table', ang)) put++;
                }
            } else if (theme === 'bath') {
                if (Math.random() < 0.6 && edges.length) {
                    const e = edges[0];
                    addFurn(e[0], e[1], Math.random() < 0.5 ? 'crate' : 'barrel', e[2]);
                }
            } else { // misc / Kammer
                const types = ['table', 'crate', 'barrel', 'shelf', 'chair'];
                const n = 1 + (Math.random() * 2 | 0);
                for (let k = 0; k < n; k++) {
                    const e = edges[k];
                    const t = types[(Math.random() * types.length) | 0];
                    if (e && !isCenter(e[0], e[1])) addFurn(e[0], e[1], t, e[2]);
                }
            }
        }

        // Schränke zum Verstecken (~40% der Räume) — an der Westwand, auf einer
        // Kachel, die noch frei von Möbeln ist (sonst überlappen sich solide Objekte).
        const tileHasFurniture = (tx, ty) => {
            const wx = tx * TILE_SIZE + TILE_SIZE / 2, wy = ty * TILE_SIZE + TILE_SIZE / 2;
            for (const fu of furnitureData) {
                if (fu.floor === f && Math.abs(fu.x - wx) < TILE_SIZE * 0.6 && Math.abs(fu.y - wy) < TILE_SIZE * 0.6) return true;
            }
            return false;
        };
        for (let ri = 1; ri < habitableRooms.length; ri++) {
            if (Math.random() > 0.4) continue;
            const room = habitableRooms[ri];
            const tx = room.x; // linke Innenspalte → steht an der Wand (room.x-1)
            // ein paar Zeilen durchprobieren, bis eine freie Kachel gefunden ist
            const rows = [];
            for (let y = room.y; y < room.y + room.h; y++) rows.push(y);
            for (let i = rows.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0;[rows[i], rows[j]] = [rows[j], rows[i]]; }
            for (const ty of rows) {
                if (tileFreeForProp(grid, tx, ty) && !tileHasFurniture(tx, ty)) {
                    closetsData.push({
                        x: tx * TILE_SIZE + TILE_SIZE * 0.42,
                        y: ty * TILE_SIZE + TILE_SIZE * 0.5,
                        floor: f,
                        seed: Math.random() * 1000,
                        angle: 0,
                        collHW: 0.27 * TILE_SIZE,
                        collHD: 0.20 * TILE_SIZE
                    });
                    break;
                }
            }
        }

        maps[f] = grid;
    }

    currentFloor = 0;
    map = maps[currentFloor];

    // Initialisiere Fog of War für jede Etage
    exploredTiles = [];
    for (let f = 0; f < maps.length; f++) {
        exploredTiles.push(new Set());
    }

    // Regionen (Räume/Flure) für die raumbasierte Minimap-Aufdeckung
    floorRegions = [];
    revealedRegions = [];
    for (let f = 0; f < maps.length; f++) {
        computeFloorRegions(f);
        revealedRegions.push(new Set());
    }

    // Schnelle Lookups für Türen und Fenster (Performance im Raycaster)
    doorLookup = maps.map(() => new Map());
    doorsData.forEach(d => doorLookup[d.floor].set(d.y * MAP_WIDTH + d.x, d));
    windowLookup = maps.map(() => new Set());
    windowsData.forEach(w => windowLookup[w.floor].add(w.y * MAP_WIDTH + w.x));

    // Exit-Tür existiert erst, wenn alle Schlüssel gesammelt wurden
    exitSpawned = false;
    exitFloor = -1;
    exitTileX = -1; exitTileY = -1;
    exitFloorName = '';
    minimapCacheFloor = -1; // Minimap-Cache neu aufbauen

    updateMessage(); // Sofortige Aktualisierung der UI
}

// Flood-Fill: teilt jede Etage in Regionen (Räume & Flure), getrennt durch Türen.
// Die Minimap deckt immer genau die Region auf, in der der Spieler wirklich steht.
function computeFloorRegions(f) {
    const grid = maps[f];
    const reg = new Int32Array(MAP_WIDTH * MAP_HEIGHT).fill(-1);
    const isOpen = t => t === '0' || t === 'U' || t === 'D' || t === 'E';
    let nextId = 0;
    const stack = [];

    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const idx = y * MAP_WIDTH + x;
            if (reg[idx] !== -1 || !isOpen(grid[y][x])) continue;
            reg[idx] = nextId;
            stack.push(idx);
            while (stack.length) {
                const c = stack.pop();
                const cy = (c / MAP_WIDTH) | 0, cx = c % MAP_WIDTH;
                for (const [ddx, ddy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                    const nx = cx + ddx, ny = cy + ddy;
                    if (nx < 0 || ny < 0 || nx >= MAP_WIDTH || ny >= MAP_HEIGHT) continue;
                    const n = ny * MAP_WIDTH + nx;
                    if (reg[n] === -1 && isOpen(grid[ny][nx])) {
                        reg[n] = nextId;
                        stack.push(n);
                    }
                }
            }
            nextId++;
        }
    }
    floorRegions[f] = reg;
}

// Deckt eine komplette Region auf der Minimap auf (inkl. umgebender Wände und Türen)
function revealRegion(f, rid) {
    const set = exploredTiles[f];
    const reg = floorRegions[f];
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            if (reg[y * MAP_WIDTH + x] !== rid) continue;
            set.add(y * MAP_WIDTH + x);
            for (let dy = -1; dy <= 1; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    const nx = x + dx, ny = y + dy;
                    if (nx >= 0 && ny >= 0 && nx < MAP_WIDTH && ny < MAP_HEIGHT && reg[ny * MAP_WIDTH + nx] !== rid) {
                        set.add(ny * MAP_WIDTH + nx);
                    }
                }
            }
        }
    }
}

// Lässt die weiße Exit-Tür an einer zufälligen Stelle der Karte erscheinen,
// sobald alle Schlüssel eingesammelt wurden
function spawnExitDoor() {
    if (exitSpawned || !maps.length) return;

    exitFloor = Math.floor(Math.random() * maps.length);
    const candidates = floorRooms[exitFloor] || [];

    for (let tries = 0; tries < 80 && candidates.length; tries++) {
        const r = candidates[(Math.random() * candidates.length) | 0];
        const x = r.x + ((Math.random() * r.w) | 0);
        const y = r.y + ((Math.random() * r.h) | 0);
        if (maps[exitFloor][y][x] !== '0') continue;
        // Nicht direkt neben dem Spieler erscheinen lassen
        if (exitFloor === currentFloor &&
            Math.hypot(player.x - (x + 0.5) * TILE_SIZE, player.y - (y + 0.5) * TILE_SIZE) < TILE_SIZE * 10) continue;
        maps[exitFloor][y][x] = 'E';
        exitTileX = x; exitTileY = y;
        exitSpawned = true;
        break;
    }
    // Fallback: erste freie Bodenkachel
    if (!exitSpawned) {
        for (let y = 0; y < MAP_HEIGHT && !exitSpawned; y++) {
            for (let x = 0; x < MAP_WIDTH && !exitSpawned; x++) {
                if (maps[exitFloor][y][x] === '0') {
                    maps[exitFloor][y][x] = 'E';
                    exitTileX = x; exitTileY = y;
                    exitSpawned = true;
                }
            }
        }
    }

    const names = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor"];
    if (maps.length > 1 && exitFloor === maps.length - 1) exitFloorName = "Attic";
    else exitFloorName = names[exitFloor] || (exitFloor + ". Floor");

    minimapCacheFloor = -1; // Cache neu zeichnen (weiße Tür sichtbar machen)

    // Dramatischer Moment: Donnerschlag, wenn die Tür erscheint
    thunderState.active = true;
    thunderState.intensity = 1;
    thunderState.timer = 14;
    playThunderSound();
}

let mouse = { x: (canvas ? canvas.width : 800) / 2, y: (canvas ? canvas.height : 600) / 2 };
let keysPressed = {};
let gameState = 'start';
let stairsCooldown = 0;

// --- PAUSE (ESC-Menü) ---
let isPaused = false;
// Verhindert, dass ein GEWOLLTES Lösen des Mauszeigers (F-Taste) das Pause-Menü öffnet.
let _suppressAutoPause = false;

// Treppen-Zustand: nach einmaligem E-Druck klettert der Spieler automatisch
let stairAnim = { active: false, dir: 0, stepTimer: 0 };
// Edge-getriggerte Interaktionstaste (true nur für den Frame des Tastendrucks)
let interactPressed = false;

let jumpscareEffect = {
    active: false,
    timer: 0, // frames remaining for the effect
    maxTimer: 0, // total duration of the effect
    currentRedIntensity: 0 // 0 = no red, 1 = full red
};

// Schwierigkeits-Auswahl vor dem Start (Optional: Man könnte Buttons im HTML dafür haben)
// Hier setzen wir es beispielhaft über die URL oder einfach vor dem init:
function setDifficulty(level) {
    if (DIFFICULTY_SETTINGS[level]) {
        currentDifficulty = level;
        initGameWorld();
        const descEl = document.getElementById('difficulty-desc');
        if (descEl) {
            descEl.textContent = DIFFICULTY_SETTINGS[level].desc;

            // Animation neu triggern (durch Entfernen und Hinzufügen der Klasse)
            descEl.classList.remove('flicker-effect');
            void descEl.offsetWidth; // Force Reflow
            descEl.classList.add('flicker-effect');
        }
        const statsEl = document.getElementById('difficulty-stats');
        if (statsEl) {
            const s = DIFFICULTY_SETTINGS[level];
            const totalMonsters = s.floors * Math.round(s.enemiesPerFloor);
            statsEl.textContent = `Floors: ${s.floors} · Monsters: ${totalMonsters}`;
            statsEl.classList.remove('flicker-effect');
            void statsEl.offsetWidth;
            statsEl.classList.add('flicker-effect');
        }
    }
}

function spawnBloodSplatterNear(monster) {
    // Nur mit geringer Wahrscheinlichkeit spawnen (ca. alle 1-2 Sekunden während der Jagd)
    if (Math.random() > 0.02) return;

    const gx = Math.floor(monster.x / TILE_SIZE);
    const gy = Math.floor(monster.y / TILE_SIZE);

    // Prüfe die 4 Nachbarzellen auf Wände
    const directions = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }];
    for (let d of directions) {
        let nx = gx + d.x;
        let ny = gy + d.y;

        if (map[ny] && '1KSWB'.includes(map[ny][nx])) {
            bloodSplattersData.push({
                x: monster.x + d.x * (monster.radius + 2),
                y: monster.y + d.y * (monster.radius + 2),
                z: (Math.random() - 0.5) * TILE_SIZE * 0.5, // Zufällige Höhe an der Wand
                floor: monster.floor,
                size: 15 + Math.random() * 25,
                opacity: 0.8,
                timer: 1200 + Math.random() * 600 // Hält ca. 20-30 Sekunden
            });
            break; // Nur einen Spritzer pro Check
        }
    }
}

// Standard-Initialisierung
initGameWorld();

// Sound-Samples sofort im Hintergrund laden (während der Spieler noch im Menü ist)
loadSoundBank();

// Event-Listener für die Schwierigkeits-Buttons
// Nur die Buttons in der Schwierigkeitsliste — andere Buttons (Changelog-Close,
// Update, Try Again) tragen ebenfalls die Klasse .diff-btn und dürfen die
// Auswahl nicht verändern
document.querySelectorAll('.difficulty-menu .diff-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const level = btn.getAttribute('data-level');
        setDifficulty(level);
        document.querySelectorAll('.difficulty-menu .diff-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    });
});

const startBtn = document.getElementById('start-btn');
let gameStartTriggered = false; // verhindert doppelten Start (Enter + Klick)
if (startBtn) {
    startBtn.addEventListener('click', () => {
        if (gameStartTriggered) return;
        gameStartTriggered = true;
        canvas.requestPointerLock();
        // Hide start screen content, show warning
        document.getElementById('start-content').classList.add('hidden');
        const statsEl = document.getElementById('difficulty-stats');
        if (statsEl) statsEl.classList.add('hidden');
        const hintEl = document.getElementById('controls-hint');
        if (hintEl) hintEl.classList.add('hidden');

        let warningContent = document.getElementById('warning-content');
        if (warningContent) {
            warningContent.classList.remove('hidden');
            warningContent.classList.add('flicker-effect');
        }

        // 3 Sekunden Warnung anzeigen, dann das Intro-Tutorial (statt Ladebalken)
        setTimeout(async () => {
            if (warningContent) warningContent.classList.add('hidden');

            // Texturen still im Hintergrund laden, während das Tutorial läuft
            const loadPromise = (async () => {
                await Promise.race([texturesReady, new Promise(resolve => setTimeout(resolve, 8500))]);
                for (let i = 0; i < assetList.length; i++) {
                    await extractPixels(assetList[i].img, assetList[i].setter);
                }
            })();

            // Tutorial-Sequenz (Steuerung + Ziel), per gehaltener Leertaste überspringbar
            await runIntroTutorial();

            // Sicherstellen, dass die Texturen geladen sind, bevor es losgeht
            await loadPromise;

            let screen = document.getElementById('start-screen');
            if (screen) {
                screen.style.transition = 'opacity 1s ease';
                screen.style.opacity = '0';
            }
            gameState = 'playing';
            gameRunStartTime = Date.now();
            startAmbientSound(); // Bedrohlicher Drone + Wind starten
            showGameHud();
            showHudMinimap();
            showFloorPopup(0);
            updateMessage();
            setTimeout(() => screen && screen.classList.add('hidden'), 1000);
        }, 3000);
    });
}

// ==========================================
// "END GAME" — Beenden mit Bestätigung "Leave the Game?"
// ==========================================
function closeGameWebsite() {
    // Versuch, den Tab/das Fenster zu schließen. Browser erlauben window.close()
    // nur für per Skript geöffnete Fenster — der open('','_self')-Trick hilft bei
    // manchen. Schlägt es fehl, bleibt ein schwarzer Abschiedsschirm zurück.
    try { window.open('', '_self'); } catch (e) { }
    try { window.close(); } catch (e) { }
    setTimeout(() => {
        document.body.innerHTML =
            '<div style="position:fixed;inset:0;background:#000;color:#b91c1c;display:flex;' +
            'align-items:center;justify-content:center;font-family:\'Nosifer\',serif;' +
            'letter-spacing:4px;text-align:center;text-shadow:0 0 20px rgba(185,28,28,0.7);">' +
            'IT IS OVER.<br><br><span style="font-size:0.5em;color:#777;font-family:serif;">' +
            'You may now close this tab.</span></div>';
    }, 250);
}

(function wireQuitMenu() {
    const quitBtn = document.getElementById('quit-game-btn');
    const confirm = document.getElementById('quit-confirm');
    const yesBtn = document.getElementById('quit-yes');
    const noBtn = document.getElementById('quit-no');
    if (quitBtn && confirm) {
        quitBtn.addEventListener('click', () => confirm.classList.remove('hidden'));
    }
    if (yesBtn) yesBtn.addEventListener('click', closeGameWebsite);
    if (noBtn && confirm) {
        noBtn.addEventListener('click', () => confirm.classList.add('hidden'));
    }
})();

// ==========================================================================
// INTRO-TUTORIAL: erklärt Steuerung & Ziel (ersetzt den alten Ladebalken).
// Letzte Folie: geheimnisvolle Botschaft. Halten der Leertaste überspringt alles.
// ==========================================================================
// Zeichnet das stimmungsvolle Symbol einer Tutorial-Folie (animiert über t = Sekunden).
function drawTutIcon(g, kind, t) {
    const W = g.canvas.width, H = g.canvas.height, cx = W / 2, cy = H / 2;
    g.clearRect(0, 0, W, H);
    const pulse = 0.6 + 0.4 * Math.sin(t * 2.2); // 0.2..1 sanftes Pulsieren

    if (kind === 'house') {
        // Dunkle Hausfassade mit einer einzelnen, schwach glühenden Tür
        g.strokeStyle = 'rgba(120,110,100,0.55)'; g.lineWidth = 3;
        g.beginPath();
        g.moveTo(cx - 70, cy + 60); g.lineTo(cx - 70, cy - 30);
        g.lineTo(cx, cy - 70); g.lineTo(cx + 70, cy - 30);
        g.lineTo(cx + 70, cy + 60); g.stroke();
        // Türöffnung mit warmem, pulsierendem Licht
        const grd = g.createLinearGradient(0, cy - 20, 0, cy + 60);
        grd.addColorStop(0, `rgba(190,120,60,${0.25 + 0.35 * pulse})`);
        grd.addColorStop(1, 'rgba(20,10,5,0.9)');
        g.fillStyle = grd;
        g.fillRect(cx - 18, cy - 20, 36, 80);
        g.strokeStyle = 'rgba(150,90,40,0.6)'; g.lineWidth = 2;
        g.strokeRect(cx - 18, cy - 20, 36, 80);
    } else if (kind === 'key') {
        // Goldener Schlüssel mit Schimmer — DAS Sammelobjekt
        g.save();
        g.translate(cx, cy);
        g.rotate(-0.5);
        g.shadowColor = 'rgba(255,200,60,' + (0.4 + 0.5 * pulse) + ')';
        g.shadowBlur = 22 + 18 * pulse;
        g.fillStyle = '#ffd24a'; g.strokeStyle = '#9a6a10'; g.lineWidth = 3;
        // Ring
        g.beginPath(); g.arc(-46, 0, 22, 0, Math.PI * 2); g.fill(); g.stroke();
        g.shadowBlur = 0;
        g.globalCompositeOperation = 'destination-out';
        g.beginPath(); g.arc(-46, 0, 9, 0, Math.PI * 2); g.fill();
        g.globalCompositeOperation = 'source-over';
        // Schaft
        g.fillStyle = '#ffd24a';
        g.fillRect(-26, -6, 78, 12);
        g.strokeRect(-26, -6, 78, 12);
        // Bart (Zähne)
        g.fillRect(40, 6, 8, 16); g.strokeRect(40, 6, 8, 16);
        g.fillRect(24, 6, 8, 12); g.strokeRect(24, 6, 8, 12);
        // Glanzpunkt, der über den Schlüssel wandert
        const sx = -40 + ((t * 60) % 110);
        g.fillStyle = `rgba(255,255,255,${0.5 * pulse})`;
        g.fillRect(sx, -5, 6, 10);
        g.restore();
    } else if (kind === 'move') {
        // WASD-Tasten, nacheinander aufleuchtend
        const keys = [['W', 0, -1], ['A', -1, 0], ['S', 0, 0], ['D', 1, 0]];
        const lit = Math.floor(t * 3) % 4;
        g.font = 'bold 22px "Courier New", monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
        keys.forEach(([ch, gx, gy], i) => {
            const x = cx + gx * 44, y = cy + gy * 44 + 8;
            const on = i === lit;
            g.fillStyle = on ? 'rgba(60,20,20,0.9)' : 'rgba(25,25,28,0.85)';
            g.strokeStyle = on ? '#d04040' : '#555'; g.lineWidth = 2;
            g.beginPath(); g.rect(x - 18, y - 18, 36, 36); g.fill(); g.stroke();
            g.fillStyle = on ? '#fff' : '#aaa';
            g.fillText(ch, x, y + 1);
        });
    } else if (kind === 'interact') {
        // "E"-Taste neben einer sich öffnenden Tür
        g.strokeStyle = '#777'; g.lineWidth = 3;
        g.strokeRect(cx + 4, cy - 50, 56, 100);
        const open = (Math.sin(t * 1.6) * 0.5 + 0.5) * 38;
        g.fillStyle = 'rgba(30,18,10,0.9)';
        g.fillRect(cx + 6, cy - 48, 52 - open, 96);
        g.strokeStyle = '#6a4a28'; g.lineWidth = 2;
        g.strokeRect(cx + 6, cy - 48, 52 - open, 96);
        // E-Taste
        g.fillStyle = 'rgba(60,20,20,0.9)'; g.strokeStyle = '#d04040'; g.lineWidth = 2;
        g.beginPath(); g.rect(cx - 70, cy - 18, 40, 40); g.fill(); g.stroke();
        g.fillStyle = '#fff'; g.font = 'bold 24px "Courier New", monospace';
        g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText('E', cx - 50, cy + 3);
    } else if (kind === 'door') {
        // Leuchtende weiße Ausgangstür
        g.shadowColor = `rgba(255,255,255,${0.4 + 0.5 * pulse})`;
        g.shadowBlur = 30 + 24 * pulse;
        const grd = g.createLinearGradient(0, cy - 70, 0, cy + 70);
        grd.addColorStop(0, '#ffffff');
        grd.addColorStop(1, `rgba(200,210,255,${0.7 + 0.3 * pulse})`);
        g.fillStyle = grd;
        g.fillRect(cx - 34, cy - 70, 68, 140);
        g.shadowBlur = 0;
        g.strokeStyle = 'rgba(120,140,200,0.8)'; g.lineWidth = 2;
        g.strokeRect(cx - 34, cy - 70, 68, 140);
        g.fillStyle = 'rgba(120,140,200,0.9)';
        g.beginPath(); g.arc(cx + 22, cy, 4, 0, Math.PI * 2); g.fill();
    } else if (kind === 'eyes') {
        // Zwei glühende rote Augen in der Dunkelheit
        const flick = 0.55 + 0.45 * Math.abs(Math.sin(t * 5.3));
        for (const ex of [-28, 28]) {
            g.shadowColor = `rgba(220,30,30,${flick})`;
            g.shadowBlur = 26;
            g.fillStyle = `rgba(255,${40 + 40 * flick | 0},${30},${flick})`;
            g.beginPath();
            g.ellipse(cx + ex, cy, 14, 8 + 3 * Math.sin(t * 3 + ex), -0.2 * Math.sign(ex), 0, Math.PI * 2);
            g.fill();
            g.shadowBlur = 0;
            g.fillStyle = '#1a0000';
            g.beginPath(); g.ellipse(cx + ex, cy, 4, 6, 0, 0, Math.PI * 2); g.fill();
        }
    }
    // kind === 'none' → leer (finale Folie)
}

function runIntroTutorial() {
    return new Promise(resolve => {
        const slides = [
            { h: "The Hollow Halls", b: "You are trapped inside a house that feeds on the lost. Its halls shift, and the only way out is locked.", icon: 'house' },
            { h: "Find the Keys", b: "Golden keys are hidden across every floor. Collect them all — without them, the door stays shut forever.", icon: 'key' },
            { h: "Move & Look", b: "Walk with W A S D, look around with the mouse. Hold SHIFT to sprint — but your stamina runs dry fast.", icon: 'move' },
            { h: "Interact", b: "Press E to open doors, pick up keys and slip into closets. Open the map anytime with M.", icon: 'interact' },
            { h: "The Way Out", b: "Stairs connect the floors. Once you hold every key, a glowing white door appears — reach it to escape.", icon: 'door' },
            { h: "It Hunts", b: "Something stalks the dark. Break its line of sight, hide in closets — and never stay still for too long.", icon: 'eyes' },
            { h: "Don't let it get you.", b: "", final: true, icon: 'none' }
        ];
        const el = document.getElementById('intro-tutorial');
        if (!el) { resolve(); return; }
        const headEl = document.getElementById('tut-heading');
        const bodyEl = document.getElementById('tut-body');
        const slideEl = document.getElementById('tut-slide');
        const dotsEl = document.getElementById('tut-dots');
        const fillEl = document.getElementById('tut-skip-fill');
        const iconCv = document.getElementById('tut-icon');
        const ig = iconCv ? iconCv.getContext('2d') : null;

        dotsEl.innerHTML = slides.map(() => '<span></span>').join('');
        const dots = Array.from(dotsEl.children);

        el.classList.remove('hidden');
        let idx = -1, advanceTimer = null, done = false;
        let curIcon = 'house';
        const startMs = Date.now();

        function show(i) {
            idx = i;
            const s = slides[i];
            headEl.textContent = s.h;
            bodyEl.textContent = s.b;
            curIcon = s.icon || 'none';
            if (iconCv) iconCv.style.display = (curIcon === 'none') ? 'none' : 'block';
            el.classList.toggle('final', !!s.final);
            dots.forEach((d, k) => d.classList.toggle('on', k === i));
            // Fade-Animation neu auslösen
            slideEl.style.animation = 'none'; void slideEl.offsetWidth; slideEl.style.animation = '';
            // Stimmungsklang passend zur Folie
            try {
                if (curIcon === 'key') playKeyPickup();
                else if (curIcon === 'eyes') playMonsterGrowl(0.45, { lowpass: 380, wet: 0.7 });
                else if (s.final) playMonsterGrowl(0.7);
            } catch (e) { }
        }
        function advance() {
            if (done) return;
            if (idx + 1 >= slides.length) { finish(); return; }
            show(idx + 1);
            clearTimeout(advanceTimer);
            advanceTimer = setTimeout(advance, 4600);
        }
        function finish() {
            if (done) return;
            done = true;
            clearTimeout(advanceTimer);
            cancelAnimationFrame(raf);
            cancelAnimationFrame(iconRaf);
            window.removeEventListener('keydown', onKey);
            window.removeEventListener('keyup', onKeyUp);
            el.classList.add('hidden');
            el.classList.remove('final');
            resolve();
        }
        // Symbol-Animationsschleife (läuft, solange das Tutorial sichtbar ist)
        let iconRaf = 0;
        function drawIconLoop() {
            if (done) return;
            if (ig && curIcon !== 'none') drawTutIcon(ig, curIcon, (Date.now() - startMs) / 1000);
            iconRaf = requestAnimationFrame(drawIconLoop);
        }
        // Leertaste halten → überspringen
        let holding = false, holdStart = 0, raf = 0;
        function tick() {
            if (!holding) return;
            const p = Math.min(1, (Date.now() - holdStart) / 1100);
            fillEl.style.width = (p * 100) + '%';
            if (p >= 1) { finish(); return; }
            raf = requestAnimationFrame(tick);
        }
        function onKey(e) {
            if (e.code === 'Space' || e.key === ' ') {
                e.preventDefault();
                if (!holding) { holding = true; holdStart = Date.now(); tick(); }
            }
        }
        function onKeyUp(e) {
            if (e.code === 'Space' || e.key === ' ') {
                holding = false; fillEl.style.width = '0%'; cancelAnimationFrame(raf);
            }
        }
        window.addEventListener('keydown', onKey);
        window.addEventListener('keyup', onKeyUp);

        show(0);
        drawIconLoop();
        advanceTimer = setTimeout(advance, 4600);
    });
}

function updateMessage() {
    let msg = document.getElementById('message');
    // Im Hauptmenü keine Spiel-Nachricht einblenden (initGameWorld ruft das
    // auch bei jedem Schwierigkeits-Klick auf)
    if (gameState === 'start') {
        msg.classList.add('hidden');
        return;
    }
    let missing = TOTAL_KEYS - player.keys;
    msg.style.color = '#ffffff';
    msg.classList.remove('hidden');

    if (missing === 0) {
        msg.textContent = exitSpawned
            ? `A glowing white door has appeared — ${exitFloorName}!`
            : `Find the exit!`;
        msg.style.color = '#ffffff';
    } else {
        msg.textContent = `Find the keys! ${missing} remaining`;
    }
}
function showFloorPopup(floorIndex) {
    let names = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
    // Wenn es mehr als 5 Etagen gibt, generiere Namen dynamisch
    if (floorIndex === maps.length - 1) names[floorIndex] = "Attic";
    else if (!names[floorIndex]) names[floorIndex] = (floorIndex) + ". Floor";

    let popup = document.getElementById('floor-popup');
    popup.textContent = names[floorIndex];
    popup.classList.remove('hidden');
    popup.style.transition = 'none';
    popup.style.opacity = '1';

    void popup.offsetWidth;

    popup.style.transition = 'opacity 2s ease-out';
    popup.style.opacity = '0';

    setTimeout(() => {
        if (popup.style.opacity === '0') popup.classList.add('hidden');
    }, 2000);
}

let jumpscareFrame = 0;
let gameRunStartTime = 0;

// ==========================================
// GEMEINSAMES MONSTER-MODELL
// Zeichnet das Ingame-Monster in beliebigen Canvas-Kontext.
// Wird vom Raycaster (Sprite), vom Jumpscare und vom Todesbildschirm benutzt,
// damit überall dasselbe Wesen zu sehen ist.
// g = Canvas-Kontext, cx = horizontale Mitte, top = Oberkante,
// w/h = Sprite-Maße, opts = { isChase, phase, t, twitchScale }
// ==========================================
function drawMonsterModel(g, cx, top, w, h, opts = {}) {
    const t = (opts.t !== undefined) ? opts.t : Date.now() / 1000;
    const isChase = !!opts.isChase;
    const phase = opts.phase || 0;
    const twitchScale = (opts.twitchScale !== undefined) ? opts.twitchScale : 1;

    // Ruckartige Zuckungen: springen mehrmals pro Sekunde auf neue Werte
    // (wirkt wie kaputtes Stop-Motion — deutlich unheimlicher als glattes Wackeln)
    const twitchSeed = Math.floor(t * (isChase ? 14 : 7));
    const twitchX = (noise2D(twitchSeed, 1.7) - 0.5) * w * (isChase ? 0.08 : 0.025) * twitchScale;
    const twitchTilt = (noise2D(twitchSeed, 9.3) - 0.5) * (isChase ? 0.4 : 0.14) * twitchScale;
    const breathing = Math.sin(t * (isChase ? 6 : 2.2)) * 0.02;
    const armSway = Math.sin(t * 3 + phase) * w * 0.04;

    // --- GEH-ZYKLUS ---
    // Nur das Ingame-Monster läuft (walking). Im Todesbildschirm/Jumpscare wird
    // das Modell von der Brust aufwärts gezeigt — dort soll nichts wippen.
    const walking = !!opts.walking;
    const walkSpeed = isChase ? 11 : 5.5;
    const walkPhase = t * walkSpeed + phase;
    // Körper wippt im Schritt-Takt (zweimal pro Zyklus), Füße bleiben am Boden → geerdet
    const bodyBob = walking ? Math.abs(Math.sin(walkPhase)) * h * (isChase ? 0.05 : 0.032) : 0;
    const walkSway = walking ? Math.sin(walkPhase) * w * 0.022 : 0;

    // Fahle Leichenhaut mit zylindrischer Schattierung
    const skinGrad = g.createLinearGradient(cx - w * 0.2, 0, cx + w * 0.2, 0);
    skinGrad.addColorStop(0, isChase ? '#241210' : '#1c1a16');
    skinGrad.addColorStop(0.5, isChase ? '#7a6660' : '#6e6a60');
    skinGrad.addColorStop(1, isChase ? '#1a0c0a' : '#141310');
    const limbColor = isChase ? '#4a3835' : '#403d36';
    const shadowColor = isChase ? '#1c0a08' : '#15130f';

    g.save();
    // Ganzer Körper schwankt leicht und zuckt
    g.translate(cx + twitchX, top + h * 0.55);
    g.rotate(Math.sin(t * 1.3 + phase) * 0.03 + twitchTilt * 0.25);
    g.translate(-(cx + twitchX), -(top + h * 0.55));

    // --- BEINE (nach hinten geknickt, wie ein Tier) — echter Geh-Zyklus ---
    // Die Hüfte wippt mit dem Körper, die Füße bleiben am Boden und setzen
    // abwechselnd auf (Stand- und Schwungphase) → es geht, statt zu schweben.
    g.strokeStyle = limbColor;
    g.lineCap = 'round';
    const groundY = top + h * 0.985;
    for (let side = -1; side <= 1; side += 2) {
        const legPhase = walkPhase + (side > 0 ? Math.PI : 0); // Beine gegenphasig
        const sw = Math.sin(legPhase);
        const lift = walking ? Math.max(0, sw) * h * 0.06 : 0;            // Fuß hebt in der Schwungphase
        const stride = walking ? Math.cos(legPhase) * w * 0.11
                               : Math.sin(t * 4 + side * 1.6) * w * 0.03; // Stand: nur leichtes Wanken
        const hipX = cx + side * w * 0.07 + walkSway;
        const hipY = top + h * 0.60 - bodyBob;
        const footX = cx + side * w * 0.06 + stride;
        const footY = groundY - lift;
        const kneeX = (hipX + footX) * 0.5 + side * w * 0.11; // Knie nach außen/hinten geknickt
        const kneeY = (hipY + footY) * 0.5 + h * 0.015;
        g.lineWidth = w * 0.05;
        g.beginPath();
        g.moveTo(hipX, hipY);
        g.lineTo(kneeX, kneeY);
        g.lineTo(footX, footY);
        g.stroke();
        // Lange Zehenkrallen, die in den Boden greifen
        g.lineWidth = w * 0.015;
        for (let f = -1; f <= 1; f++) {
            g.beginPath();
            g.moveTo(footX, footY);
            g.lineTo(footX + f * w * 0.03 + side * w * 0.04, footY + h * 0.012);
            g.stroke();
        }
    }

    // Oberkörper wippt mit dem Schritt (Füße oben bleiben geerdet)
    g.save();
    g.translate(walkSway, -bodyBob);

    // --- TORSO (ausgemergelt, leicht vornübergebeugt) ---
    g.fillStyle = skinGrad;
    g.beginPath();
    g.moveTo(cx - w * (0.13 + breathing), top + h * 0.26);
    g.quadraticCurveTo(cx - w * 0.20, top + h * 0.38, cx - w * 0.085, top + h * 0.52); // eingefallene Taille
    g.quadraticCurveTo(cx - w * 0.10, top + h * 0.60, cx - w * 0.09, top + h * 0.66);
    g.lineTo(cx + w * 0.09, top + h * 0.66);
    g.quadraticCurveTo(cx + w * 0.10, top + h * 0.60, cx + w * 0.085, top + h * 0.52);
    g.quadraticCurveTo(cx + w * 0.20, top + h * 0.38, cx + w * (0.13 + breathing), top + h * 0.26);
    g.closePath();
    g.fill();

    // Rippen drücken durch die Haut (dunkle Schatten + helle Knochenkanten)
    for (let r = 0; r < 6; r++) {
        const ry = top + h * (0.32 + r * 0.045);
        const ribW = w * (0.115 - r * 0.011);
        g.strokeStyle = 'rgba(0, 0, 0, 0.45)';
        g.lineWidth = w * 0.014;
        g.beginPath();
        g.moveTo(cx - ribW, ry);
        g.quadraticCurveTo(cx, ry + w * 0.025, cx + ribW, ry);
        g.stroke();
        g.strokeStyle = 'rgba(160, 150, 135, 0.25)';
        g.lineWidth = w * 0.008;
        g.beginPath();
        g.moveTo(cx - ribW, ry - w * 0.008);
        g.quadraticCurveTo(cx, ry + w * 0.015, cx + ribW, ry - w * 0.008);
        g.stroke();
    }
    // Eingefallener Bauch (dunkle Höhlung)
    const bellyGrad = g.createRadialGradient(cx, top + h * 0.56, 0, cx, top + h * 0.56, w * 0.09);
    bellyGrad.addColorStop(0, 'rgba(0,0,0,0.55)');
    bellyGrad.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = bellyGrad;
    g.fillRect(cx - w * 0.09, top + h * 0.48, w * 0.18, h * 0.16);

    // Dunkle Flecken / Wunden auf der Haut
    for (let p = 0; p < 4; p++) {
        const px = cx + (noise2D(p * 7.7, 3.1) - 0.5) * w * 0.2;
        const py = top + h * (0.3 + noise2D(p * 3.3, 8.8) * 0.3);
        g.fillStyle = `rgba(${isChase ? '60, 10, 5' : '25, 20, 15'}, 0.5)`;
        g.beginPath();
        g.ellipse(px, py, w * 0.025, w * 0.04, p, 0, Math.PI * 2);
        g.fill();
    }

    // --- ARME (viel zu lang, fast bis zum Boden) ---
    g.strokeStyle = limbColor;
    g.lineWidth = w * 0.042;
    for (let side = -1; side <= 1; side += 2) {
        // Bei der Jagd greifen die Arme nach vorne (zur Kamera)
        const reach = isChase ? w * 0.06 : 0;
        const handX = cx + side * (w * 0.27 + reach) + armSway * side;
        const handY = top + h * (isChase ? 0.62 : 0.82) + breathing * h;
        g.beginPath();
        g.moveTo(cx + side * w * 0.13, top + h * 0.28); // Schulter
        g.lineTo(cx + side * w * 0.26 - armSway * side, top + h * 0.48); // Ellbogen weit außen
        g.lineTo(handX, handY); // Handgelenk
        g.stroke();

        // Hand: gespreizte, viel zu lange Krallenfinger
        g.lineWidth = w * 0.011;
        g.strokeStyle = isChase ? '#5c4a45' : '#4d4a42';
        for (let f = 0; f < 4; f++) {
            const fAngle = (f - 1.5) * 0.32 + side * 0.5 + (isChase ? Math.PI * 0.45 : Math.PI * 0.5);
            const fLen = w * (0.085 + (f === 1 || f === 2 ? 0.025 : 0));
            const midX = handX + Math.cos(fAngle) * fLen * 0.6;
            const midY = handY + Math.sin(fAngle) * fLen * 0.6;
            g.beginPath();
            g.moveTo(handX, handY);
            g.quadraticCurveTo(midX, midY, midX + Math.cos(fAngle + 0.5) * fLen * 0.5, midY + Math.sin(fAngle + 0.5) * fLen * 0.5);
            g.stroke();
        }
        g.lineWidth = w * 0.042;
        g.strokeStyle = limbColor;
    }

    // --- KOPF (kahl, länglich, ruckartig geneigt) ---
    const headY = top + h * 0.155;
    g.save();
    g.translate(cx, headY);
    g.rotate(twitchTilt); // Kopf kippt unnatürlich zur Seite
    g.translate(-cx, -headY);

    const headGrad = g.createRadialGradient(cx - w * 0.03, headY - w * 0.04, w * 0.01, cx, headY, w * 0.16);
    headGrad.addColorStop(0, isChase ? '#8a7570' : '#7d7868');
    headGrad.addColorStop(0.7, isChase ? '#4a3530' : '#403c33');
    headGrad.addColorStop(1, shadowColor);
    g.fillStyle = headGrad;
    g.beginPath();
    // Länglicher Schädel mit schmalem Kinn
    g.moveTo(cx, headY - w * 0.135);
    g.bezierCurveTo(cx + w * 0.115, headY - w * 0.13, cx + w * 0.105, headY + w * 0.04, cx + w * 0.045, headY + w * 0.115);
    g.quadraticCurveTo(cx, headY + w * 0.15, cx - w * 0.045, headY + w * 0.115);
    g.bezierCurveTo(cx - w * 0.105, headY + w * 0.04, cx - w * 0.115, headY - w * 0.13, cx, headY - w * 0.135);
    g.fill();

    // Eingefallene Wangen
    g.fillStyle = 'rgba(0,0,0,0.35)';
    g.beginPath();
    g.ellipse(cx - w * 0.06, headY + w * 0.035, w * 0.025, w * 0.04, 0.3, 0, Math.PI * 2);
    g.ellipse(cx + w * 0.06, headY + w * 0.035, w * 0.025, w * 0.04, -0.3, 0, Math.PI * 2);
    g.fill();

    // Tiefe schwarze Augenhöhlen
    const eyeY = headY - w * 0.025;
    const eyeSpread = w * 0.052;
    for (let side = -1; side <= 1; side += 2) {
        const sockGrad = g.createRadialGradient(cx + side * eyeSpread, eyeY, 0, cx + side * eyeSpread, eyeY, w * 0.038);
        sockGrad.addColorStop(0, '#000');
        sockGrad.addColorStop(0.75, '#050505');
        sockGrad.addColorStop(1, 'rgba(5,5,5,0)');
        g.fillStyle = sockGrad;
        g.beginPath();
        g.ellipse(cx + side * eyeSpread, eyeY, w * 0.035, w * 0.042, side * 0.2, 0, Math.PI * 2);
        g.fill();
    }

    // Winzige glühende Pupillen tief in den Höhlen (rot bei Jagd)
    const pupilR = Math.max(0.4, w * (isChase ? 0.011 : 0.008));
    g.fillStyle = isChase ? '#ff2200' : '#d8d4c4';
    g.shadowColor = isChase ? '#ff2200' : '#999';
    g.shadowBlur = isChase ? 14 : 5;
    g.beginPath(); g.arc(cx - eyeSpread, eyeY + w * 0.005, pupilR, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.arc(cx + eyeSpread, eyeY + w * 0.005, pupilR, 0, Math.PI * 2); g.fill();
    g.shadowBlur = 0;

    // Nasenlöcher (keine Nase, nur zwei Schlitze)
    g.fillStyle = 'rgba(0,0,0,0.7)';
    g.beginPath();
    g.ellipse(cx - w * 0.008, headY + w * 0.035, w * 0.005, w * 0.011, 0.15, 0, Math.PI * 2);
    g.ellipse(cx + w * 0.008, headY + w * 0.035, w * 0.005, w * 0.011, -0.15, 0, Math.PI * 2);
    g.fill();

    // Ausgerenkter, klaffender Kiefer (bei Jagd weit offen)
    const jawDrop = w * (isChase ? 0.085 + Math.sin(t * 9) * 0.012 : 0.045 + breathing * 0.5);
    const mouthY = headY + w * 0.085;
    g.fillStyle = '#020101';
    g.beginPath();
    g.ellipse(cx, mouthY + jawDrop * 0.5, w * 0.038, jawDrop, 0, 0, Math.PI * 2);
    g.fill();

    // --- ZÄHNE: saubere, ineinandergreifende Reihe entlang der Lippenbögen ---
    // Beide Reihen sitzen sauber an Ober-/Unterlippe und greifen versetzt
    // ineinander (Reißzähne), statt frei im schwarzen Mund zu schweben.
    const mouthCY = mouthY + jawDrop * 0.5;     // Mund-Mittelpunkt (= Ellipsenzentrum)
    const rxM = w * 0.038;                       // halbe Mundbreite
    const ryM = jawDrop;                         // halbe Mundhöhe
    const lipY = (fx, dir) => mouthCY + dir * ryM * Math.sqrt(Math.max(0, 1 - fx * fx)) * 0.92;
    const detailedTeeth = w > 220; // volle Zahn-Details nur aus der Nähe (Performance)

    // Feuchtes Zahnfleisch / dunkler Fleischrand rund um den Mund
    g.strokeStyle = 'rgba(70, 18, 16, 0.55)';
    g.lineWidth = Math.max(0.6, w * 0.006);
    g.beginPath();
    g.ellipse(cx, mouthCY, rxM * 1.02, ryM * 0.98, 0, 0, Math.PI * 2);
    g.stroke();

    // Ein einzelner, organisch gebogener Reißzahn mit Schmelz-Verlauf & Fäulnis
    const drawFang = (tx, baseY, halfW, len, dir, seed) => {
        const tipY = baseY + dir * len;
        g.beginPath();
        g.moveTo(tx - halfW, baseY);
        g.quadraticCurveTo(tx - halfW * 0.45, baseY + dir * len * 0.55, tx, tipY);
        g.quadraticCurveTo(tx + halfW * 0.45, baseY + dir * len * 0.55, tx + halfW, baseY);
        g.closePath();
        if (detailedTeeth) {
            const decay = Math.abs(noise2D(seed, 2.2));
            const gr = g.createLinearGradient(tx, baseY, tx, tipY);
            // Ansatz (am Zahnfleisch) gelblich-verfault → Spitze heller Schmelz
            gr.addColorStop(0, `rgba(${120 - decay * 45 | 0}, ${104 - decay * 50 | 0}, ${68 - decay * 30 | 0}, 0.96)`);
            gr.addColorStop(0.5, 'rgba(198, 188, 162, 0.96)');
            gr.addColorStop(1, 'rgba(233, 227, 209, 0.98)');
            g.fillStyle = gr;
            g.fill();
            g.lineWidth = Math.max(0.4, w * 0.0016);
            g.strokeStyle = 'rgba(15, 10, 6, 0.5)';
            g.stroke();
        } else {
            g.fillStyle = 'rgba(205, 195, 170, 0.95)';
            g.fill();
        }
    };

    const UP = 6; // Anzahl oberer Zähne
    // Obere Reihe (zeigt nach unten), folgt dem Oberlippenbogen
    for (let i = 0; i < UP; i++) {
        const fx = (i / (UP - 1)) * 1.7 - 0.85;  // -0.85..0.85 (Ränder bleiben frei)
        const tx = cx + fx * rxM;
        const baseY = lipY(fx, -1);
        const tLen = ryM * (0.55 + Math.abs(noise2D(i, 5.5)) * 0.30);
        const halfW = w * (0.0050 + Math.abs(noise2D(i, 3.1)) * 0.0026);
        drawFang(tx, baseY, halfW, tLen, 1, i + 0.3);
    }
    // Untere Reihe (zeigt nach oben), um eine halbe Lücke versetzt → greift ineinander
    for (let i = 0; i < UP - 1; i++) {
        const fx = ((i + 0.5) / (UP - 1)) * 1.7 - 0.85;
        const tx = cx + fx * rxM;
        const baseY = lipY(fx, 1);
        const tLen = ryM * (0.5 + Math.abs(noise2D(i, 9.1)) * 0.30);
        const halfW = w * (0.0048 + Math.abs(noise2D(i, 6.7)) * 0.0024);
        drawFang(tx, baseY, halfW, tLen, -1, i + 7.5);
    }

    // Schwarzer Speichel läuft aus dem Mund
    g.strokeStyle = 'rgba(10, 5, 5, 0.75)';
    g.lineWidth = Math.max(0.5, w * 0.006);
    for (let d = -1; d <= 1; d++) {
        const dx = cx + d * w * 0.018;
        const dLen = w * (0.04 + Math.abs(noise2D(d, twitchSeed)) * 0.05);
        g.beginPath();
        g.moveTo(dx, mouthY + jawDrop * 1.3);
        g.quadraticCurveTo(dx + d * w * 0.005, mouthY + jawDrop * 1.3 + dLen * 0.6, dx, mouthY + jawDrop * 1.3 + dLen);
        g.stroke();
    }

    g.restore(); // Kopf-Neigung
    g.restore(); // Geh-Hub (Oberkörper-Wippen)
    g.restore(); // Körper-Schwanken
    g.lineCap = 'butt';
}

// ==========================================
// LEICHEN / SKELETTE (Grusel-Deko, flach am Boden liegend)
// (g, cx, baseY=Bodenkontakt, w=Breite, type='skeleton'|'gore', seed)
// Wichtig: Alles liegt FLACH am Boden (geringe Höhe), damit nichts schwebt.
// ==========================================
function drawCorpse(g, cx, baseY, w, type, seed) {
    const rnd = makeSeededRandom(((seed || 0) * 9973 | 0) + 1);
    const dir = ((seed | 0) % 2 === 0) ? 1 : -1; // Ausrichtung (Kopf links/rechts)
    g.save();
    g.lineCap = 'round';
    g.lineJoin = 'round';

    // Flache Blut-/Verwesungslache am Boden (verankert die Leiche optisch)
    g.fillStyle = type === 'gore' ? 'rgba(50,2,3,0.72)' : 'rgba(22,14,9,0.6)';
    g.beginPath();
    g.ellipse(cx, baseY, w * 1.15, w * 0.42, 0, 0, Math.PI * 2);
    g.fill();

    if (type === 'skeleton') {
        const bone = '#cbc4ad';
        const spineY = baseY - w * 0.06; // liegt knapp über dem Boden

        // Wirbelsäule (horizontal liegend)
        g.strokeStyle = bone; g.lineWidth = w * 0.07;
        g.beginPath();
        g.moveTo(cx - dir * w * 0.55, spineY + w * 0.04);
        g.lineTo(cx + dir * w * 0.35, spineY - w * 0.06);
        g.stroke();

        // Beine zur einen Seite gespreizt
        g.lineWidth = w * 0.055;
        for (const o of [-0.08, 0.08]) {
            g.beginPath();
            g.moveTo(cx - dir * w * 0.5, spineY + o * w);
            g.lineTo(cx - dir * w * 0.95, baseY + o * w * 2);
            g.stroke();
        }

        // Brustkorb (flaches Oval) + Rippen
        g.fillStyle = bone;
        g.beginPath(); g.ellipse(cx, spineY - w * 0.04, w * 0.3, w * 0.2, 0, 0, Math.PI * 2); g.fill();
        g.strokeStyle = 'rgba(35,30,20,0.6)'; g.lineWidth = Math.max(0.6, w * 0.014);
        for (let r = 0; r < 4; r++) {
            const rx = cx - w * 0.14 + r * w * 0.1;
            g.beginPath(); g.moveTo(rx, spineY - w * 0.16); g.quadraticCurveTo(rx + w * 0.02, spineY, rx, spineY + w * 0.1); g.stroke();
        }

        // ein ausgestreckter Arm
        g.strokeStyle = bone; g.lineWidth = w * 0.04;
        g.beginPath();
        g.moveTo(cx, spineY - w * 0.06);
        g.lineTo(cx + dir * w * 0.18, spineY - w * 0.26);
        g.lineTo(cx + dir * w * 0.4, spineY - w * 0.3);
        g.stroke();

        // Schädel zur Vorderseite, leicht gedreht
        const skX = cx + dir * w * 0.46, skY = spineY - w * 0.1, skR = w * 0.19;
        g.fillStyle = bone;
        g.beginPath(); g.ellipse(skX, skY, skR, skR * 0.9, dir * 0.35, 0, Math.PI * 2); g.fill();
        g.fillStyle = '#000';
        g.beginPath();
        g.ellipse(skX - dir * skR * 0.3, skY - skR * 0.12, skR * 0.3, skR * 0.34, 0, 0, Math.PI * 2);
        g.ellipse(skX + dir * skR * 0.32, skY - skR * 0.06, skR * 0.28, skR * 0.32, 0, 0, Math.PI * 2);
        g.fill();
        // Kiefer/Zähne
        g.fillStyle = bone;
        g.fillRect(skX - skR * 0.45, skY + skR * 0.45, skR * 0.9, skR * 0.26);
    } else {
        // GORE: flacher zerfetzter Fleischhaufen + Eingeweide + abgetrennte Gliedmaße
        // Eingeweide-Stränge
        g.strokeStyle = 'rgba(95,12,12,0.85)'; g.lineWidth = w * 0.05;
        for (let e = 0; e < 3; e++) {
            const ex = cx + (rnd() - 0.5) * w * 0.9;
            g.beginPath();
            g.moveTo(cx, baseY - w * 0.06);
            g.quadraticCurveTo(ex, baseY - w * 0.02, ex + (rnd() - 0.5) * w * 0.4, baseY + w * 0.12);
            g.stroke();
        }

        // Rumpf (dunkle, flache Fleischmasse)
        const torso = g.createRadialGradient(cx, baseY - w * 0.1, w * 0.04, cx, baseY - w * 0.1, w * 0.55);
        torso.addColorStop(0, '#6e2a26');
        torso.addColorStop(1, '#280f0e');
        g.fillStyle = torso;
        g.beginPath(); g.ellipse(cx, baseY - w * 0.1, w * 0.52, w * 0.26, 0, 0, Math.PI * 2); g.fill();

        // freiliegende, gebrochene Rippen
        g.strokeStyle = '#e2dac2'; g.lineWidth = Math.max(0.8, w * 0.022);
        for (let r = 0; r < 4; r++) {
            const rx = cx - w * 0.12 + r * w * 0.09;
            g.beginPath(); g.moveTo(rx, baseY - w * 0.2); g.quadraticCurveTo(rx + w * 0.03, baseY - w * 0.1, rx, baseY - w * 0.02); g.stroke();
        }

        // abgetrennte Gliedmaße daneben (mit Knochenstumpf)
        const lx = cx + dir * w * 0.78;
        g.strokeStyle = '#5a2422'; g.lineWidth = w * 0.1;
        g.beginPath(); g.moveTo(lx, baseY - w * 0.02); g.lineTo(lx + dir * w * 0.26, baseY - w * 0.1); g.stroke();
        g.fillStyle = '#d8cfb4';
        g.beginPath(); g.arc(lx, baseY - w * 0.02, w * 0.05, 0, Math.PI * 2); g.fill();

        // frische Blutspritzer ringsum (flach am Boden)
        for (let i = 0; i < 16; i++) {
            const a = rnd() * Math.PI * 2, d = w * (0.4 + rnd() * 0.85);
            g.fillStyle = `rgba(${70 + rnd() * 40 | 0},0,0,${0.5 + rnd() * 0.4})`;
            g.beginPath();
            g.arc(cx + Math.cos(a) * d, baseY + Math.sin(a) * d * 0.4, rnd() * w * 0.05 + 0.5, 0, Math.PI * 2);
            g.fill();
        }
    }

    g.restore();
}

// ==========================================
// 3D-TREPPE als boden­verankertes Objekt (echte gestufte Geometrie statt flacher Wand).
// (g, cx, baseY=Bodenkontakt vorne, w=Breite, dir='U'|'D')
// ==========================================
function drawStairs3D(g, cx, baseY, w, dir) {
    g.save();
    g.lineCap = 'butt';
    g.lineJoin = 'round';

    if (dir === 'U') {
        // Aufsteigende Treppe: Stufen wachsen aus dem Boden nach oben in eine Öffnung
        const N = 9;
        const totalH = w * 1.95;
        const baseHalf = w * 0.72, topHalf = w * 0.20;
        const topY = baseY - totalH;
        const yAt = i => baseY - totalH * Math.pow(i / N, 0.85);
        const halfAt = i => baseHalf + (topHalf - baseHalf) * (i / N);

        // dunkles Treppenhaus dahinter + kaltes Licht von oben
        g.fillStyle = '#070605';
        g.beginPath();
        g.moveTo(cx - baseHalf, baseY); g.lineTo(cx - topHalf, topY);
        g.lineTo(cx + topHalf, topY); g.lineTo(cx + baseHalf, baseY);
        g.closePath(); g.fill();
        const gl = g.createRadialGradient(cx, topY, 2, cx, topY, totalH * 0.7);
        gl.addColorStop(0, 'rgba(150,160,185,0.45)');
        gl.addColorStop(1, 'rgba(150,160,185,0)');
        g.fillStyle = gl;
        g.beginPath();
        g.moveTo(cx - baseHalf, baseY); g.lineTo(cx - topHalf, topY);
        g.lineTo(cx + topHalf, topY); g.lineTo(cx + baseHalf, baseY);
        g.closePath(); g.fill();

        // Stufen von fern (oben) nach nah (unten) zeichnen
        for (let i = N - 1; i >= 0; i--) {
            const yF = yAt(i), yB = yAt(i + 1);
            const hwF = halfAt(i), hwB = halfAt(i + 1);
            const riserH = (i === 0) ? (baseY - yF) : (yAt(i - 1) - yF);

            // Setzstufe (Vorderseite, im Schatten)
            const sh = 22 + i * 2;
            g.fillStyle = `rgb(${sh | 0},${(sh * 0.9) | 0},${(sh * 0.8) | 0})`;
            g.beginPath();
            g.moveTo(cx - hwF, yF); g.lineTo(cx + hwF, yF);
            g.lineTo(cx + hwF, yF + Math.max(2, riserH * 0.6));
            g.lineTo(cx - hwF, yF + Math.max(2, riserH * 0.6));
            g.closePath(); g.fill();

            // Trittfläche (Oberseite, beleuchtet)
            const lt = 58 + i * 4;
            g.fillStyle = `rgb(${Math.min(150, lt) | 0},${Math.min(142, lt * 0.94) | 0},${Math.min(128, lt * 0.84) | 0})`;
            g.beginPath();
            g.moveTo(cx - hwF, yF); g.lineTo(cx + hwF, yF);
            g.lineTo(cx + hwB, yB); g.lineTo(cx - hwB, yB);
            g.closePath(); g.fill();

            // helle Vorderkante
            g.strokeStyle = 'rgba(195,190,175,0.4)';
            g.lineWidth = Math.max(1, w * 0.02);
            g.beginPath(); g.moveTo(cx - hwF, yF); g.lineTo(cx + hwF, yF); g.stroke();

            // Teppichläufer in der Mitte (dunkelrot)
            const cF = hwF * 0.4, cB = hwB * 0.4;
            g.fillStyle = `rgb(${(46 + i) | 0},${(12 + i * 0.4) | 0},${(12 + i * 0.4) | 0})`;
            g.beginPath();
            g.moveTo(cx - cF, yF); g.lineTo(cx + cF, yF);
            g.lineTo(cx + cB, yB); g.lineTo(cx - cB, yB);
            g.closePath(); g.fill();
        }
    } else {
        // Absteigende Treppe: dunkles Loch im Boden mit Stufenkanten, die nach hinten abfallen
        const nearHalf = w * 0.72, farHalf = w * 0.34;
        const frontY = baseY + w * 0.14;       // vordere (nahe) Kante, etwas tiefer
        const backY = baseY - w * 0.20;         // hintere (ferne) Kante, höher am Schirm
        g.fillStyle = '#050505';
        g.beginPath();
        g.moveTo(cx - nearHalf, frontY); g.lineTo(cx + nearHalf, frontY);
        g.lineTo(cx + farHalf, backY); g.lineTo(cx - farHalf, backY);
        g.closePath(); g.fill();

        const N = 6;
        for (let i = 1; i <= N; i++) {
            const t = i / N;
            const y = frontY + (backY - frontY) * t;
            const hw = nearHalf + (farHalf - nearHalf) * t;
            const lt = 46 * (1 - t); // nach hinten dunkler (tiefer im Loch)
            g.strokeStyle = `rgba(${(lt + 22) | 0},${(lt + 18) | 0},${(lt + 14) | 0},0.8)`;
            g.lineWidth = Math.max(1, w * 0.035);
            g.beginPath(); g.moveTo(cx - hw, y); g.lineTo(cx + hw, y); g.stroke();
        }
        // heller Rand der obersten Stufe (Bodenkante)
        g.strokeStyle = 'rgba(120,115,100,0.5)';
        g.lineWidth = Math.max(1, w * 0.03);
        g.beginPath(); g.moveTo(cx - nearHalf, frontY); g.lineTo(cx + nearHalf, frontY); g.stroke();
    }

    g.restore();
}

// ==========================================================================
// 3D-TREPPE — WELT-VERANKERT (wie die Möbel): echte 3D-Stufen, die fest am Boden
// "kleben" und sich NICHT mit dem Blick mitdrehen. (g, cam, st={x,y(Welt-Mitte),dir})
// ==========================================================================
function drawStairs3DWorld(g, cam, st) {
    const lk = _propLightK;
    const T = TILE_SIZE;
    const cx = st.x, cy = st.y;            // Welt-Mittelpunkt der Treppenkachel
    const halfX = T * 0.44;                // halbe Breite (quer)
    const N = 8;
    const span = T * 0.86;                 // Gesamttiefe der Treppe (entlang +y)
    const depth = span / N;                // Tiefe je Stufe
    const startY = cy - span * 0.5;
    const stone = { base: [116, 114, 122], grain: false };

    if (st.dir === 'U') {
        // Aufsteigende Treppe aus echten 3D-Stein-Boxen (fern → nah zeichnen)
        const steps = [];
        for (let i = 0; i < N; i++) {
            const yc = startY + depth * (i + 0.5);
            const z1 = 0.07 + ((i + 1) / N) * 0.9; // wächst zur Decke hin
            steps.push({ yc, z1, d: Math.hypot(cx - cam.pX, yc - cam.pY) });
        }
        steps.sort((a, b) => b.d - a.d);
        for (const s of steps) {
            drawWorldBox(g, cam, cx, s.yc, 0, halfX, depth * 0.5, 0, s.z1, stone);
            // dunkelroter Teppichläufer auf der Trittfläche
            const cw = halfX * 0.42, y0 = s.yc - depth * 0.5, y1 = s.yc + depth * 0.5;
            const p0 = projCam(cam, cx - cw, y0, s.z1), p1 = projCam(cam, cx + cw, y0, s.z1);
            const p2 = projCam(cam, cx + cw, y1, s.z1), p3 = projCam(cam, cx - cw, y1, s.z1);
            if (p0.depth > 0.06 && p2.depth > 0.06) drawShadedFace(g, [p0, p1, p2, p3], [82, 22, 22], 0.75 * lk, false);
        }
    } else {
        // Absteigende Treppe: echtes Loch mit Stufen, die nach unten/hinten abfallen
        const dz = 0.85 / N;
        // dunkler Schacht-Hintergrund (immer dunkel — ein Loch bleibt ein Loch)
        const b0 = projCam(cam, cx - halfX, startY, 0), b1 = projCam(cam, cx + halfX, startY, 0);
        const b2 = projCam(cam, cx + halfX, startY + span, -0.9), b3 = projCam(cam, cx - halfX, startY + span, -0.9);
        if (b0.depth > 0.06 && b2.depth > 0.06) drawShadedFace(g, [b0, b1, b2, b3], [8, 8, 10], 1, false);
        // Stufen von tief/hinten nach vorne zeichnen
        for (let i = N - 1; i >= 0; i--) {
            const yF = startY + depth * i, yB = startY + depth * (i + 1);
            const zT = -i * dz;
            const lit = Math.max(0.12, 0.55 - i * 0.05) * lk;
            // Trittfläche
            const t0 = projCam(cam, cx - halfX, yF, zT), t1 = projCam(cam, cx + halfX, yF, zT);
            const t2 = projCam(cam, cx + halfX, yB, zT), t3 = projCam(cam, cx - halfX, yB, zT);
            if (t0.depth > 0.06 && t2.depth > 0.06) drawShadedFace(g, [t0, t1, t2, t3], [116, 114, 122], lit, false);
            // Setzstufe (senkrecht nach unten an der hinteren Kante)
            const r0 = projCam(cam, cx - halfX, yB, zT), r1 = projCam(cam, cx + halfX, yB, zT);
            const r2 = projCam(cam, cx + halfX, yB, zT - dz), r3 = projCam(cam, cx - halfX, yB, zT - dz);
            if (r0.depth > 0.06 && r2.depth > 0.06) drawShadedFace(g, [r0, r1, r2, r3], [70, 68, 78], lit * 0.6, false);
        }
    }
}

// ==========================================
// MÖBEL (boden­verankerte Deko-Billboards)
// (g, cx, baseY, w, type, seed)
// ==========================================
function drawFurniture(g, cx, baseY, w, type, seed) {
    g.save();
    g.lineJoin = 'round';
    const dark = '#2a1c10', wood = '#3d2a18', woodLit = '#5a3f24', metal = '#3a3a40';

    // weicher Bodenschatten
    g.fillStyle = 'rgba(0,0,0,0.4)';
    g.beginPath(); g.ellipse(cx, baseY, w * 0.7, w * 0.18, 0, 0, Math.PI * 2); g.fill();

    if (type === 'table') {
        const topY = baseY - w * 0.95, topW = w * 1.3, legH = w * 0.95;
        // Beine
        g.strokeStyle = wood; g.lineWidth = w * 0.1;
        for (const sx of [-0.55, 0.55]) {
            g.beginPath(); g.moveTo(cx + sx * topW * 0.7, baseY); g.lineTo(cx + sx * topW * 0.7, topY + w * 0.1); g.stroke();
        }
        // Tischplatte
        g.fillStyle = woodLit;
        g.fillRect(cx - topW * 0.5, topY, topW, w * 0.18);
        g.fillStyle = dark;
        g.fillRect(cx - topW * 0.5, topY + w * 0.16, topW, w * 0.05);
    } else if (type === 'crate') {
        const s = w * 1.0, topY = baseY - s;
        g.fillStyle = wood; g.fillRect(cx - s * 0.5, topY, s, s);
        g.strokeStyle = dark; g.lineWidth = Math.max(1, w * 0.04);
        g.strokeRect(cx - s * 0.5, topY, s, s);
        // Diagonalstreben
        g.beginPath(); g.moveTo(cx - s * 0.5, topY); g.lineTo(cx + s * 0.5, topY + s);
        g.moveTo(cx + s * 0.5, topY); g.lineTo(cx - s * 0.5, topY + s); g.stroke();
        // Brett-Highlights
        g.strokeStyle = woodLit; g.lineWidth = Math.max(1, w * 0.02);
        g.beginPath(); g.moveTo(cx - s * 0.5, topY + s * 0.35); g.lineTo(cx + s * 0.5, topY + s * 0.35); g.stroke();
    } else if (type === 'barrel') {
        const bw = w * 0.85, bh = w * 1.15, topY = baseY - bh;
        const grad = g.createLinearGradient(cx - bw * 0.5, 0, cx + bw * 0.5, 0);
        grad.addColorStop(0, dark); grad.addColorStop(0.5, woodLit); grad.addColorStop(1, dark);
        g.fillStyle = grad;
        g.beginPath();
        g.moveTo(cx - bw * 0.5, topY + bh * 0.1);
        g.quadraticCurveTo(cx - bw * 0.62, topY + bh * 0.5, cx - bw * 0.5, topY + bh * 0.9);
        g.lineTo(cx + bw * 0.5, topY + bh * 0.9);
        g.quadraticCurveTo(cx + bw * 0.62, topY + bh * 0.5, cx + bw * 0.5, topY + bh * 0.1);
        g.closePath(); g.fill();
        g.fillStyle = '#241608'; g.beginPath(); g.ellipse(cx, topY + bh * 0.1, bw * 0.5, bh * 0.08, 0, 0, Math.PI * 2); g.fill();
        // Eisenreifen
        g.strokeStyle = metal; g.lineWidth = Math.max(1, w * 0.05);
        for (const ry of [0.28, 0.62]) { g.beginPath(); g.moveTo(cx - bw * 0.56, topY + bh * ry); g.lineTo(cx + bw * 0.56, topY + bh * ry); g.stroke(); }
    } else if (type === 'shelf') {
        const sw = w * 1.2, sh = w * 1.9, topY = baseY - sh;
        g.fillStyle = wood; g.fillRect(cx - sw * 0.5, topY, sw, sh);
        g.strokeStyle = dark; g.lineWidth = Math.max(1, w * 0.05); g.strokeRect(cx - sw * 0.5, topY, sw, sh);
        // Regalbretter + Bücher
        const bookCols = ['#5a2020', '#3a4a2a', '#2a3a55', '#6a5520', '#402a40'];
        for (let r = 0; r < 4; r++) {
            const shY = topY + sh * (0.18 + r * 0.22);
            g.strokeStyle = dark; g.lineWidth = Math.max(1, w * 0.03);
            g.beginPath(); g.moveTo(cx - sw * 0.5, shY); g.lineTo(cx + sw * 0.5, shY); g.stroke();
            // Bücher auf dem Brett
            let bx = cx - sw * 0.42;
            while (bx < cx + sw * 0.4) {
                const bw2 = w * (0.08 + Math.abs(noise2D(bx, r + seed)) * 0.08);
                const bh2 = w * (0.14 + Math.abs(noise2D(bx * 1.7, r)) * 0.05);
                g.fillStyle = bookCols[(bx * 7 + r) | 0 % bookCols.length] || bookCols[r % bookCols.length];
                g.fillRect(bx, shY - bh2, bw2, bh2);
                bx += bw2 + w * 0.015;
            }
        }
    } else { // chair
        const sw = w * 0.7, seatY = baseY - w * 0.55, backY = baseY - w * 1.15;
        g.strokeStyle = wood; g.lineWidth = w * 0.08;
        for (const sx of [-0.4, 0.4]) { g.beginPath(); g.moveTo(cx + sx * sw, baseY); g.lineTo(cx + sx * sw, seatY); g.stroke(); }
        g.fillStyle = woodLit; g.fillRect(cx - sw * 0.5, seatY, sw, w * 0.12);
        // Rückenlehne
        g.strokeStyle = wood; g.lineWidth = w * 0.08;
        g.beginPath(); g.moveTo(cx - sw * 0.4, seatY); g.lineTo(cx - sw * 0.4, backY); g.stroke();
        g.beginPath(); g.moveTo(cx + sw * 0.4, seatY); g.lineTo(cx + sw * 0.4, backY); g.stroke();
        g.beginPath(); g.moveTo(cx - sw * 0.45, backY + w * 0.1); g.lineTo(cx + sw * 0.45, backY + w * 0.1); g.stroke();
    }

    g.restore();
}

// ==========================================
// SCHRANK zum Verstecken (boden­verankertes Billboard)
// (g, cx, baseY, w, seed, ajar = leicht geöffnet)
// ==========================================
function drawCloset(g, cx, baseY, w, seed, ajar) {
    g.save();
    g.lineJoin = 'round';
    const cw = w * 1.5, ch = w * 2.5, topY = baseY - ch;
    const dark = '#1c1208', wood = '#3a2716', woodLit = '#523619';

    // Schatten
    g.fillStyle = 'rgba(0,0,0,0.45)';
    g.beginPath(); g.ellipse(cx, baseY, cw * 0.55, w * 0.2, 0, 0, Math.PI * 2); g.fill();

    // Korpus
    const grad = g.createLinearGradient(cx - cw * 0.5, 0, cx + cw * 0.5, 0);
    grad.addColorStop(0, dark); grad.addColorStop(0.5, wood); grad.addColorStop(1, dark);
    g.fillStyle = grad;
    g.fillRect(cx - cw * 0.5, topY, cw, ch);
    // Gesims oben
    g.fillStyle = woodLit; g.fillRect(cx - cw * 0.54, topY - w * 0.1, cw * 1.08, w * 0.14);
    // Rahmen
    g.strokeStyle = '#0d0805'; g.lineWidth = Math.max(1, w * 0.05); g.strokeRect(cx - cw * 0.5, topY, cw, ch);

    // Zwei Türen
    const gap = ajar ? cw * 0.12 : cw * 0.02; // leicht offen, wenn ajar
    const doorW = (cw - gap) * 0.5 - w * 0.06;
    for (const side of [-1, 1]) {
        const dx0 = side < 0 ? (cx - cw * 0.5 + w * 0.06) : (cx + gap * 0.5 + w * 0.02);
        g.fillStyle = side < 0 ? wood : '#34230f';
        g.fillRect(dx0, topY + w * 0.1, doorW, ch - w * 0.2);
        g.strokeStyle = '#0d0805'; g.lineWidth = Math.max(1, w * 0.03);
        g.strokeRect(dx0, topY + w * 0.1, doorW, ch - w * 0.2);
        // Paneel
        g.strokeStyle = 'rgba(90,60,30,0.5)';
        g.strokeRect(dx0 + doorW * 0.18, topY + ch * 0.12, doorW * 0.64, ch * 0.32);
        g.strokeRect(dx0 + doorW * 0.18, topY + ch * 0.52, doorW * 0.64, ch * 0.32);
        // Griff
        g.fillStyle = '#caa24a';
        const hx = side < 0 ? dx0 + doorW * 0.92 : dx0 + doorW * 0.08;
        g.beginPath(); g.arc(hx, topY + ch * 0.5, w * 0.06, 0, Math.PI * 2); g.fill();
    }
    // dunkler Spalt zwischen den Türen
    g.fillStyle = '#000';
    g.fillRect(cx - gap * 0.5, topY + w * 0.1, gap, ch - w * 0.2);

    g.restore();
}

// ==========================================================================
// ECHTES 3D-RENDERING FÜR REQUISITEN (Möbel, Schränke, Leichen)
// Statt flacher Billboards, die sich immer zur Kamera drehen, werden hier
// echte, perspektivisch projizierte 3D-Boxen mit fester Welt-Ausrichtung
// gezeichnet. Dadurch wirken die Objekte räumlich und "wandern" nicht mehr
// mit der Spielerposition mit.
// ==========================================================================

// Projiziert einen Weltpunkt (wx,wy in Weltkoordinaten, hz = Höhe in Kacheln:
// 0 = Boden, 1 = Decke) exakt wie der Wand-Raycaster auf den Bildschirm.
function projCam(cam, wx, wy, hz) {
    const dxw = (wx - cam.pX) / TILE_SIZE;
    const dyw = (wy - cam.pY) / TILE_SIZE;
    const ty = cam.dirX * dxw + cam.dirY * dyw;            // Tiefe (senkrechter Abstand) in Kacheln
    const tx = (cam.dirX * dyw - cam.dirY * dxw) / cam.a;  // seitliche Bildebenen-Koordinate
    const wh = cam.h / ty;                                 // projizierte Höhe einer ganzen Kachel
    return {
        x: (tx / ty + 1) * 0.5 * cam.w,
        y: cam.h * 0.5 + (0.5 - hz) * wh + cam.pitch + cam.pz * wh,
        depth: ty
    };
}

// Lineare Interpolation eines Punktes innerhalb eines (Bildschirm-)Vierecks.
// quad = [P0(oben-links), P1(oben-rechts), P2(unten-rechts), P3(unten-links)]
function quadPoint(quad, u, v) {
    const tx = quad[0].x + (quad[1].x - quad[0].x) * u;
    const ty = quad[0].y + (quad[1].y - quad[0].y) * u;
    const bx = quad[3].x + (quad[2].x - quad[3].x) * u;
    const by = quad[3].y + (quad[2].y - quad[3].y) * u;
    return { x: tx + (bx - tx) * v, y: ty + (by - ty) * v };
}

// Zeichnet ein texturiertes Viereck (4 Bildschirmpunkte) per affiner Abbildung.
// pts: [P0,P1,P2,P3] umlaufend; P0->P1 = U-Achse, P0->P3 = V-Achse.
function drawTexQuad(g, img, pts, darken, solid) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of pts) {
        if (!isFinite(p.x) || !isFinite(p.y)) return;
        if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y;
    }
    const bw = maxX - minX, bh = maxY - minY;
    if (bw < 0.5 || bh < 0.5) return;

    // Performance: kleine Flächen (Beine, ferne Möbel) werden ohne Clip direkt als
    // einfarbiges Polygon gefüllt — viel billiger als Clip + texturiertes drawImage.
    const useTexture = img && bw * bh >= 1500;
    if (!useTexture) {
        if (!solid) return;
        g.beginPath();
        g.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < 4; i++) g.lineTo(pts[i].x, pts[i].y);
        g.closePath();
        g.fillStyle = solid; g.fill();
        if (darken > 0.001) { g.fillStyle = `rgba(6,4,3,${Math.min(0.93, darken)})`; g.fill(); }
        return;
    }

    g.save();
    g.beginPath();
    g.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < 4; i++) g.lineTo(pts[i].x, pts[i].y);
    g.closePath();
    g.clip();
    {
        const iw = img.width || img.naturalWidth || 256;
        const ih = img.height || img.naturalHeight || 256;
        const m11 = (pts[1].x - pts[0].x) / iw, m12 = (pts[1].y - pts[0].y) / iw;
        const m21 = (pts[3].x - pts[0].x) / ih, m22 = (pts[3].y - pts[0].y) / ih;
        if (isFinite(m11) && isFinite(m12) && isFinite(m21) && isFinite(m22)) {
            g.setTransform(m11, m12, m21, m22, pts[0].x, pts[0].y);
            try { g.drawImage(img, 0, 0, iw, ih); } catch (e) { }
            g.setTransform(1, 0, 0, 1, 0, 0);
        }
    }
    if (darken > 0.001) {
        g.fillStyle = `rgba(6,4,3,${Math.min(0.93, darken)})`;
        g.fillRect(minX - 1, minY - 1, bw + 2, bh + 2);
    }
    g.restore();
}

// Bildschirm-Bounding-Box-Fläche eines projizierten Vierecks (Performance-Heuristik).
function quadBboxArea(q) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of q) {
        if (!isFinite(p.x) || !isFinite(p.y)) return 0;
        if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y;
    }
    return (maxX - minX) * (maxY - minY);
}

// Perspektivisch korrektes Texturieren eines Vierecks über vertikale Streifen.
// w0,w1 = obere Kante (Weltpunkte mit z), w3,w2 = untere Kante. Jeder Streifen wird
// einzeln projiziert → die Textur bleibt beim Annähern stabil (kein affines Wandern).
function drawPerspQuad(g, cam, w0, w1, w2, w3, img, darken) {
    const N = 5;
    const iw = img.width || img.naturalWidth || 256;
    const ih = img.height || img.naturalHeight || 256;
    let prevA = projCam(cam, w0.x, w0.y, w0.z);
    let prevB = projCam(cam, w3.x, w3.y, w3.z);
    for (let s = 1; s <= N; s++) {
        const u = s / N;
        const ax = w0.x + (w1.x - w0.x) * u, ay = w0.y + (w1.y - w0.y) * u, az = w0.z + (w1.z - w0.z) * u;
        const bx = w3.x + (w2.x - w3.x) * u, by = w3.y + (w2.y - w3.y) * u, bz = w3.z + (w2.z - w3.z) * u;
        const curA = projCam(cam, ax, ay, az);
        const curB = projCam(cam, bx, by, bz);
        if (prevA.depth > 0.06 && curA.depth > 0.06 && prevB.depth > 0.06 && curB.depth > 0.06) {
            const q0 = prevA, q1 = curA, q2 = curB, q3 = prevB;
            if (isFinite(q0.x) && isFinite(q1.x) && isFinite(q2.x) && isFinite(q3.x) &&
                isFinite(q0.y) && isFinite(q1.y) && isFinite(q2.y) && isFinite(q3.y)) {
                g.save();
                g.beginPath();
                g.moveTo(q0.x, q0.y); g.lineTo(q1.x, q1.y); g.lineTo(q2.x, q2.y); g.lineTo(q3.x, q3.y); g.closePath();
                g.clip();
                const m11 = q1.x - q0.x, m12 = q1.y - q0.y;
                const m21 = q3.x - q0.x, m22 = q3.y - q0.y;
                if (isFinite(m11) && isFinite(m12) && isFinite(m21) && isFinite(m22)) {
                    g.setTransform(m11, m12, m21, m22, q0.x, q0.y);
                    try { g.drawImage(img, ((s - 1) / N) * iw, 0, iw / N, ih, 0, 0, 1, 1); } catch (e) { }
                    g.setTransform(1, 0, 0, 1, 0, 0);
                }
                if (darken > 0.001) {
                    let mnX = Math.min(q0.x, q1.x, q2.x, q3.x), mnY = Math.min(q0.y, q1.y, q2.y, q3.y);
                    let mxX = Math.max(q0.x, q1.x, q2.x, q3.x), mxY = Math.max(q0.y, q1.y, q2.y, q3.y);
                    g.fillStyle = `rgba(6,4,3,${Math.min(0.93, darken)})`;
                    g.fillRect(mnX - 1, mnY - 1, mxX - mnX + 2, mxY - mnY + 2);
                }
                g.restore();
            }
        }
        prevA = curA; prevB = curB;
    }
}

// Perspektivisch korrektes Texturieren über ein NxN-Gitter (beide Achsen unterteilt).
// Für flach am Boden liegende Bilder (Leichen): die Textur "klebt" an der Welt und
// wandert beim Annähern NICHT mehr — wie eine Wand-/Bodentextur.
function drawPerspGrid(g, cam, w0, w1, w2, w3, img, darken, N) {
    N = N || 5;
    const iw = img.width || img.naturalWidth || 256;
    const ih = img.height || img.naturalHeight || 256;
    // Bilineare Welt-Position: u entlang Kante w0->w1 / w3->w2, v von oberer zu unterer Kante
    const P = (u, v) => {
        const ax = w0.x + (w1.x - w0.x) * u, ay = w0.y + (w1.y - w0.y) * u, az = w0.z + (w1.z - w0.z) * u;
        const bx = w3.x + (w2.x - w3.x) * u, by = w3.y + (w2.y - w3.y) * u, bz = w3.z + (w2.z - w3.z) * u;
        return projCam(cam, ax + (bx - ax) * v, ay + (by - ay) * v, az + (bz - az) * v);
    };
    // Zeilenweise projizierte Punkte cachen (jeder Punkt nur einmal projizieren)
    let rowTop = [];
    for (let i = 0; i <= N; i++) rowTop.push(P(i / N, 0));
    for (let j = 0; j < N; j++) {
        const v1 = (j + 1) / N;
        const rowBot = [];
        for (let i = 0; i <= N; i++) rowBot.push(P(i / N, v1));
        for (let i = 0; i < N; i++) {
            const q0 = rowTop[i], q1 = rowTop[i + 1], q2 = rowBot[i + 1], q3 = rowBot[i];
            if (q0.depth < 0.06 || q1.depth < 0.06 || q2.depth < 0.06 || q3.depth < 0.06) continue;
            if (!(isFinite(q0.x) && isFinite(q1.x) && isFinite(q2.x) && isFinite(q3.x) &&
                isFinite(q0.y) && isFinite(q1.y) && isFinite(q2.y) && isFinite(q3.y))) continue;
            g.save();
            g.beginPath();
            g.moveTo(q0.x, q0.y); g.lineTo(q1.x, q1.y); g.lineTo(q2.x, q2.y); g.lineTo(q3.x, q3.y); g.closePath();
            g.clip();
            const m11 = q1.x - q0.x, m12 = q1.y - q0.y, m21 = q3.x - q0.x, m22 = q3.y - q0.y;
            if (isFinite(m11) && isFinite(m12) && isFinite(m21) && isFinite(m22)) {
                g.setTransform(m11, m12, m21, m22, q0.x, q0.y);
                try { g.drawImage(img, (i / N) * iw, (j / N) * ih, iw / N, ih / N, 0, 0, 1, 1); } catch (e) { }
                g.setTransform(1, 0, 0, 1, 0, 0);
            }
            if (darken > 0.001) {
                const mnX = Math.min(q0.x, q1.x, q2.x, q3.x), mnY = Math.min(q0.y, q1.y, q2.y, q3.y);
                const mxX = Math.max(q0.x, q1.x, q2.x, q3.x), mxY = Math.max(q0.y, q1.y, q2.y, q3.y);
                g.fillStyle = `rgba(6,4,3,${Math.min(0.93, darken)})`;
                g.fillRect(mnX - 1, mnY - 1, mxX - mnX + 2, mxY - mnY + 2);
            }
            g.restore();
        }
        rowTop = rowBot;
    }
}

// Eine Basisfarbe um den Faktor k aufhellen/abdunkeln.
function shadeRGB(b, k) {
    if (k < 0) k = 0;
    return `rgb(${Math.min(255, b[0] * k) | 0},${Math.min(255, b[1] * k) | 0},${Math.min(255, b[2] * k) | 0})`;
}

// Zeichnet EINE Boxfläche als flach schattiertes Polygon mit aufgemalter Maserung.
// Rein geometrisch (aus den projizierten Eckpunkten) → die Oberfläche kann NICHT
// "wandern"/flackern wie eine bitmap-texturierte Fläche.
function drawShadedFace(g, quad, base, shade, grain) {
    for (const p of quad) if (!isFinite(p.x) || !isFinite(p.y)) return;
    g.beginPath();
    g.moveTo(quad[0].x, quad[0].y);
    g.lineTo(quad[1].x, quad[1].y);
    g.lineTo(quad[2].x, quad[2].y);
    g.lineTo(quad[3].x, quad[3].y);
    g.closePath();
    g.fillStyle = shadeRGB(base, shade);
    g.fill();
    if (grain) {
        const w = Math.hypot(quad[1].x - quad[0].x, quad[1].y - quad[0].y);
        g.lineWidth = Math.max(0.8, w * 0.02);
        g.strokeStyle = shadeRGB(base, shade * 0.55);
        for (const v of [0.27, 0.52, 0.78]) {
            const a = quadPoint(quad, 0.05, v), b = quadPoint(quad, 0.95, v);
            g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
        }
        // helle obere Kante (Lichtsaum)
        g.strokeStyle = shadeRGB(base, Math.min(1.6, shade * 1.5));
        g.beginPath(); g.moveTo(quad[0].x, quad[0].y); g.lineTo(quad[1].x, quad[1].y); g.stroke();
    }
}

// Zeichnet eine (optional gedrehte) 3D-Box in Weltkoordinaten.
// cx,cy = Mittelpunkt; theta = feste Welt-Drehung; hw/hd = halbe Breite/Tiefe
// (Welt-Einheiten); z0/z1 = Boden-/Deckenhöhe in Kacheln;
// tex = { base:[r,g,b], grain:true }; detail(g, quad, faceMeta) optional.
// Beleuchtungsfaktor für feststehende Deko-Geometrie. Wird vom Sprite-Renderer
// pro Objekt gesetzt: er steuert die HELLIGKEIT der Flächen (Taschenlampe), NICHT
// die Deckkraft. So bleibt ein nahes Möbelstück solide (undurchsichtig) und wird
// nur dunkler/heller — statt durchsichtig zu werden.
let _propLightK = 1;

function drawWorldBox(g, cam, cx, cy, theta, hw, hd, z0, z1, tex, detail) {
    const lk = _propLightK;
    const cs = Math.cos(theta), sn = Math.sin(theta);
    const local = [[hw, hd], [-hw, hd], [-hw, -hd], [hw, -hd]];
    const corners = local.map(([lx, ly]) => ({ x: cx + lx * cs - ly * sn, y: cy + lx * sn + ly * cs }));
    const pr = corners.map(c => ({ top: projCam(cam, c.x, c.y, z1), bot: projCam(cam, c.x, c.y, z0) }));
    for (const p of pr) if (p.top.depth < 0.06) return; // hinter der Kamera → überspringen

    // Sichtbare Seitenflächen sammeln (Vorderseiten), fernste zuerst zeichnen
    const faces = [];
    for (let i = 0; i < 4; i++) {
        const j = (i + 1) % 4;
        const A = corners[i], B = corners[j];
        const mx = (A.x + B.x) * 0.5, my = (A.y + B.y) * 0.5;
        const ox = mx - cx, oy = my - cy;                 // Außennormale
        const vx = cam.pX - mx, vy = cam.pY - my;
        const dot = vx * ox + vy * oy;
        if (dot <= 0) continue;                           // Rückseite → unsichtbar
        const len = Math.hypot(ox, oy) || 1, vlen = Math.hypot(vx, vy) || 1;
        const cosang = dot / (len * vlen);                // 0..1 wie frontal die Fläche steht
        const depth = (pr[i].top.depth + pr[j].top.depth) * 0.5;
        faces.push({ i, j, depth, shade: 0.4 + 0.5 * Math.max(0, Math.min(1, cosang)) });
    }
    faces.sort((a, b) => b.depth - a.depth);
    for (let k = 0; k < faces.length; k++) {
        const f = faces[k];
        f.isFront = (k === faces.length - 1);
        const A = pr[f.i], B = pr[f.j];
        const quad = [A.top, B.top, B.bot, A.bot];
        // Echte Foto-Textur (perspektivisch per Gitter → wandert NICHT), wenn vorhanden
        // und die Fläche groß genug auf dem Bildschirm ist. Sonst flach schattiert (billig).
        const litShade = f.shade * lk;
        if (tex.img && faceScreenArea(quad) >= 900) {
            const ci = corners[f.i], cj = corners[f.j];
            const w0 = { x: ci.x, y: ci.y, z: z1 }, w1 = { x: cj.x, y: cj.y, z: z1 };
            const w2 = { x: cj.x, y: cj.y, z: z0 }, w3 = { x: ci.x, y: ci.y, z: z0 };
            const N = faceScreenArea(quad) > 9000 ? 4 : 3;
            drawPerspGrid(g, cam, w0, w1, w2, w3, tex.img, 1 - Math.min(1, litShade), N);
        } else {
            drawShadedFace(g, quad, tex.base, litShade, tex.grain);
        }
        if (detail) detail(g, quad, f);
    }

    // Deckfläche nur sichtbar, wenn die Oberkante unter Augenhöhe liegt
    const eyeHz = 0.5 + cam.pz;
    if (z1 < eyeHz - 0.02) {
        const quad = [pr[0].top, pr[1].top, pr[2].top, pr[3].top];
        if (tex.img && faceScreenArea(quad) >= 900) {
            const c = corners;
            drawPerspGrid(g, cam,
                { x: c[0].x, y: c[0].y, z: z1 }, { x: c[1].x, y: c[1].y, z: z1 },
                { x: c[2].x, y: c[2].y, z: z1 }, { x: c[3].x, y: c[3].y, z: z1 },
                tex.img, 1 - Math.min(1, 0.98 * lk), faceScreenArea(quad) > 9000 ? 4 : 3);
        } else {
            drawShadedFace(g, quad, tex.base, 0.98 * lk, tex.grain);
        }
        if (detail) detail(g, quad, { isTop: true, shade: 0.95 });
    } else if (z0 > eyeHz + 0.02) {
        const quad = [pr[0].bot, pr[3].bot, pr[2].bot, pr[1].bot];
        drawShadedFace(g, quad, tex.base, 0.4 * lk, false);
    }
}

// Grobe Bildschirm-Fläche eines projizierten Vierecks (für Detailgrad-Entscheidungen).
function faceScreenArea(quad) {
    const minX = Math.min(quad[0].x, quad[1].x, quad[2].x, quad[3].x);
    const maxX = Math.max(quad[0].x, quad[1].x, quad[2].x, quad[3].x);
    const minY = Math.min(quad[0].y, quad[1].y, quad[2].y, quad[3].y);
    const maxY = Math.max(quad[0].y, quad[1].y, quad[2].y, quad[3].y);
    return (maxX - minX) * (maxY - minY);
}

// Lokale (Möbel-)Versatzposition in Weltkoordinaten umrechnen
function l2w(cx, cy, cs, sn, lx, ly) { return [cx + lx * cs - ly * sn, cy + lx * sn + ly * cs]; }

// Weicher Bodenschatten am festen Weltstandort — verankert das Objekt sichtbar
// auf dem Boden (macht klar: es steht HIER und bewegt sich nicht mit dem Spieler).
function drawGroundShadow(g, cam, cx, cy, radiusWorld) {
    const p = projCam(cam, cx, cy, 0);
    if (p.depth < 0.12) return;
    const rx = (radiusWorld / TILE_SIZE) * (cam.h / p.depth);
    if (rx < 1.5) return;
    g.beginPath();
    g.fillStyle = 'rgba(0,0,0,0.42)';
    g.ellipse(p.x, p.y, rx, rx * 0.38, 0, 0, Math.PI * 2);
    g.fill();
}

// ---- MÖBEL als echte 3D-Boxen ----
function drawFurniture3D(g, cam, item) {
    const T = TILE_SIZE, cx = item.x, cy = item.y, th = item.angle || 0;
    const cs = Math.cos(th), sn = Math.sin(th);
    const wood = { base: [128, 88, 50], grain: true, img: propTexSmall.wood };
    const crate = { base: [112, 76, 42], grain: true, img: propTexSmall.crate };
    drawGroundShadow(g, cam, cx, cy, 0.34 * T);

    if (item.furnType === 'table') {
        // vier Beine + Platte (deutlich kompakter)
        const legHw = 0.04 * T;
        for (const [ox, oy] of [[0.29, 0.17], [-0.29, 0.17], [-0.29, -0.17], [0.29, -0.17]]) {
            const [lx, ly] = l2w(cx, cy, cs, sn, ox * T, oy * T);
            drawWorldBox(g, cam, lx, ly, th, legHw, legHw, 0, 0.32, wood);
        }
        drawWorldBox(g, cam, cx, cy, th, 0.34 * T, 0.21 * T, 0.32, 0.37, wood);
    } else if (item.furnType === 'chair') {
        const legHw = 0.03 * T;
        for (const [ox, oy] of [[0.12, 0.12], [-0.12, 0.12], [-0.12, -0.12], [0.12, -0.12]]) {
            const [lx, ly] = l2w(cx, cy, cs, sn, ox * T, oy * T);
            drawWorldBox(g, cam, lx, ly, th, legHw, legHw, 0, 0.30, wood);
        }
        drawWorldBox(g, cam, cx, cy, th, 0.15 * T, 0.15 * T, 0.30, 0.34, wood);
        const [bx, by] = l2w(cx, cy, cs, sn, -0.12 * T, 0);
        drawWorldBox(g, cam, bx, by, th, 0.035 * T, 0.15 * T, 0.34, 0.60, wood);
    } else if (item.furnType === 'crate') {
        drawWorldBox(g, cam, cx, cy, th, 0.22 * T, 0.22 * T, 0, 0.42, crate, (gg, quad, f) => {
            // Diagonalstrebe
            if (f && !f.isTop) {
                gg.strokeStyle = `rgba(20,12,6,${0.5 * f.shade})`;
                gg.lineWidth = Math.max(1, (quad[1].x - quad[0].x) * 0.04);
                gg.beginPath();
                gg.moveTo(quad[0].x, quad[0].y); gg.lineTo(quad[2].x, quad[2].y);
                gg.moveTo(quad[1].x, quad[1].y); gg.lineTo(quad[3].x, quad[3].y);
                gg.stroke();
            }
        });
    } else if (item.furnType === 'barrel') {
        drawWorldBox(g, cam, cx, cy, th, 0.20 * T, 0.20 * T, 0, 0.48, wood, (gg, quad, f) => {
            if (f && !f.isTop) {
                // Eisenreifen
                gg.strokeStyle = 'rgba(20,20,24,0.85)';
                for (const v of [0.22, 0.72]) {
                    const a = quadPoint(quad, 0, v), b = quadPoint(quad, 1, v);
                    gg.lineWidth = Math.max(2, (b.x - a.x) * 0.12);
                    gg.beginPath(); gg.moveTo(a.x, a.y); gg.lineTo(b.x, b.y); gg.stroke();
                }
            }
        });
    } else { // shelf / Regal
        drawWorldBox(g, cam, cx, cy, th, 0.24 * T, 0.13 * T, 0, 0.72, wood, (gg, quad, f) => {
            if (!f || f.isTop || !f.isFront) return;
            const books = ['#5a2020', '#3a4a2a', '#2a3a55', '#6a5520', '#402a40', '#244d4d'];
            for (let r = 0; r < 4; r++) {
                const v = 0.16 + r * 0.21;
                // Regalbrett
                const a = quadPoint(quad, 0.04, v), b = quadPoint(quad, 0.96, v);
                gg.strokeStyle = `rgba(15,9,4,${0.7 * f.shade})`;
                gg.lineWidth = Math.max(1, (b.x - a.x) * 0.03);
                gg.beginPath(); gg.moveTo(a.x, a.y); gg.lineTo(b.x, b.y); gg.stroke();
                // Bücher auf dem Brett
                let u = 0.08;
                let bi = r;
                while (u < 0.9) {
                    const bw = 0.05 + ((bi * 37) % 9) * 0.006;
                    const vT = v - (0.10 + ((bi * 53) % 7) * 0.006);
                    const p0 = quadPoint(quad, u, vT), p1 = quadPoint(quad, u + bw, vT);
                    const p2 = quadPoint(quad, u + bw, v), p3 = quadPoint(quad, u, v);
                    gg.fillStyle = books[bi % books.length];
                    gg.globalAlpha = (gg.globalAlpha) * f.shade;
                    gg.beginPath(); gg.moveTo(p0.x, p0.y); gg.lineTo(p1.x, p1.y);
                    gg.lineTo(p2.x, p2.y); gg.lineTo(p3.x, p3.y); gg.closePath(); gg.fill();
                    gg.globalAlpha = gg.globalAlpha / f.shade;
                    u += bw + 0.012;
                    bi++;
                }
            }
        });
    }
}

// ---- SCHRANK als echte 3D-Box (kleiner & solide) ----
function drawCloset3D(g, cam, item) {
    const T = TILE_SIZE, cx = item.x, cy = item.y, th = item.angle || 0;
    const wood = { base: [120, 82, 46], grain: true, img: propTexSmall.wood };
    drawGroundShadow(g, cam, cx, cy, 0.28 * T);
    drawWorldBox(g, cam, cx, cy, th, 0.24 * T, 0.17 * T, 0, 0.80, wood, (gg, quad, f) => {
        if (!f || f.isTop || !f.isFront) return;
        // Zwei Türen mit Paneelen und Griffen auf der Vorderseite
        gg.save();
        gg.globalAlpha = gg.globalAlpha * f.shade;
        for (const [u0, u1] of [[0.06, 0.48], [0.52, 0.94]]) {
            // Paneel-Rahmen
            gg.strokeStyle = 'rgba(15,9,4,0.85)';
            gg.lineWidth = Math.max(1, (quad[1].x - quad[0].x) * 0.02);
            const c0 = quadPoint(quad, u0, 0.08), c1 = quadPoint(quad, u1, 0.08);
            const c2 = quadPoint(quad, u1, 0.92), c3 = quadPoint(quad, u0, 0.92);
            gg.beginPath(); gg.moveTo(c0.x, c0.y); gg.lineTo(c1.x, c1.y);
            gg.lineTo(c2.x, c2.y); gg.lineTo(c3.x, c3.y); gg.closePath(); gg.stroke();
            // Innenpaneele
            gg.strokeStyle = 'rgba(90,60,30,0.4)';
            for (const [vA, vB] of [[0.14, 0.46], [0.54, 0.86]]) {
                const a = quadPoint(quad, u0 + 0.04, vA), b = quadPoint(quad, u1 - 0.04, vA);
                const c = quadPoint(quad, u1 - 0.04, vB), d = quadPoint(quad, u0 + 0.04, vB);
                gg.beginPath(); gg.moveTo(a.x, a.y); gg.lineTo(b.x, b.y);
                gg.lineTo(c.x, c.y); gg.lineTo(d.x, d.y); gg.closePath(); gg.stroke();
            }
            // Griff
            const h = quadPoint(quad, u0 < 0.5 ? u1 - 0.04 : u0 + 0.04, 0.5);
            gg.fillStyle = '#caa24a';
            gg.beginPath(); gg.arc(h.x, h.y, Math.max(1.5, (quad[1].x - quad[0].x) * 0.018), 0, Math.PI * 2); gg.fill();
        }
        gg.restore();
    });
}

// ---- LEICHE/SKELETT: realistische Aufsicht (Kopf oben), als Boden-Decal ----
// len = Körperlänge in Pixeln; gezeichnet relativ zu (cx,cy = Körpermitte).
function drawCorpseTopDown(c, cx, cy, len, type, seed) {
    const rnd = makeSeededRandom(((seed || 0) * 9973 | 0) + 5);
    const u = len / 100; // Maßstabseinheit
    c.save();
    c.lineCap = 'round'; c.lineJoin = 'round';

    // ---- Blutlache unter allem (mehrere weiche, dunkle Schichten) ----
    function blood(x, y, rx, ry, alpha) {
        const g = c.createRadialGradient(x, y, 1, x, y, Math.max(rx, ry));
        g.addColorStop(0, `rgba(66,4,5,${alpha})`);
        g.addColorStop(0.65, `rgba(40,0,0,${alpha * 0.65})`);
        g.addColorStop(1, 'rgba(22,0,0,0)');
        c.fillStyle = g;
        c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); c.fill();
    }
    blood(cx, cy + 6 * u, 58 * u, 86 * u, 0.85);
    for (let i = 0; i < 7; i++) {
        const a = rnd() * Math.PI * 2, d = (35 + rnd() * 50) * u;
        blood(cx + Math.cos(a) * d, cy + Math.sin(a) * d, (8 + rnd() * 16) * u, (8 + rnd() * 16) * u, 0.7);
    }

    if (type === 'skeleton') {
        const bone = '#bfb393', boneHi = '#ded2b2', boneSh = 'rgba(55,48,34,0.55)';
        // Verwesungsschatten
        c.fillStyle = 'rgba(64,54,34,0.22)';
        c.beginPath(); c.ellipse(cx, cy, 42 * u, 80 * u, 0, 0, Math.PI * 2); c.fill();

        // Beine (Femur + Tibia, leicht gespreizt)
        c.strokeStyle = bone; c.lineWidth = 6 * u;
        c.beginPath(); c.moveTo(cx - 7 * u, cy + 24 * u); c.lineTo(cx - 15 * u, cy + 56 * u); c.lineTo(cx - 11 * u, cy + 86 * u); c.stroke();
        c.beginPath(); c.moveTo(cx + 7 * u, cy + 24 * u); c.lineTo(cx + 18 * u, cy + 54 * u); c.lineTo(cx + 23 * u, cy + 82 * u); c.stroke();

        // Becken
        c.strokeStyle = bone; c.lineWidth = 7 * u;
        c.beginPath(); c.arc(cx, cy + 24 * u, 14 * u, Math.PI * 0.12, Math.PI * 0.88); c.stroke();
        c.beginPath(); c.arc(cx, cy + 24 * u, 14 * u, Math.PI * 1.12, Math.PI * 1.88); c.stroke();

        // Wirbelsäule
        c.strokeStyle = boneHi; c.lineWidth = 4 * u;
        c.beginPath(); c.moveTo(cx, cy - 40 * u); c.lineTo(cx + 1 * u, cy + 18 * u); c.stroke();

        // Brustkorb + dunkle Höhle
        c.fillStyle = bone; c.beginPath(); c.ellipse(cx, cy - 18 * u, 20 * u, 26 * u, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = 'rgba(16,12,8,0.9)'; c.beginPath(); c.ellipse(cx, cy - 16 * u, 11 * u, 18 * u, 0, 0, Math.PI * 2); c.fill();
        c.strokeStyle = bone; c.lineWidth = 2.4 * u;
        for (let r = 0; r < 6; r++) {
            const ry = cy - 34 * u + r * 6 * u;
            c.beginPath(); c.moveTo(cx - 1 * u, ry); c.quadraticCurveTo(cx - 20 * u, ry + 3 * u, cx - 17 * u, ry + 9 * u); c.stroke();
            c.beginPath(); c.moveTo(cx + 1 * u, ry); c.quadraticCurveTo(cx + 20 * u, ry + 3 * u, cx + 17 * u, ry + 9 * u); c.stroke();
        }

        // Arme (Humerus + Unterarm, gespreizt)
        c.lineWidth = 4 * u;
        c.beginPath(); c.moveTo(cx - 13 * u, cy - 28 * u); c.lineTo(cx - 38 * u, cy - 16 * u); c.lineTo(cx - 50 * u, cy - 2 * u); c.stroke();
        c.beginPath(); c.moveTo(cx + 13 * u, cy - 28 * u); c.lineTo(cx + 36 * u, cy - 24 * u); c.lineTo(cx + 48 * u, cy - 30 * u); c.stroke();

        // Schädel
        const skX = cx, skY = cy - 56 * u, skR = 13 * u;
        c.fillStyle = boneHi; c.beginPath(); c.ellipse(skX, skY, skR, skR * 1.12, 0, 0, Math.PI * 2); c.fill();
        c.strokeStyle = boneSh; c.lineWidth = 1.5 * u; c.stroke();
        c.fillStyle = '#000';
        c.beginPath();
        c.ellipse(skX - skR * 0.42, skY - skR * 0.08, skR * 0.3, skR * 0.4, 0, 0, Math.PI * 2);
        c.ellipse(skX + skR * 0.42, skY - skR * 0.08, skR * 0.3, skR * 0.4, 0, 0, Math.PI * 2);
        c.fill();
        c.beginPath(); c.moveTo(skX, skY + skR * 0.12); c.lineTo(skX - skR * 0.13, skY + skR * 0.5); c.lineTo(skX + skR * 0.13, skY + skR * 0.5); c.closePath(); c.fill();
        c.fillStyle = bone; c.fillRect(skX - skR * 0.5, skY + skR * 0.62, skR, skR * 0.32);
        c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 0.8 * u;
        for (let t = 1; t < 4; t++) { const tx = skX - skR * 0.5 + t * skR * 0.33; c.beginPath(); c.moveTo(tx, skY + skR * 0.62); c.lineTo(tx, skY + skR * 0.94); c.stroke(); }
    } else {
        // GORE: zerfetzter Körper mit Kleidung, Wunde und Eingeweiden
        const skin = '#7c6b60', skinSh = '#473a34', cloth = '#2c2930', clothSh = '#171519';
        // Beine (Hose)
        c.strokeStyle = cloth; c.lineWidth = 15 * u;
        c.beginPath(); c.moveTo(cx - 6 * u, cy + 18 * u); c.lineTo(cx - 17 * u, cy + 50 * u); c.lineTo(cx - 13 * u, cy + 80 * u); c.stroke();
        c.beginPath(); c.moveTo(cx + 6 * u, cy + 18 * u); c.lineTo(cx + 21 * u, cy + 48 * u); c.lineTo(cx + 28 * u, cy + 74 * u); c.stroke();
        // Schuhe
        c.strokeStyle = '#0c0a09'; c.lineWidth = 12 * u;
        c.beginPath(); c.moveTo(cx - 13 * u, cy + 80 * u); c.lineTo(cx - 15 * u, cy + 90 * u); c.stroke();
        c.beginPath(); c.moveTo(cx + 28 * u, cy + 74 * u); c.lineTo(cx + 32 * u, cy + 83 * u); c.stroke();
        // Arme
        c.strokeStyle = cloth; c.lineWidth = 11 * u;
        c.beginPath(); c.moveTo(cx - 11 * u, cy - 24 * u); c.lineTo(cx - 40 * u, cy - 12 * u); c.lineTo(cx - 53 * u, cy - 2 * u); c.stroke();
        c.beginPath(); c.moveTo(cx + 11 * u, cy - 24 * u); c.lineTo(cx + 40 * u, cy - 22 * u); c.lineTo(cx + 51 * u, cy - 32 * u); c.stroke();
        // Hände
        c.fillStyle = skin;
        c.beginPath(); c.arc(cx - 55 * u, cy - 1 * u, 6 * u, 0, Math.PI * 2); c.fill();
        c.beginPath(); c.arc(cx + 53 * u, cy - 34 * u, 6 * u, 0, Math.PI * 2); c.fill();
        // Torso (Kleidung mit Schattierung)
        const tg = c.createLinearGradient(cx - 24 * u, 0, cx + 24 * u, 0);
        tg.addColorStop(0, clothSh); tg.addColorStop(0.5, cloth); tg.addColorStop(1, clothSh);
        c.fillStyle = tg; c.beginPath(); c.ellipse(cx, cy - 16 * u, 24 * u, 32 * u, 0, 0, Math.PI * 2); c.fill();
        // aufgerissene Wunde
        c.fillStyle = '#380708'; c.beginPath(); c.ellipse(cx + 2 * u, cy - 14 * u, 13 * u, 19 * u, 0.2, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#5e0d0d'; c.beginPath(); c.ellipse(cx + 2 * u, cy - 14 * u, 8 * u, 13 * u, 0.2, 0, Math.PI * 2); c.fill();
        // freiliegende Rippen
        c.strokeStyle = 'rgba(214,204,178,0.85)'; c.lineWidth = 2 * u;
        for (let r = 0; r < 3; r++) { const ry = cy - 24 * u + r * 8 * u; c.beginPath(); c.moveTo(cx - 6 * u, ry); c.quadraticCurveTo(cx, ry + 2 * u, cx + 8 * u, ry); c.stroke(); }
        // Eingeweide-Strang
        c.strokeStyle = 'rgba(92,16,16,0.9)'; c.lineWidth = 4 * u;
        c.beginPath(); c.moveTo(cx + 4 * u, cy); c.quadraticCurveTo(cx + 18 * u, cy + 8 * u, cx + 9 * u, cy + 18 * u); c.stroke();
        // Hals + Kopf
        c.strokeStyle = skinSh; c.lineWidth = 9 * u; c.beginPath(); c.moveTo(cx, cy - 46 * u); c.lineTo(cx, cy - 38 * u); c.stroke();
        const hg = c.createRadialGradient(cx - 4 * u, cy - 54 * u, 2, cx, cy - 52 * u, 15 * u);
        hg.addColorStop(0, skin); hg.addColorStop(1, skinSh);
        c.fillStyle = hg; c.beginPath(); c.arc(cx, cy - 52 * u, 13 * u, 0, Math.PI * 2); c.fill();
        // Haare (dunkler Oberkopf)
        c.fillStyle = '#14110e'; c.beginPath(); c.arc(cx, cy - 56 * u, 12 * u, Math.PI * 0.95, Math.PI * 2.05); c.fill();
        // Blutrinnsal
        c.strokeStyle = 'rgba(72,2,2,0.8)'; c.lineWidth = 2.5 * u;
        c.beginPath(); c.moveTo(cx + 6 * u, cy - 48 * u); c.quadraticCurveTo(cx + 16 * u, cy - 42 * u, cx + 14 * u, cy - 32 * u); c.stroke();
    }

    // dunkle Spritzer ringsum
    for (let i = 0; i < 14; i++) {
        const a = rnd() * Math.PI * 2, d = rnd() * 78 * u;
        c.fillStyle = `rgba(${40 + rnd() * 30 | 0},0,0,${0.4 + rnd() * 0.4})`;
        c.beginPath(); c.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, rnd() * 3 * u + 0.5, 0, Math.PI * 2); c.fill();
    }
    c.restore();
}

const _corpseCanvasCache = {};
function getCorpseCanvas(type, seed) {
    const key = type + '_' + (seed | 0);
    if (_corpseCanvasCache[key]) return _corpseCanvasCache[key];
    const cv = document.createElement('canvas');
    cv.width = 160; cv.height = 220; // hochkant: Körper liegt der Länge nach
    drawCorpseTopDown(cv.getContext('2d'), 80, 110, 112, type, seed);
    _corpseCanvasCache[key] = cv;
    return cv;
}
function drawCorpseDecal(g, cam, item) {
    const T = TILE_SIZE, cx = item.x, cy = item.y, th = item.angle || 0;
    const cs = Math.cos(th), sn = Math.sin(th);
    // Seitenverhältnis = Canvas (160:220) → keine Verzerrung des Körpers
    const hw = 0.40 * T, hd = 0.55 * T; // flach auf dem Boden liegend (z = 0)
    const c0 = [hw, hd], c1 = [-hw, hd], c2 = [-hw, -hd], c3 = [hw, -hd];
    const w = ([lx, ly]) => ({ x: cx + lx * cs - ly * sn, y: cy + lx * sn + ly * cs, z: 0 });
    // schneller Kamera-Test (Mittelpunkt vor der Kamera?)
    if (projCam(cam, cx, cy, 0).depth < 0.1) return;
    // Perspektivisch korrektes NxN-Gitter → die Leiche klebt fest am Boden wie eine
    // Wandtextur und "warpt" beim Annähern nicht mehr.
    drawPerspGrid(g, cam, w(c0), w(c1), w(c2), w(c3), getCorpseCanvas(item.corpseType, item.seed), 0.12, 6);
}

// Panik beim zu langen Verstecken: pochender Herzschlag + zunehmende Rotfärbung.
// Das Bild "pulsiert" im Takt des Herzens (Vignette zieht sich bei jedem Schlag
// zusammen) und färbt sich immer stärker rot, je näher der Tod rückt.
function drawHidePanic() {
    const panic = hideState.panic || 0;
    if (panic < 0.02) return;
    const W = canvas.width, H = canvas.height;
    const beat = hideState.beat || 0;

    // Grundrote Tönung + Pochen bei jedem Schlag
    const baseRed = panic * 0.22;
    const beatRed = panic * beat * 0.42;
    ctx.fillStyle = `rgba(120,0,0,${Math.min(0.72, baseRed + beatRed)})`;
    ctx.fillRect(0, 0, W, H);

    // Rote Vignette, die sich im Herzschlag-Takt zusammenzieht ("pocht")
    const inner = Math.max(W, H) * (0.55 - panic * 0.18 - beat * panic * 0.12);
    const outer = Math.max(W, H) * 0.75;
    const vig = ctx.createRadialGradient(W / 2, H / 2, Math.max(1, inner), W / 2, H / 2, outer);
    vig.addColorStop(0, 'rgba(60,0,0,0)');
    vig.addColorStop(1, `rgba(90,0,0,${Math.min(0.95, 0.45 + panic * 0.5)})`);
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, W, H);

    // Warnhinweis, sobald es brenzlig wird
    if (panic > 0.45) {
        ctx.save();
        ctx.globalAlpha = 0.55 + beat * 0.45;
        ctx.fillStyle = '#ff5555';
        ctx.font = `bold ${Math.floor(H * 0.035)}px 'Special Elite', serif`;
        ctx.textAlign = 'center';
        ctx.fillText('GET OUT — IT CAN HEAR YOUR HEART', W / 2, H * 0.14);
        ctx.restore();
        ctx.textAlign = 'left';
    }
}

// ==========================================
// VERSTECK-OVERLAY: Blick aus dem Schrank durch einen senkrechten Türspalt
// ==========================================
function drawHideOverlay() {
    const W = canvas.width, H = canvas.height;
    const crackW = W * 0.16;                 // Breite des Spalts
    const crackX = W * 0.5 - crackW / 2;

    // Schranktüren (dunkles Holz) links & rechts — lassen den Spalt in der Mitte frei
    const woodL = ctx.createLinearGradient(0, 0, crackX, 0);
    woodL.addColorStop(0, '#070503'); woodL.addColorStop(1, '#23160b');
    ctx.fillStyle = woodL; ctx.fillRect(0, 0, crackX, H);
    const woodR = ctx.createLinearGradient(crackX + crackW, 0, W, 0);
    woodR.addColorStop(0, '#23160b'); woodR.addColorStop(1, '#070503');
    ctx.fillStyle = woodR; ctx.fillRect(crackX + crackW, 0, W - (crackX + crackW), H);

    // Maserung als feine senkrechte Linien
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1;
    for (let x = 12; x < crackX - 4; x += 18) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 6, H); ctx.stroke(); }
    for (let x = crackX + crackW + 12; x < W - 4; x += 18) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 6, H); ctx.stroke(); }

    // Abdunkelung an den Spalträndern (Licht fällt nur durch die Mitte)
    const edge = ctx.createLinearGradient(crackX - 30, 0, crackX + crackW + 30, 0);
    edge.addColorStop(0, 'rgba(0,0,0,0.85)');
    edge.addColorStop(0.5, 'rgba(0,0,0,0)');
    edge.addColorStop(1, 'rgba(0,0,0,0.85)');
    ctx.fillStyle = edge;
    ctx.fillRect(crackX - 30, 0, crackW + 60, H);

    // QTE-Oberfläche
    if (hideState.minigame) drawHideMinigameUI(W, H);
}

function drawHideMinigameUI(W, H) {
    const barW = W * 0.46, barH = Math.max(10, H * 0.045);
    const bx = W * 0.5 - barW / 2, by = H * 0.82;

    // Hinweis-Text oben
    ctx.fillStyle = hideState.flashTimer > 0 ? (hideState.flashGood ? '#66ff99' : '#ff4030') : '#ffffff';
    ctx.font = `bold ${Math.floor(H * 0.05)}px Arial`;
    ctx.textAlign = 'center';
    ctx.fillText('STAY QUIET!', W * 0.5, by - H * 0.16);

    // Panel-Hintergrund
    ctx.fillStyle = 'rgba(0,0,0,0.65)';
    ctx.fillRect(bx - 14, by - H * 0.11, barW + 28, barH + H * 0.18);

    // geforderte Taste (groß)
    ctx.fillStyle = '#ffd24a';
    ctx.font = `bold ${Math.floor(H * 0.09)}px Arial`;
    ctx.fillText(hideState.key, W * 0.5, by - H * 0.02);

    // Balken + Zielzone + Marker
    ctx.fillStyle = 'rgba(40,40,40,0.9)';
    ctx.fillRect(bx, by, barW, barH);
    ctx.fillStyle = 'rgba(0,210,70,0.45)';
    ctx.fillRect(bx + barW * 0.40, by, barW * 0.20, barH);
    ctx.strokeStyle = '#33ff77'; ctx.lineWidth = 2;
    ctx.strokeRect(bx + barW * 0.40, by, barW * 0.20, barH);
    ctx.strokeStyle = '#999'; ctx.lineWidth = 2; ctx.strokeRect(bx, by, barW, barH);
    const mx = bx + hideState.marker * barW;
    ctx.fillStyle = hideState.flashTimer > 0 ? (hideState.flashGood ? '#00ff66' : '#ff2200') : '#ffffff';
    ctx.fillRect(mx - 3, by - 8, 6, barH + 16);

    // Fehlversuche (3 Kreuze)
    ctx.font = `bold ${Math.floor(H * 0.045)}px Arial`;
    const xs = W * 0.5 - H * 0.06;
    for (let i = 0; i < 3; i++) {
        ctx.fillStyle = i < hideState.strikes ? '#ff2020' : '#555';
        ctx.fillText('✕', xs + i * H * 0.06, by + barH + H * 0.07);
    }
    ctx.textAlign = 'left';
}

function drawDeathMonster() {
    const dCanvas = document.getElementById('deathMonsterCanvas');
    if (!dCanvas) return;
    dCanvas.width = 600;
    dCanvas.height = 600;
    const dCtx = dCanvas.getContext('2d');

    function animateDeathMonster() {
        const time = Date.now() * 0.001;

        dCtx.fillStyle = '#000';
        dCtx.fillRect(0, 0, 600, 600);

        // Das echte Ingame-Monster, von der Brust aufwärts, atmet langsam heran
        const breathScale = 1 + Math.sin(time * 0.7) * 0.015;
        const mh = 600 * 2.3 * breathScale;
        const cx = 300 + (noise2D(Math.floor(time * 8), 4.4) - 0.5) * 8;
        const top = 250 - mh * 0.155; // Kopf bleibt im Bildfokus

        drawMonsterModel(dCtx, cx, top, mh, mh, { isChase: true });

        // Sterbender Taschenlampen-Schein: nur das Gesicht beleuchtet,
        // der Rand läuft auf VOLLES Schwarz aus, damit der Canvas nahtlos
        // in den Hintergrund des Todesbildschirms übergeht
        const light = dCtx.createRadialGradient(300, 240, 60, 300, 270, 300);
        light.addColorStop(0, 'rgba(0,0,0,0)');
        light.addColorStop(0.6, 'rgba(0,0,0,0.5)');
        light.addColorStop(1, 'rgba(0,0,0,1)');
        dCtx.fillStyle = light;
        dCtx.fillRect(0, 0, 600, 600);

        // Filmkorn
        for (let i = 0; i < 350; i++) {
            dCtx.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
            dCtx.fillRect(Math.random() * 600, Math.random() * 600, 1.5, 1.5);
        }

        // Gelegentliches Flackern wie eine sterbende Lampe
        if (noise2D(Math.floor(time * 6), 7.7) > 0.82) {
            dCtx.fillStyle = 'rgba(0,0,0,0.55)';
            dCtx.fillRect(0, 0, 600, 600);
        }

        if (gameState === 'gameover') requestAnimationFrame(animateDeathMonster);
    }
    animateDeathMonster(); // Start the animation loop
}

// Füllt die Todes-Statistik (wird sowohl vom Tutorial als auch vom Todesbildschirm gebraucht)
function populateDeathStats() {
    const statsEl = document.getElementById('death-stats');
    if (!statsEl) return;
    const survived = gameRunStartTime > 0 ? Math.floor((Date.now() - gameRunStartTime) / 1000) : 0;
    const mins = Math.floor(survived / 60);
    const secs = String(survived % 60).padStart(2, '0');
    const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
    let floorName = floorNames[currentFloor] || (currentFloor + ". Floor");
    if (maps.length > 0 && currentFloor === maps.length - 1) floorName = "Attic";
    statsEl.innerHTML =
        `<div class="stat"><div class="stat-label">Keys</div><div class="stat-value">${player.keys} / ${TOTAL_KEYS}</div></div>` +
        `<div class="stat"><div class="stat-label">Floor</div><div class="stat-value">${floorName}</div></div>` +
        `<div class="stat"><div class="stat-label">Survived</div><div class="stat-value">${mins}:${secs}</div></div>`;
}

// ==========================================
// KURZES TUTORIAL NACH DEM TOD: Wie man dem Monster entkommt.
// Das Monster ist dabei sichtbar; ein Tastendruck/Klick überspringt es.
// ==========================================
let tutorialActive = false;
let tutorialCanSkipAt = 0;
let tutorialAutoTimer = null;

function showMonsterTutorial() {
    const ts = document.getElementById('tutorial-screen');
    if (!ts) { document.getElementById('game-over').classList.remove('hidden'); drawDeathMonster(); return; }
    tutorialActive = true;
    tutorialCanSkipAt = Date.now() + 700; // kurze Sperre, damit man es überhaupt sieht
    ts.classList.remove('hidden');
    animateTutorialMonster();
    // Sicherheits-Auto-Weiter, falls keine Taste gedrückt wird
    clearTimeout(tutorialAutoTimer);
    tutorialAutoTimer = setTimeout(endTutorialShowDeath, 17000);
}

function endTutorialShowDeath() {
    if (!tutorialActive) return;
    tutorialActive = false;
    clearTimeout(tutorialAutoTimer);
    const ts = document.getElementById('tutorial-screen');
    if (ts) ts.classList.add('hidden');
    document.getElementById('game-over').classList.remove('hidden');
    drawDeathMonster();
}

function animateTutorialMonster() {
    const cv = document.getElementById('tutorialMonsterCanvas');
    if (!cv) return;
    cv.width = 360; cv.height = 360;
    const c = cv.getContext('2d');
    function loop() {
        if (!tutorialActive) return;
        const t = Date.now() * 0.001;
        c.fillStyle = '#000';
        c.fillRect(0, 0, 360, 360);
        // Das Monster lauert und atmet, zuckt gelegentlich
        const breath = 1 + Math.sin(t * 1.1) * 0.03;
        const mh = 360 * 1.85 * breath;
        const cx = 180 + (noise2D(Math.floor(t * 7), 5.1) - 0.5) * 12;
        const top = 150 - mh * 0.155;
        drawMonsterModel(c, cx, top, mh, mh, { isChase: true, twitchScale: 1.4 });
        // weicher Lichtkegel, Ränder ins Schwarze
        const lg = c.createRadialGradient(180, 150, 40, 180, 180, 195);
        lg.addColorStop(0, 'rgba(0,0,0,0)');
        lg.addColorStop(0.62, 'rgba(0,0,0,0.55)');
        lg.addColorStop(1, 'rgba(0,0,0,1)');
        c.fillStyle = lg;
        c.fillRect(0, 0, 360, 360);
        // Filmkorn
        for (let i = 0; i < 120; i++) {
            c.fillStyle = `rgba(255,255,255,${Math.random() * 0.05})`;
            c.fillRect(Math.random() * 360, Math.random() * 360, 1.5, 1.5);
        }
        requestAnimationFrame(loop);
    }
    loop();
}

// Blendet alle Spiel-HUD-Elemente aus (für Tod und Sieg)
function hideGameHud() {
    hideHudMinimap();
    ['emf-container', 'stamina-bar-container', 'stamina-percentage-text', 'message', 'interaction-prompt', 'floor-popup', 'crosshair']
        .forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.add('hidden');
        });
}

// Blendet die Spiel-HUD-Elemente ein (beim Spielstart). Im Hauptmenü bleiben
// sie ausgeblendet, damit das atmosphärische 3D-Setting durchscheinen kann.
function showGameHud() {
    ['emf-container', 'stamina-bar-container', 'stamina-percentage-text', 'crosshair']
        .forEach(id => {
            const el = document.getElementById(id);
            if (el) el.classList.remove('hidden');
        });
}

// ==========================================
// PAUSE-MENÜ (ESC)
// Friert die Simulation ein (das gerenderte Bild bleibt als Standbild stehen),
// gibt den Mauszeiger frei und zeigt ein stimmungsvolles Menü.
// ==========================================
function pauseGame() {
    if (gameState !== 'playing' || isPaused || hideState.active || tutorialActive) return;
    isPaused = true;
    const menu = document.getElementById('pause-menu');
    if (menu) menu.classList.remove('hidden');
    // Mauszeiger freigeben (falls ESC ihn nicht ohnehin schon gelöst hat)
    if (document.pointerLockElement === canvas) document.exitPointerLock();
    // Atmosphäre leiser drehen, damit das Menü „stiller“ wirkt
    try { if (masterGain) masterGain.gain.value = 0.18; } catch (e) { }
    try { playDoorCreak(); } catch (e) { }
}

function resumeGame() {
    if (!isPaused) return;
    isPaused = false;
    const menu = document.getElementById('pause-menu');
    if (menu) menu.classList.add('hidden');
    try { if (masterGain) masterGain.gain.value = 1.0; } catch (e) { }
    // Steuerung zurückholen — der Klick auf „Resume“ zählt als Nutzergeste,
    // damit der Browser das Pointer-Lock wieder erlaubt.
    _suppressAutoPause = false;
    try { canvas.requestPointerLock(); } catch (e) { }
}

function quitToMainMenu() {
    // Sauberster Weg zurück ins Hauptmenü: Seite neu laden → frischer Startbildschirm.
    isPaused = false;
    if (document.pointerLockElement) document.exitPointerLock();
    location.reload();
}

function triggerJumpscare() {
    if (gameState === 'gameover') return;
    gameState = 'gameover';
    hideGameHud();

    if (document.pointerLockElement) document.exitPointerLock();
    document.getElementById('jumpscare').classList.remove('hidden');

    playJumpscareScream();

    jumpscareFrame = 0;

    const jsCanvas = document.getElementById('jumpscareCanvas');
    if (!jsCanvas) return;
    const jCtx = jsCanvas.getContext('2d');

    // Setze die Größe nur einmalig fest, um Einfrieren zu verhindern
    jsCanvas.width = window.innerWidth;
    jsCanvas.height = window.innerHeight;
    const W = jsCanvas.width, H = jsCanvas.height;
    const TOTAL_FRAMES = 52; // ca. 0.9 Sekunden

    function animate() {
        jumpscareFrame++;
        const f = jumpscareFrame;
        const prog = Math.min(1, f / TOTAL_FRAMES);

        // Das echte Ingame-Monster stürmt beschleunigend auf die Kamera zu
        const lunge = Math.pow(prog, 2.4);
        const shake = 3 + lunge * 75;
        const shakeX = (Math.random() - 0.5) * shake;
        const shakeY = (Math.random() - 0.5) * shake;

        jCtx.setTransform(1, 0, 0, 1, 0, 0);
        jCtx.fillStyle = '#000';
        jCtx.fillRect(0, 0, W, H);

        // Modellgröße: am Ende füllt der aufgerissene Schädel den Bildschirm
        const mh = H * (1.4 + lunge * 7.5);
        const cx = W / 2 + shakeX + (noise2D(f, 3.3) - 0.5) * lunge * 50;
        // Kopf (liegt bei top + h*0.155) bleibt leicht über der Bildmitte
        const top = H * 0.42 - mh * 0.155 + shakeY;

        // Bewegungsunschärfe: Geisterbild leicht versetzt hinter dem Hauptbild
        jCtx.globalAlpha = 0.35;
        drawMonsterModel(jCtx, cx - shakeX * 1.6, top - shakeY * 1.6, mh, mh, { isChase: true, twitchScale: 2.5 });
        jCtx.globalAlpha = 1;
        drawMonsterModel(jCtx, cx, top, mh, mh, { isChase: true, twitchScale: 2.5 });

        // Hartes Gegenlicht: nur das Gesicht ist beleuchtet, die Ränder saufen ab
        const light = jCtx.createRadialGradient(
            W / 2, H * 0.42, H * (0.12 + lunge * 0.25),
            W / 2, H * 0.42, H * (0.55 + lunge * 0.4));
        light.addColorStop(0, 'rgba(0,0,0,0)');
        light.addColorStop(1, 'rgba(0,0,0,0.92)');
        jCtx.fillStyle = light;
        jCtx.fillRect(0, 0, W, H);

        // VHS-Glitch: horizontale Bildstreifen reißen zur Seite
        if (f > 6) {
            const tears = 2 + ((lunge * 6) | 0);
            for (let i = 0; i < tears; i++) {
                const ty = Math.random() * H;
                const th = 4 + Math.random() * (10 + lunge * 40);
                const off = (Math.random() - 0.5) * (20 + lunge * 120);
                jCtx.drawImage(jsCanvas, 0, ty, W, th, off, ty, W, th);
            }
        }

        // Filmkorn
        for (let i = 0; i < 220; i++) {
            jCtx.fillStyle = `rgba(255,255,255,${Math.random() * 0.08})`;
            jCtx.fillRect(Math.random() * W, Math.random() * H, 2, 2);
        }

        // Schockblitze kurz vor dem Aufprall
        if (f > TOTAL_FRAMES - 8) {
            if (f % 3 === 0) {
                jCtx.fillStyle = 'rgba(255, 245, 235, 0.85)';
                jCtx.fillRect(0, 0, W, H);
            } else if (f % 3 === 1) {
                jCtx.fillStyle = 'rgba(120, 0, 0, 0.5)';
                jCtx.fillRect(0, 0, W, H);
            }
        }

        // Rote Rand-Vignette, wird mit der Nähe intensiver
        const vig = jCtx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 0.75);
        vig.addColorStop(0, 'rgba(0,0,0,0)');
        vig.addColorStop(1, `rgba(80, 0, 0, ${0.35 + lunge * 0.4})`);
        jCtx.fillStyle = vig;
        jCtx.fillRect(0, 0, W, H);

        if (f < TOTAL_FRAMES) {
            requestAnimationFrame(animate);
        } else {
            // Harter Schnitt auf Schwarz, kurze Stille, dann der Todesbildschirm
            jCtx.setTransform(1, 0, 0, 1, 0, 0);
            jCtx.fillStyle = '#000';
            jCtx.fillRect(0, 0, W, H);
            setTimeout(() => {
                document.getElementById('jumpscare').classList.add('hidden');
                populateDeathStats();
                // Erst der kurze Tutorial-Bildschirm (Monster sichtbar), dann der Todesbildschirm
                showMonsterTutorial();
            }, 350);
        }
    }

    requestAnimationFrame(animate);
}

setTimeout(updateMessage, 100);

window.addEventListener('keydown', (e) => {
    // Tutorial nach dem Tod: beliebige Taste überspringt es
    if (tutorialActive) {
        if (Date.now() >= tutorialCanSkipAt) endTutorialShowDeath();
        return;
    }
    // ESC: Pause umschalten (im Spiel) bzw. Beenden-Dialog schließen (im Menü)
    if (e.key === 'Escape') {
        const qc = document.getElementById('quit-confirm');
        if (gameState === 'start' && qc && !qc.classList.contains('hidden')) {
            qc.classList.add('hidden');
        } else if (gameState === 'playing' && !hideState.active) {
            if (isPaused) resumeGame();
            else pauseGame();
        }
        return;
    }
    // Im Pause-Menü keine sonstigen Spiel-Tasten verarbeiten
    if (isPaused) return;
    // Menü-Navigation per Tastatur (Pfeiltasten + Enter), nur im Hauptmenü
    if (gameState === 'start') {
        // Bei offenem Beenden-Dialog keine Menü-Tasten (sonst startet Enter das Spiel)
        const qc = document.getElementById('quit-confirm');
        if (qc && !qc.classList.contains('hidden')) return;
        const startContent = document.getElementById('start-content');
        const menuVisible = startContent && !startContent.classList.contains('hidden');
        if (menuVisible) {
            if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                e.preventDefault();
                const btns = Array.from(document.querySelectorAll('.difficulty-menu .diff-btn'));
                const idx = btns.findIndex(b => b.classList.contains('active'));
                const next = (idx + (e.key === 'ArrowDown' ? 1 : -1) + btns.length) % btns.length;
                btns[next].click();
            } else if (e.key === 'Enter') {
                const sb = document.getElementById('start-btn');
                if (sb) sb.click();
            }
        }
        return; // Im Menü keine Spiel-Tasten (F/M/E) auslösen
    }
    if (e.key.toLowerCase() === 'f' && gameState === 'playing') {
        if (document.pointerLockElement === canvas) {
            _suppressAutoPause = true; // gewolltes Lösen → kein Pause-Menü
            document.exitPointerLock();
        } else {
            canvas.requestPointerLock();
        }
    }
    // Minimap Toggle mit 'M'
    if (e.key.toLowerCase() === 'm' && gameState === 'playing') {
        toggleMinimap();
    }
    // Interaktion (E) nur beim ersten Drücken auslösen, nicht bei Key-Repeat
    if (e.key.toLowerCase() === 'e' && !e.repeat) {
        interactPressed = true;
    }
    // QTE im Schrank: A / D einzeln abfangen (kein Key-Repeat)
    if (hideState.minigame && !e.repeat) {
        const k = e.key.toLowerCase();
        if (k === 'a') { e.preventDefault(); handleHideKey('A'); }
        else if (k === 'd') { e.preventDefault(); handleHideKey('D'); }
    }
    keysPressed[e.key.toLowerCase()] = true; if (e.key === 'Shift') keysPressed['shift'] = true;
});
window.addEventListener('keyup', (e) => { keysPressed[e.key.toLowerCase()] = false; if (e.key === 'Shift') keysPressed['shift'] = false; });

// Tutorial nach dem Tod: auch ein Mausklick überspringt es
window.addEventListener('mousedown', () => {
    if (tutorialActive && Date.now() >= tutorialCanSkipAt) endTutorialShowDeath();
});
document.addEventListener('mousemove', (e) => {
    // Im Schrank ist der Blick fest auf den Türspalt gerichtet — kein Umsehen/Bewegen.
    if (document.pointerLockElement === canvas && gameState === 'playing' && !hideState.active) {
        player.angle += (e.movementX || 0) * 0.004; // Erhöhte horizontale Sensitivität
        // Limit leicht angepasst für bessere Stabilität und POV-Gefühl
        player.pitch = Math.max(-0.75, Math.min(0.75, player.pitch - (e.movementY || 0) * 0.005)); // Erhöhte vertikale Sensitivität
    }
});

// Klick-Listener, um die Steuerung zu reaktivieren, falls sie verloren geht
canvas.addEventListener('click', () => {
    if (gameState === 'playing' && !isPaused && document.pointerLockElement !== canvas) {
        canvas.requestPointerLock();
    }
});

// Wird der Mauszeiger während des Spiels freigegeben (typischerweise durch ESC),
// öffnet sich das Pause-Menü — außer es war ein gewolltes Lösen (F-Taste) oder
// ein Sonderzustand (Verstecken, Tutorial, Game Over).
document.addEventListener('pointerlockchange', () => {
    if (document.pointerLockElement !== canvas) {
        if (gameState === 'playing' && !isPaused && !hideState.active &&
            !tutorialActive && !_suppressAutoPause) {
            pauseGame();
        }
        _suppressAutoPause = false;
    }
});

// Pause-Menü-Buttons
(function wirePauseMenu() {
    const resumeBtn = document.getElementById('resume-btn');
    const quitBtn = document.getElementById('quit-btn');
    if (resumeBtn) resumeBtn.addEventListener('click', resumeGame);
    if (quitBtn) quitBtn.addEventListener('click', quitToMainMenu);
})();

function castRay(ox, oy, angle, maxDist) {
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);
    let x = ox, y = oy;
    for (let i = 0; i < maxDist; i += 4) {
        x += dx * 4;
        y += dy * 4;
        const gx = Math.floor(x / TILE_SIZE);
        const gy = Math.floor(y / TILE_SIZE);
        if (gy >= 0 && gy < map.length && gx >= 0 && gx < map[0].length) {
            let t = map[gy][gx];
            let solid = (t === '1' || t === '4' || t === '5' || 'KSWB'.includes(t));
            if (t === '2') {
                const d = getDoorAt(gx, gy);
                solid = !d || d.open < 0.5; // offene Türen lassen den Strahl durch
            }
            if (solid) {
                let bx = x, by = y;
                while (Math.floor(bx / TILE_SIZE) === gx && Math.floor(by / TILE_SIZE) === gy) {
                    bx -= dx;
                    by -= dy;
                }
                return { x: bx + dx * 30, y: by + dy * 30 };
            }
        } else {
            return { x, y };
        }
    }
    return { x, y };
}

function hasLineOfSight(x1, y1, x2, y2) {
    if (!map || !map.length) return false;
    const dist = Math.hypot(x2 - x1, y2 - y1);
    const angle = Math.atan2(y2 - y1, x2 - x1);
    let x = x1, y = y1;
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);
    for (let i = 0; i < dist; i += 5) {
        x += dx * 5;
        y += dy * 5;
        const gx = Math.floor(x / TILE_SIZE);
        const gy = Math.floor(y / TILE_SIZE);
        let t = map[gy] ? map[gy][gx] : null;
        // Monster können nicht durch Wände, geschlossene Türen oder Treppenaufbauten sehen
        if (t === '2') {
            const d = getDoorAt(gx, gy);
            if (!d || d.open < 0.5) return false;
        } else if ('1UDKSWB'.includes(t)) return false;
    }
    return true;
}

// Eine Kachel ist für solide Deko (Möbel/Schränke) nur geeignet, wenn sie Boden ist
// UND keine Tür in der direkten 3x3-Nachbarschaft liegt — sonst stellt sich das
// (jetzt solide) Möbel in den Türrahmen und blockiert den Durchgang.
function tileFreeForProp(grid, tx, ty) {
    if (!grid[ty] || grid[ty][tx] !== '0') return false;
    for (let dy = -1; dy <= 1; dy++) {
        const row = grid[ty + dy];
        if (!row) continue;
        for (let dx = -1; dx <= 1; dx++) {
            if (row[tx + dx] === '2') return false;
        }
    }
    return true;
}

function handleCollision(entity) {
    const buffer = entity.radius;
    const gx = Math.floor(entity.x / TILE_SIZE);
    const gy = Math.floor(entity.y / TILE_SIZE);

    for (let y = gy - 1; y <= gy + 1; y++) {
        for (let x = gx - 1; x <= gx + 1; x++) {
            let t = map[y] ? map[y][x] : null;
            let solid = (t === '1' || t === '4' || t === '5' || 'KSWB'.includes(t));
            if (t === '2') {
                const d = getDoorAt(x, y);
                solid = !d || d.open < 0.75; // Tür erst passierbar, wenn weit genug offen
            }
            if (solid) {
                const wallX = x * TILE_SIZE;
                const wallY = y * TILE_SIZE;

                const closestX = Math.max(wallX, Math.min(entity.x, wallX + TILE_SIZE));
                const closestY = Math.max(wallY, Math.min(entity.y, wallY + TILE_SIZE));

                const distanceX = entity.x - closestX;
                const distanceY = entity.y - closestY;
                const distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);

                if (distanceSquared < buffer * buffer) {
                    const distance = Math.sqrt(distanceSquared);
                    if (distance > 0) {
                        const overlap = buffer - distance;
                        entity.x += (distanceX / distance) * overlap;
                        entity.y += (distanceY / distance) * overlap;
                    }
                }
            }
        }
    }

    // --- SOLIDE REQUISITEN: Möbel & Schränke (feste Position, kreisförmige Kollision)
    // Nur der Spieler kollidiert mit ihnen — so kann man nicht mehr durch Möbel
    // hindurchgehen oder in den Schrank hineinlaufen, das Monster bleibt aber nicht
    // an Deko hängen.
    if (entity === player) {
        const props = getCollisionProps();
        for (let i = 0; i < props.length; i++) collideBox(entity, props[i]);
    }
}

// Drängt eine Entität exakt aus einer (gedrehten) Box heraus (kürzeste Achse).
// So kann der Spieler nicht mehr in Möbel oder in den Schrank hineinlaufen.
function collideBox(entity, pr) {
    const cs = Math.cos(pr.theta), sn = Math.sin(pr.theta);
    const dx = entity.x - pr.x, dy = entity.y - pr.y;
    // In den lokalen Box-Raum drehen
    let lx = dx * cs + dy * sn;
    let ly = -dx * sn + dy * cs;
    const ex = pr.hw + entity.radius, ey = pr.hd + entity.radius;
    if (Math.abs(lx) < ex && Math.abs(ly) < ey) {
        const penX = ex - Math.abs(lx);
        const penY = ey - Math.abs(ly);
        if (penX < penY) lx += lx >= 0 ? penX : -penX;
        else ly += ly >= 0 ? penY : -penY;
        // zurück in die Welt
        entity.x = pr.x + lx * cs - ly * sn;
        entity.y = pr.y + lx * sn + ly * cs;
    }
}

// Liefert (gecacht) die soliden Requisiten der aktuellen Etage für die Kollision.
function getCollisionProps() {
    if (_collProps && _collPropsFloor === currentFloor) return _collProps;
    _collProps = [];
    for (const fu of furnitureData) if (fu.floor === currentFloor)
        _collProps.push({ x: fu.x, y: fu.y, theta: fu.angle || 0, hw: fu.collHW || 17, hd: fu.collHD || 17 });
    for (const cl of closetsData) if (cl.floor === currentFloor)
        _collProps.push({ x: cl.x, y: cl.y, theta: cl.angle || 0, hw: cl.collHW || 20, hd: cl.collHD || 14 });
    _collPropsFloor = currentFloor;
    return _collProps;
}

// ==========================================
// MONSTER-PATHFINDING (BFS auf dem Kachelgitter)
// Damit das Monster intelligent UM Wände herum navigiert, statt blind
// dagegen zu laufen. Die Puffer werden wiederverwendet (kein GC-Druck),
// ein "Token" markiert besuchte Kacheln ohne sie jedes Mal zu löschen.
// ==========================================
const bfsStamp = new Int32Array(MAP_WIDTH * MAP_HEIGHT);
const bfsPrev = new Int32Array(MAP_WIDTH * MAP_HEIGHT);
const bfsQueue = new Int32Array(MAP_WIDTH * MAP_HEIGHT);
let bfsToken = 0;

function tileWalkableForEnemy(grid, x, y) {
    if (x < 0 || y < 0 || x >= MAP_WIDTH || y >= MAP_HEIGHT) return false;
    const t = grid[y][x];
    // Türen sind begehbar (das Monster öffnet sie), Treppen/Exit ebenfalls
    return t === '0' || t === '2' || t === 'U' || t === 'D' || t === 'E';
}

// Liefert die NÄCHSTE Kachel auf dem kürzesten Weg von (sx,sy) nach (gx,gy)
// oder null, wenn kein Weg gefunden wird.
function findNextStep(grid, sx, sy, gx, gy, maxNodes = 1600) {
    if (!grid || (sx === gx && sy === gy)) return null;

    // Liegt das Ziel auf einer Wand? Dann die nächste begehbare Nachbarkachel nehmen.
    if (!tileWalkableForEnemy(grid, gx, gy)) {
        let found = false;
        const around = [[1, 0], [-1, 0], [0, 1], [0, -1]];
        for (let n = 0; n < 4; n++) {
            if (tileWalkableForEnemy(grid, gx + around[n][0], gy + around[n][1])) {
                gx += around[n][0]; gy += around[n][1]; found = true; break;
            }
        }
        if (!found) return null;
    }

    bfsToken++;
    const W = MAP_WIDTH;
    const startIdx = sy * W + sx;
    const goalIdx = gy * W + gx;
    let head = 0, tail = 0, nodes = 0;
    bfsQueue[tail++] = startIdx;
    bfsStamp[startIdx] = bfsToken;
    bfsPrev[startIdx] = -1;
    let reached = false;

    const neigh = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    while (head < tail && nodes < maxNodes) {
        const cur = bfsQueue[head++];
        nodes++;
        if (cur === goalIdx) { reached = true; break; }
        const cy = (cur / W) | 0, cx = cur % W;
        for (let n = 0; n < 4; n++) {
            const nx = cx + neigh[n][0], ny = cy + neigh[n][1];
            if (nx < 0 || ny < 0 || nx >= MAP_WIDTH || ny >= MAP_HEIGHT) continue;
            const ni = ny * W + nx;
            if (bfsStamp[ni] === bfsToken) continue;
            if (!tileWalkableForEnemy(grid, nx, ny)) continue;
            bfsStamp[ni] = bfsToken;
            bfsPrev[ni] = cur;
            bfsQueue[tail++] = ni;
        }
    }
    if (!reached) return null;

    // Pfad zurückverfolgen bis zum ersten Schritt ab dem Start
    let node = goalIdx;
    let prev = bfsPrev[node];
    while (prev !== -1 && prev !== startIdx) {
        node = prev;
        prev = bfsPrev[node];
    }
    return { x: node % W, y: (node / W) | 0 };
}

// Lenkt einen Gegner per Pfadsuche zur Zielkachel (tgx,tgy). Der Pfad wird nur
// alle paar Frames neu berechnet (Performance, schont schwache Geräte).
function steerEnemyTo(e, grid, tgx, tgy, speed) {
    const egx = Math.floor(e.x / TILE_SIZE), egy = Math.floor(e.y / TILE_SIZE);
    if (e.pathTimer === undefined) e.pathTimer = 0;

    if (e.pathTimer <= 0 || e.pathGoalX !== tgx || e.pathGoalY !== tgy) {
        const step = findNextStep(grid, egx, egy, tgx, tgy);
        e.stepX = step ? step.x : -1;
        e.stepY = step ? step.y : -1;
        e.pathGoalX = tgx; e.pathGoalY = tgy;
        e.pathTimer = 12; // alle 12 Frames neu berechnen
    }
    e.pathTimer--;

    let aimX, aimY;
    if (e.stepX >= 0) {
        aimX = e.stepX * TILE_SIZE + TILE_SIZE / 2;
        aimY = e.stepY * TILE_SIZE + TILE_SIZE / 2;
    } else {
        // Kein Pfad gefunden: grob in Zielrichtung tasten
        aimX = tgx * TILE_SIZE + TILE_SIZE / 2;
        aimY = tgy * TILE_SIZE + TILE_SIZE / 2;
    }

    const ang = Math.atan2(aimY - e.y, aimX - e.x);
    e.wanderAngle = ang;
    e.x += Math.cos(ang) * speed;
    e.y += Math.sin(ang) * speed;
    handleCollision(e);
}

function checkStairs() {
    // Laufende Treppen-Animation: klettert automatisch weiter (einmal E drücken genügt)
    if (stairAnim.active) {
        player.z += 1.5 * stairAnim.dir;
        fadeAlpha = Math.min(1, Math.abs(player.z) / (TILE_SIZE * 0.8));
        player.pitch = stairAnim.dir > 0 ? -0.1 : 0.1;

        // Schwere Schritte auf den Stufen
        stairAnim.stepTimer--;
        if (stairAnim.stepTimer <= 0) {
            playStairStep();
            stairAnim.stepTimer = 14;
        }

        if (Math.abs(player.z) >= TILE_SIZE) {
            // Etagenwechsel
            currentFloor += stairAnim.dir;
            map = maps[currentFloor];
            spawnAtTile(stairAnim.dir > 0 ? 'D' : 'U');
            player.z = 0;
            player.pitch = 0;
            stairAnim.active = false;
            showFloorPopup(currentFloor);
        }
        return;
    }

    const gx = Math.floor(player.x / TILE_SIZE);
    const gy = Math.floor(player.y / TILE_SIZE);
    const tile = (maps[currentFloor] && maps[currentFloor][gy]) ? maps[currentFloor][gy][gx] : null;

    if ((tile === 'U' || tile === 'D') && stairsCooldown === 0 && interactPressed) {
        let dir = 0;
        if (tile === 'U' && currentFloor < maps.length - 1) dir = 1;
        else if (tile === 'D' && currentFloor > 0) dir = -1;

        if (dir !== 0) {
            interactPressed = false; // Tastendruck konsumieren (öffnet nicht nebenbei eine Tür)
            player.x = gx * TILE_SIZE + TILE_SIZE / 2;
            player.y = gy * TILE_SIZE + TILE_SIZE / 2;
            stairAnim.active = true;
            stairAnim.dir = dir;
            stairAnim.stepTimer = 0;
        }
    } else {
        // Sanftes Zurücksetzen der Z-Position, wenn nicht auf Treppe
        player.z *= 0.8;
        fadeAlpha *= 0.8;
        if (Math.abs(player.z) < 0.1) player.z = 0;
    }
}

function spawnAtTile(targetTile) {
    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] === targetTile) {
                player.x = x * TILE_SIZE + TILE_SIZE / 2;
                player.y = y * TILE_SIZE + TILE_SIZE / 2;
                stairsCooldown = 60;
                return;
            }
        }
    }
    // Fallback: Sollte die Ziel-Treppe fehlen, auf der ersten freien Bodenkachel
    // spawnen, damit der Spieler niemals im Nichts oder in einer Wand landet
    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] === '0') {
                player.x = x * TILE_SIZE + TILE_SIZE / 2;
                player.y = y * TILE_SIZE + TILE_SIZE / 2;
                stairsCooldown = 60;
                return;
            }
        }
    }
}

// ==========================================
// VERSTECKEN IM SCHRANK + QTE-MINISPIEL
// ==========================================
function enterCloset(cl) {
    hideState.active = true;
    hideState.closet = cl;
    hideState.savedX = player.x; hideState.savedY = player.y;
    // In den Schrank setzen und nach außen (in den Raum) blicken
    player.x = cl.x; player.y = cl.y;
    player.angle = 0; // nach Osten → in den Raum (Schrank steht an der Westwand)
    player.pitch = 0;
    player.isHiding = true;
    hideState.minigame = false;
    hideState.strikes = 0; hideState.successes = 0;
    hideState.hideTimer = 0; hideState.panic = 0; hideState.beat = 0; hideState.beatPhase = 0;
    playDoorCreak();
}

function exitCloset() {
    hideState.active = false; hideState.minigame = false; hideState.closet = null;
    player.isHiding = false;
    hideState.hideTimer = 0; hideState.panic = 0; hideState.beat = 0;
    // einen Schritt in den Raum treten
    player.x += Math.cos(player.angle) * TILE_SIZE * 0.5;
    player.y += Math.sin(player.angle) * TILE_SIZE * 0.5;
    handleCollision(player);
    playDoorCreak();
}

function startHideRound() {
    hideState.key = Math.random() < 0.5 ? 'A' : 'D';
    hideState.marker = Math.random() * 0.3;
    hideState.markerDir = 1;
    hideState.markerSpeed = 0.016 + hideState.successes * 0.0028; // wird mit jedem Erfolg schneller
    hideState.roundTimer = 200; // ~3.3 s Zeit pro Runde
}

function hideHit() {
    hideState.successes++;
    hideState.flashTimer = 16; hideState.flashGood = true;
    if (hideState.successes >= 5) endHideMinigameSuccess();
    else startHideRound();
}

function hideMiss() {
    hideState.strikes++;
    hideState.flashTimer = 16; hideState.flashGood = false;
    playMonsterGrowl(0.7);
    if (hideState.strikes >= 3) {
        hideState.active = false; hideState.minigame = false;
        player.isHiding = false;
        triggerJumpscare(); // 3x daneben → erwischt
    } else {
        startHideRound();
    }
}

// Sucht eine begehbare Bodenkachel, die möglichst weit vom Spieler entfernt ist.
// Liefert Weltkoordinaten (Kachelmitte) oder null, falls nichts gefunden wird.
function findFarFloorTile(minDist) {
    if (typeof map === 'undefined' || !map || !map.length) return null;
    let best = null, bestDist = -1;
    const candidates = [];
    for (let y = 0; y < map.length; y++) {
        for (let x = 0; x < map[y].length; x++) {
            if (map[y][x] !== '0') continue;
            const wx = x * TILE_SIZE + TILE_SIZE / 2;
            const wy = y * TILE_SIZE + TILE_SIZE / 2;
            const d = Math.hypot(wx - player.x, wy - player.y);
            if (d >= minDist) candidates.push({ wx, wy, d });
            if (d > bestDist) { bestDist = d; best = { wx, wy, d }; }
        }
    }
    // Aus allen weit genug entfernten Kacheln eine zufällige wählen (Abwechslung),
    // sonst die absolut entfernteste als Fallback.
    if (candidates.length) return candidates[Math.floor(Math.random() * candidates.length)];
    return best;
}

function endHideMinigameSuccess() {
    hideState.minigame = false;
    // Begegnung überlebt → frisches Zeitfenster zum Rauskommen (Panik-Uhr zurücksetzen)
    hideState.hideTimer = 0; hideState.panic = 0; hideState.beat = 0;
    // Alle jagenden Monster verlieren die Spur, verschwinden vom Schrank
    // und tauchen ganz woanders auf der Etage wieder auf (Despawn → Respawn).
    enemiesData.forEach(e => {
        if (e.floor === currentFloor && (e.state === 'chase' || e.state === 'search' || e.hunting)) {
            const spot = findFarFloorTile(TILE_SIZE * 12);
            if (spot) {
                e.x = spot.wx; e.y = spot.wy;
                e.lastKnownX = spot.wx; e.lastKnownY = spot.wy;
            } else {
                // Fallback: einfach vom Spieler wegziehen
                const ang = Math.atan2(e.y - player.y, e.x - player.x);
                e.lastKnownX = e.x + Math.cos(ang) * 700;
                e.lastKnownY = e.y + Math.sin(ang) * 700;
            }
            e.state = 'patrol';
            e.chaseTime = 0;
            e.hunting = false; e.huntTimer = 600;
            e.wanderAngle = Math.random() * Math.PI * 2;
            e.targetX = e.lastKnownX; e.targetY = e.lastKnownY;
        }
    });
    playMonsterGrowl(0.3); // entfernt verklingendes Knurren → Monster ist weg
}

function handleHideKey(key) {
    if (!hideState.minigame) return;
    const inZone = hideState.marker > 0.40 && hideState.marker < 0.60;
    if (key === hideState.key && inZone) hideHit();
    else hideMiss();
}

function updateHideMinigame() {
    // Jagt ein Monster in der Nähe? → QTE starten
    let hunting = false;
    for (const e of enemiesData) {
        if (e.floor !== currentFloor) continue;
        if (e.state === 'chase' || e.state === 'search' || e.hunting) {
            if (Math.hypot(player.x - e.x, player.y - e.y) < TILE_SIZE * 9) { hunting = true; break; }
        }
    }
    if (hunting && !hideState.minigame) {
        hideState.minigame = true;
        hideState.strikes = 0; hideState.successes = 0;
        startHideRound();
        playMonsterGrowl(0.85);
    }
    if (!hideState.minigame) return;

    // Das jagende Monster weiter zum Schrank locken → bleibt durch den Spalt sichtbar
    for (const e of enemiesData) {
        if (e.floor === currentFloor && (e.state === 'search' || e.state === 'chase')) {
            e.lastKnownX = player.x; e.lastKnownY = player.y;
        }
    }

    // Laufbalken bewegen
    hideState.marker += hideState.markerDir * hideState.markerSpeed;
    if (hideState.marker > 1) { hideState.marker = 1; hideState.markerDir = -1; }
    else if (hideState.marker < 0) { hideState.marker = 0; hideState.markerDir = 1; }

    if (hideState.flashTimer > 0) hideState.flashTimer--;

    hideState.roundTimer--;
    if (hideState.roundTimer <= 0) hideMiss(); // zu langsam = Fehler
}

function update() {
    if (gameState !== 'playing') return;
    if (isPaused) return; // Simulation eingefroren — das Standbild bleibt stehen

    // --- EXPLORATION TRACKING ---
    updateExploration();
    // --- TASCHENLAMPEN-FLACKERN ---
    if (!window._flashlightFlicker) window._flashlightFlicker = 1.0;
    if (!window._blackoutTimer) window._blackoutTimer = 0;

    if (window._blackoutTimer > 0) {
        // Seltener Total-Ausfall der Taschenlampe: fast völlige Dunkelheit
        window._blackoutTimer--;
        window._flashlightFlicker = 0.08 + Math.random() * 0.1;
    } else if (Math.random() < 0.0006) {
        window._blackoutTimer = 25 + Math.floor(Math.random() * 50);
    } else if (Math.random() < 0.03) {
        window._flashlightFlicker = 0.7 + Math.random() * 0.2; // kurzer Einbruch
    } else {
        window._flashlightFlicker += (1.0 - window._flashlightFlicker) * 0.15; // sanft zurück zu 1.0
    }
    window._flashlightFlicker = Math.min(1.0, window._flashlightFlicker + (Math.random() - 0.5) * 0.02);

    // --- DONNER & BLITZ SYSTEM ---
    if (thunderState.timer > 0) {
        thunderState.timer--;
        thunderState.intensity *= 0.88; // Schneller Abfall des Blitzes
    } else {
        thunderState.active = false;
        thunderState.intensity = 0;
    }
    thunderState.nextThunder--;
    if (thunderState.nextThunder <= 0) {
        thunderState.active = true;
        thunderState.intensity = 0.6 + Math.random() * 0.4;
        thunderState.timer = 8 + Math.floor(Math.random() * 12); // 8-20 Frames
        thunderState.nextThunder = 400 + Math.floor(Math.random() * 1200); // 7-27 Sekunden bis zum nächsten
        playThunderSound();
    }

    // --- RANDOM AMBIENT STINGS ---
    stingTimer--;
    if (stingTimer <= 0) {
        playScarySting();
        stingTimer = 600 + Math.random() * 1800; // Alle 10-40 Sekunden
    }

    // Blutspritzer altern, verblassen und entfernen
    for (let i = bloodSplattersData.length - 1; i >= 0; i--) {
        let b = bloodSplattersData[i];
        b.timer--;
        if (b.timer < 150) b.opacity = b.timer / 150;
        if (b.timer <= 0) bloodSplattersData.splice(i, 1);
    }

    // Update jumpscare effect
    if (jumpscareEffect.active) {
        jumpscareEffect.timer--;

        const progress = 1 - (jumpscareEffect.timer / jumpscareEffect.maxTimer); // 0 to 1
        // Use sine wave to smoothly ramp up and down
        const effectPhase = Math.sin(progress * Math.PI); // Peaks at 0.5, goes from 0 to 1 to 0

        // Red intensity in and then out (max 0.6 opacity)
        jumpscareEffect.currentRedIntensity = 0.6 * effectPhase;

        if (jumpscareEffect.timer <= 0) {
            jumpscareEffect.active = false;
            jumpscareEffect.currentRedIntensity = 0;
        }
    }

    const DOOR_OPEN_TIME = 180; // 3 Sekunden bei 60 FPS
    const DOOR_INTERACTION_DISTANCE = TILE_SIZE * 1.5; // Spieler muss innerhalb von 1.5 Kacheln sein

    let interactionPromptMessage = null; // Speichert die Nachricht für den Interaktions-Prompt
    let currentFloorDoors = doorsData.filter(d => d.floor === currentFloor);

    // --- 1. TREPPEN-CHECK (Priorität vor Türen) ---
    const pgx = Math.floor(player.x / TILE_SIZE);
    const pgy = Math.floor(player.y / TILE_SIZE);
    const currentTile = (map[pgy] && map[pgy][pgx]) ? map[pgy][pgx] : null;
    const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];

    if ((currentTile === 'U' || currentTile === 'D') && stairsCooldown === 0 && !stairAnim.active) {
        if (currentTile === 'U') {
            let nextFloorName = currentFloor + 1 === maps.length - 1 ? "Attic" : (currentFloor + 1) + ". Floor";
            interactionPromptMessage = `press E: Climb to ${nextFloorName}`;
        } else {
            let nextFloorName = currentFloor - 1 === 0 ? "Ground Floor" : (currentFloor - 1) + ". Floor";
            interactionPromptMessage = `press E: Descend to ${nextFloorName}`;
        }
    }
    checkStairs();

    if (stairsCooldown > 0) stairsCooldown--; // Keep only one decrement per frame

    // --- 2. TÜR-INTERAKTION ---
    // Tür-Interaktion und -Zustand verwalten
    currentFloorDoors.forEach(door => {
        const doorCenterX = door.x * TILE_SIZE + TILE_SIZE / 2;
        const doorCenterY = door.y * TILE_SIZE + TILE_SIZE / 2;
        const distToDoor = Math.hypot(player.x - doorCenterX, player.y - doorCenterY);

        // Performance-Optimierung: Nur berechnen, wenn der Spieler oder ein Gegner in der Nähe ist
        if (distToDoor > TILE_SIZE * 5 && door.state === 'closed') return;

        // Prüfen, ob jemand in der Tür steht (Spieler oder Monster)
        const isBlocked = distToDoor < TILE_SIZE * 0.6 ||
            enemiesData.some(e => e.floor === door.floor &&
                Math.hypot(e.x - doorCenterX, e.y - doorCenterY) < TILE_SIZE * 0.6);

        // --- TÜR-ANIMATION (Schiebetür): open läuft weich zwischen 0 und 1 ---
        if (door.state === 'opening') {
            door.open = Math.min(1, door.open + 0.05);
            if (door.open >= 1) {
                door.state = 'open';
                door.timer = DOOR_OPEN_TIME;
            }
        } else if (door.state === 'closing') {
            if (isBlocked) {
                door.state = 'opening'; // jemand steht in der Tür: wieder öffnen
            } else {
                door.open = Math.max(0, door.open - 0.035);
                if (door.open <= 0) door.state = 'closed';
            }
        } else if (door.state === 'open') {
            if (door.timer > 0) {
                door.timer--;
            } else if (!isBlocked) { // Tür schließt nur, wenn niemand darin steht
                door.state = 'closing';
                playDoorCreak();
            }
        }

        if ((door.state === 'closed' || door.state === 'closing') && distToDoor < DOOR_INTERACTION_DISTANCE) {
            let angleToDoor = Math.atan2(doorCenterY - player.y, doorCenterX - player.x);
            let angleDiff = Math.abs(Math.atan2(Math.sin(angleToDoor - player.angle), Math.cos(angleToDoor - player.angle)));
            if (angleDiff < Math.PI / 4) { // Prüfen ob Spieler die Tür ansieht (innerhalb von 45 Grad)
                interactionPromptMessage = "press E to open";
                if (interactPressed && !stairAnim.active && !hideState.active) { // Manuelles Öffnen mit E (Einzeldruck)
                    door.state = 'opening';
                    interactPressed = false;
                    playDoorCreak();
                }
            }
        }
    });

    // --- 2b. SCHRANK-INTERAKTION (Verstecken) ---
    if (!hideState.active) {
        let nearCloset = null, nearDist = TILE_SIZE * 1.4;
        for (const cl of closetsData) {
            if (cl.floor !== currentFloor) continue;
            const d = Math.hypot(player.x - cl.x, player.y - cl.y);
            if (d < nearDist) { nearDist = d; nearCloset = cl; }
        }
        if (nearCloset) {
            interactionPromptMessage = "press E to hide";
            if (interactPressed) { interactPressed = false; enterCloset(nearCloset); }
        }
    } else {
        if (!hideState.minigame) {
            interactionPromptMessage = "press E to leave the closet";
            if (interactPressed) { interactPressed = false; exitCloset(); }
        } else {
            interactionPromptMessage = `Press ${hideState.key} at the right moment!`;
        }
        updateHideMinigame();
    }

    // --- 3. PICKUP & EXIT ---
    updatePickupsAndExit();

    // --- 4. BEWEGUNG & KOLLISION ---

    // EMF-Reader Logik (Gefahrenmeter)
    let minEnemyDist = Infinity;
    enemiesData.forEach(e => {
        if (e.floor === currentFloor) {
            let d = Math.hypot(player.x - e.x, player.y - e.y);
            if (d < minEnemyDist) minEnemyDist = d;
        }
    });

    const emfSegments = document.getElementsByClassName('emf-segment');
    if (emfSegments.length > 0) { // EMF-Reader Logik (Gefahrenmeter)
        let emfIntensity = 0;
        if (minEnemyDist < 1000) { // Erkennungsradius 1000 Einheiten
            emfIntensity = 1 - Math.max(0, (minEnemyDist - 150) / 850);
            emfIntensity = Math.min(1, emfIntensity);
        }

        let activeSegments = Math.ceil(emfIntensity * 5);
        const colors = ['#00ff00', '#00ff00', '#ffff00', '#ffff00', '#ff0000'];
        for (let i = 0; i < 5; i++) {
            if (i < activeSegments) {
                emfSegments[i].style.backgroundColor = colors[i];
                emfSegments[i].style.boxShadow = `0 0 10px ${colors[i]}`;
            } else {
                emfSegments[i].style.backgroundColor = '#111';
                emfSegments[i].style.boxShadow = 'none';
            }
        }
    }

    // --- HERZSCHLAG bei Monsternähe (schneller, je näher es kommt) ---
    if (!window._heartbeatTimer) window._heartbeatTimer = 0;
    window._heartbeatTimer--;
    if (minEnemyDist < 400 && window._heartbeatTimer <= 0) {
        const proximity = 1 - minEnemyDist / 400;
        playHeartbeat(proximity);
        window._heartbeatTimer = 25 + (1 - proximity) * 50;
    }

    // Interaktions-Hinweis am unteren Bildschirmrand anzeigen
    const promptEl = document.getElementById('interaction-prompt');
    if (promptEl && interactionPromptMessage) {
        promptEl.textContent = interactionPromptMessage;
        promptEl.classList.remove('hidden');
    } else if (promptEl) {
        promptEl.classList.add('hidden');
    }

    let speed = player.speed;
    let isMoving = keysPressed['w'] || keysPressed['a'] || keysPressed['s'] || keysPressed['d'];

    // Stamina-Logik: Verhindert "Stottern" bei leerer Ausdauer
    if (keysPressed['shift'] && isMoving && player.stamina > 0 && !player.isExhausted) {
        speed = player.runSpeed;
        player.stamina = Math.max(0, player.stamina - 0.8);
        player.footstepTimer -= 2.5;
        if (player.stamina <= 0) player.isExhausted = true;
    } else {
        player.stamina = Math.min(player.maxStamina, player.stamina + 0.4);
        if (isMoving) player.footstepTimer -= 1.5;
        if (player.stamina >= player.maxStamina) player.isExhausted = false; // Erst wieder rennen, wenn voll regeneriert
    }

    if (isMoving && player.footstepTimer <= 0) {
        playFootstepSound();
        player.footstepTimer = 25;
    }

    const staminaBarFill = document.getElementById('stamina-bar-fill');
    const staminaText = document.getElementById('stamina-percentage-text');

    if (staminaBarFill) {
        let staminaPercent = (player.stamina / player.maxStamina * 100);
        staminaBarFill.style.width = staminaPercent + '%';

        if (staminaText) {
            staminaText.textContent = `Stamina: ${Math.round(staminaPercent)}%`;
        }

        if (player.isExhausted) {
            staminaBarFill.style.backgroundColor = '#ff0000'; // Rot bei Erschöpfung
            staminaBarFill.style.boxShadow = '0 0 15px #ff0000';
            staminaBarFill.style.animation = 'pulseRed 1s infinite alternate';

            // Schweres Keuchen, solange man erschöpft ist
            window._breathTimer = (window._breathTimer || 0) - 1;
            if (window._breathTimer <= 0) {
                playExhaustedBreath();
                window._breathTimer = 45;
            }
        } else {
            staminaBarFill.style.animation = 'none';
            if (staminaPercent > 70) {
                staminaBarFill.style.backgroundColor = '#ffffff'; // Voll
            } else if (staminaPercent > 30) {
                staminaBarFill.style.backgroundColor = '#ffff00'; // Mittel
            } else {
                staminaBarFill.style.backgroundColor = '#ffa500'; // Niedrig
            }
            staminaBarFill.style.boxShadow = '0 0 5px ' + staminaBarFill.style.backgroundColor;
        }
    }

    // Only allow horizontal movement if not actively climbing/descending stairs
    // A small threshold for player.z is used to allow slight z-movement without blocking horizontal movement
    if (hideState.active) {
        // Im Schrank bewegt man sich nicht — A/D steuern stattdessen das Minispiel
    } else if (Math.abs(player.z) < 1 && !stairAnim.active) {
        let moveX = 0; let moveY = 0;
        if (keysPressed['w']) { moveX += Math.cos(player.angle) * speed; moveY += Math.sin(player.angle) * speed; }
        if (keysPressed['s']) { moveX -= Math.cos(player.angle) * speed; moveY -= Math.sin(player.angle) * speed; }
        if (keysPressed['a']) { moveX += Math.cos(player.angle - Math.PI / 2) * speed; moveY += Math.sin(player.angle - Math.PI / 2) * speed; }
        if (keysPressed['d']) { moveX += Math.cos(player.angle + Math.PI / 2) * speed; moveY += Math.sin(player.angle + Math.PI / 2) * speed; }

        if (moveX !== 0 || moveY !== 0) { // Check if there's any movement
            const length = Math.sqrt(moveX * moveX + moveY * moveY);
            moveX = (moveX / length) * speed;
            moveY = (moveY / length) * speed;
        }

        player.x += moveX;
        player.y += moveY;
        handleCollision(player);
    } else {
        // If climbing, still handle collision for the current stair tile to prevent going through walls
        handleCollision(player);
    }

    // Schlüssel-Pickup und Exit-Check passieren zentral in updatePickupsAndExit()

    enemiesData.forEach(e => {
        const settings = DIFFICULTY_SETTINGS[currentDifficulty];
        if (e.floor !== currentFloor) return;

        // Wenn das Monster aktiv ist, hinterlässt es Spuren
        if (e.state === 'chase' || e.state === 'search') {
            spawnBloodSplatterNear(e);
        }

        // Gegner öffnet Türen jetzt über das neue doorsData System
        const egx = Math.floor(e.x / TILE_SIZE);
        const egy = Math.floor(e.y / TILE_SIZE);

        for (let i = 0; i < currentFloorDoors.length; i++) {
            let door = currentFloorDoors[i];
            if ((door.state === 'closed' || door.state === 'closing') && Math.abs(door.x - egx) <= 1 && Math.abs(door.y - egy) <= 1) {
                door.state = 'opening';
                door.timer = 180;
                // Unheimlich: man hört das Monster irgendwo eine Tür aufschieben
                if (door.floor === currentFloor) playDoorCreak();
            }
        }

        const distToPlayer = Math.hypot(player.x - e.x, player.y - e.y);

        // --- ENTFERNTES KNURREN: Man hört das Monster leise durch das Haus ---
        // Lautstärke nach Distanz, Stereo-Panning nach Richtung, Tiefpass dämpft Ferne
        if (e.idleSoundTimer === undefined) e.idleSoundTimer = 300 + Math.random() * 600;
        e.idleSoundTimer--;
        if (e.idleSoundTimer <= 0) {
            if (e.state !== 'chase' && distToPlayer < 1600) {
                const closeness = 1 - distToPlayer / 1600;
                const relAngle = Math.atan2(e.y - player.y, e.x - player.x) - player.angle;
                playMonsterGrowl(0.06 + Math.pow(closeness, 1.5) * 0.45, {
                    pan: Math.sin(relAngle),
                    lowpass: 500 + closeness * 2500,
                    wet: 0.85 // viel Hall: klingt weit weg im Gebäude
                });
            }
            e.idleSoundTimer = 360 + Math.random() * 540; // alle 6-15 Sekunden
        }

        // Im Schrank versteckt → das Monster kann den Spieler nicht sehen (nur das QTE zählt)
        let canSee = !hideState.active && hasLineOfSight(e.x, e.y, player.x, player.y);

        // Sicherheitscheck für atan2 (vermeidet NaN bei identischer Position)
        let angleToPlayer = distToPlayer > 0.1 ? Math.atan2(player.y - e.y, player.x - e.x) : e.wanderAngle;
        let angleDiff = Math.abs(Math.atan2(Math.sin(e.wanderAngle - angleToPlayer), Math.cos(e.wanderAngle - angleToPlayer)));

        let inFOV = (angleDiff < Math.PI / 2.2);
        if (e.state === 'chase') inFOV = true;

        if (canSee && (distToPlayer < 100 || (distToPlayer < settings.visionRange && inFOV))) {
            e.state = 'chase';
            if (!jumpscareEffect.active) { // Trigger effect only if not already active
                jumpscareEffect.active = true;
                jumpscareEffect.timer = 90; // 1.5 seconds
                jumpscareEffect.maxTimer = 90;

                // Das Monster hat dich entdeckt: lautes Knurren
                playMonsterGrowl(1.0);
            }
            e.lastKnownX = player.x;
            e.lastKnownY = player.y;
        } else if (e.state === 'chase') {
            // Bei niedriger Intelligenz (Leicht) vergisst das Monster sofort
            if (settings.intelligence > 0) {
                e.state = 'search';
            } else {
                e.state = 'patrol';
            }
        } else if (e.state === 'search' && distToPlayer > settings.searchDist) {
            e.state = 'patrol';
        }

        let currentBaseSpeed = e.baseSpeed + (player.keys * 0.2);

        if (e.state === 'chase') {
            e.wanderAngle = angleToPlayer;
            e.chaseTime += 1 / 60;
            // Beschleunigung begrenzt: Das Monster wird schneller, aber nur bis zu einem fairen Maximum
            let activeSpeed = Math.min(currentBaseSpeed + (e.chaseTime * 0.3), currentBaseSpeed + 2);

            // Jagd-Sound Logik: Intervalle verkürzen sich, wenn das Monster näher kommt
            e.chaseSoundTimer--;
            if (e.chaseSoundTimer <= 0) {
                e.chaseSoundTimer = 20 + Math.floor(distToPlayer / 20); // Schneller bei Annäherung
                const chaseRelAngle = Math.atan2(e.y - player.y, e.x - player.x) - player.angle;
                playMonsterGrowl(Math.max(0.2, 1 - distToPlayer / 800), { pan: Math.sin(chaseRelAngle) });
            }

            e.x += Math.cos(angleToPlayer) * activeSpeed;
            e.y += Math.sin(angleToPlayer) * activeSpeed;

            if (distToPlayer < player.radius + e.radius && !hideState.active) {
                triggerJumpscare();
            }
            handleCollision(e);
        } else if (e.state === 'search') {
            e.chaseTime = 0; // Beschleunigung zurücksetzen
            let distToLastKnown = Math.hypot(e.lastKnownX - e.x, e.lastKnownY - e.y);

            if (distToLastKnown > TILE_SIZE * 0.6) {
                // Per Pfadsuche zum letzten bekannten Ort — navigiert UM Wände herum
                const tgx = Math.floor(e.lastKnownX / TILE_SIZE);
                const tgy = Math.floor(e.lastKnownY / TILE_SIZE);
                steerEnemyTo(e, map, tgx, tgy, currentBaseSpeed);
            } else {
                // Am Ziel angekommen und nichts gefunden? Zurück zum Patrouillieren
                e.state = 'patrol';
            }
        } else {
            e.chaseTime = 0;

            // STALKING: Je intelligenter, desto öfter pirscht sich das Monster
            // GEZIELT (per Pfadsuche) an den Spieler heran statt nur zu wandern.
            e.huntTimer = (e.huntTimer || 0) - 1;
            if (e.huntTimer <= 0) {
                const stalkChance = 0.2 + settings.intelligence * 0.2;
                e.hunting = settings.intelligence > 0
                    && !hideState.active // versteckte Spieler werden nicht angepirscht
                    && distToPlayer < settings.searchDist * 1.5
                    && Math.random() < stalkChance;
                e.huntTimer = 90 + Math.random() * 120; // alle 1.5–3.5 s neu entscheiden
            }

            if (e.hunting) {
                // Lautlos heranpirschen: langsamer als die offene Jagd
                const tgx = Math.floor(player.x / TILE_SIZE);
                const tgy = Math.floor(player.y / TILE_SIZE);
                steerEnemyTo(e, map, tgx, tgy, currentBaseSpeed * 0.65);
            } else {
                // Klassisches Umherwandern
                if (Math.random() < 0.02) e.wanderAngle += (Math.random() - 0.5);

                let moveSpeed = currentBaseSpeed * 0.4;
                let prevX = e.x, prevY = e.y;
                e.x += Math.cos(e.wanderAngle) * moveSpeed;
                e.y += Math.sin(e.wanderAngle) * moveSpeed;
                handleCollision(e);

                // Festgefahren? Neue Richtung suchen
                if (Math.hypot(e.x - prevX, e.y - prevY) < moveSpeed * 0.5) {
                    e.wanderAngle += Math.PI / 2 + (Math.random() * Math.PI / 2);
                }
            }
        }
    });

    // --- VERSTECK: Blick fest auf den Türspalt; während des QTE steht das jagende
    //     Monster direkt vor der Schranktür (im Spalt sichtbar); bei zu langem
    //     Verstecken pocht der Herzschlag, das Bild wird rot und das Monster holt dich.
    //     Läuft am ENDE von update(), nachdem die Gegner-KI ihre Züge gemacht hat.
    if (hideState.active && hideState.closet) {
        player.angle = 0; player.pitch = 0; // Tür zeigt nach Osten → Blick nach Osten
        if (hideState.minigame) {
            const cl = hideState.closet;
            let mon = null, best = Infinity;
            for (const e of enemiesData) {
                if (e.floor !== currentFloor) continue;
                const d = Math.hypot(e.x - cl.x, e.y - cl.y);
                if (d < best) { best = d; mon = e; }
            }
            if (mon) {
                mon.x = cl.x + TILE_SIZE * 1.25; // direkt vor der Tür (im Raum)
                mon.y = cl.y;
                mon.angle = Math.PI;             // starrt zum Schrank/Spieler herein
                mon.state = 'search';
            }
            // Während des QTE läuft die Panik-Uhr nicht — das QTE ist die Bedrohung
            hideState.panic = Math.max(0, hideState.panic - 0.02);
            hideState.beat = 0;
        } else {
            // ZU LANGE VERSTECKT: Herzschlag pocht, das Bild wird rot, dann holt
            // dich das Monster aus dem Schrank.
            const SAFE = 240;   // ~4 s ruhig
            const DEATH = 750;  // danach reißt das Monster die Tür auf
            hideState.hideTimer++;
            hideState.panic = Math.max(0, Math.min(1, (hideState.hideTimer - SAFE) / (DEATH - SAFE)));

            if (hideState.panic > 0.02) {
                const bps = 0.9 + hideState.panic * 1.6;            // Schläge pro Sekunde
                hideState.beatPhase += bps / 60;
                if (hideState.beatPhase >= 1) {
                    hideState.beatPhase -= 1;
                    playHeartbeat(hideState.panic);                 // Lub-Dub-Sound
                }
                const ph = hideState.beatPhase;
                hideState.beat = Math.exp(-Math.pow(ph / 0.08, 2)) + 0.55 * Math.exp(-Math.pow((ph - 0.17) / 0.08, 2));
            } else {
                hideState.beat = 0;
            }

            if (hideState.hideTimer >= DEATH) {
                hideState.active = false; hideState.minigame = false;
                player.isHiding = false;
                hideState.panic = 0; hideState.beat = 0; hideState.hideTimer = 0;
                playMonsterGrowl(0.9);
                triggerJumpscare(); // zu lange versteckt → erwischt
            }
        }
    }
}

function updateSanity() {
    let currentSanityDrain = player.sanityDrainRate;
    let monsterProximityDrain = 0;

    enemiesData.forEach(e => {
        if (e.floor === currentFloor) {
            let d = Math.hypot(player.x - e.x, player.y - e.y);
            if (d < 500) monsterProximityDrain += (1 - d / 500) * 0.2;
            if (e.state === 'chase') monsterProximityDrain += 0.1;
        }
    });
    
    if (window._flashlightFlicker < 0.8) currentSanityDrain += 0.05;
    currentSanityDrain += monsterProximityDrain;

    if (monsterProximityDrain === 0 && !player.isHiding) {
        player.sanity = Math.min(player.maxSanity, player.sanity + player.sanityRegenRate);
    } else {
        player.sanity = Math.max(0, player.sanity - currentSanityDrain);
    }

    player.sanityEffectIntensity = 1 - (player.sanity / player.maxSanity);
    if (player.sanity <= 0 && gameState === 'playing') triggerJumpscare();
}

function updatePickupsAndExit() {
    const pgx = Math.floor(player.x / TILE_SIZE);
    const pgy = Math.floor(player.y / TILE_SIZE);

    keysData.forEach(k => {
        if (!k.collected && k.floor === currentFloor && Math.hypot(player.x - k.x, player.y - k.y) < player.radius + 20) {
            k.collected = true;
            player.keys++;
            playKeyPickup();
            // Letzter Schlüssel: Die weiße Exit-Tür erscheint irgendwo auf der Karte
            if (player.keys >= TOTAL_KEYS) spawnExitDoor();
            updateMessage();
        }
    });

    if (exitSpawned && player.keys >= TOTAL_KEYS && currentFloor === exitFloor) {
        if (map[pgy] && map[pgy][pgx] === 'E') {
            gameState = 'victory';
            hideGameHud();
            if (document.pointerLockElement) document.exitPointerLock();

            // Statistik des erfolgreichen Versuchs anzeigen
            const victoryStats = document.getElementById('victory-stats');
            if (victoryStats) {
                const survived = gameRunStartTime > 0 ? Math.floor((Date.now() - gameRunStartTime) / 1000) : 0;
                const mins = Math.floor(survived / 60);
                const secs = String(survived % 60).padStart(2, '0');
                const diffNames = { leicht: 'Easy', normal: 'Normal', schwer: 'Hard', impossible: 'Impossible' };
                victoryStats.innerHTML =
                    `<div class="stat"><div class="stat-label">Keys</div><div class="stat-value">${player.keys} / ${TOTAL_KEYS}</div></div>` +
                    `<div class="stat"><div class="stat-label">Difficulty</div><div class="stat-value">${diffNames[currentDifficulty] || currentDifficulty}</div></div>` +
                    `<div class="stat"><div class="stat-label">Time</div><div class="stat-value">${mins}:${secs}</div></div>`;
            }
            document.getElementById('victory').classList.remove('hidden');
        }
    }
}

function drawFirstPersonOverlay() {
    let isMoving = keysPressed['w'] || keysPressed['a'] || keysPressed['s'] || keysPressed['d'];
    let time = Date.now() / 1000;
    let shakeY = Math.sin(time * 6.5) * (isMoving ? 5 : 1.5);
    let shakeX = Math.cos(time * 3.3) * (isMoving ? 4 : 1);
    let flicker = window._flashlightFlicker || 1.0;

    // --- 1. Realistischer runder Lichtkegel (Vignette) ---
    // Der Lichtkegel bewegt sich synchron mit der Taschenlampe
    // Das Licht bleibt nun im Zentrum des Bildschirms (da wo man hinschaut)
    let gazeCenterY = canvas.height / 2 + shakeY * 1.5;
    let gazeCenterX = canvas.width / 2 + canvas.width * 0.02 + shakeX * 2.0;

    // Basis-Vignette (hartes Abfallen am Rand wie bei LED-Taschenlampen) - Jetzt deutlich dunkler außen
    let vig = ctx.createRadialGradient(gazeCenterX, gazeCenterY, canvas.height * 0.12, gazeCenterX, gazeCenterY, canvas.height * 0.75);
    vig.addColorStop(0, 'rgba(0,0,0,0)');
    vig.addColorStop(0.25, `rgba(0,0,0,${0.05 * flicker})`);
    vig.addColorStop(0.4, `rgba(0,0,0,${0.35 * flicker})`);
    vig.addColorStop(0.55, 'rgba(0,0,0,0.92)');
    vig.addColorStop(0.75, 'rgba(0,0,0,1)');
    vig.addColorStop(1, 'rgba(0,0,0,1)');
    ctx.fillStyle = vig;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Innerer LED-Ring (Hotspot)
    let hotSpot = ctx.createRadialGradient(gazeCenterX, gazeCenterY, 0, gazeCenterX, gazeCenterY, canvas.height * 0.25);
    hotSpot.addColorStop(0, `rgba(255, 250, 240, ${0.12 * flicker})`);
    hotSpot.addColorStop(0.7, `rgba(255, 245, 220, ${0.05 * flicker})`);
    hotSpot.addColorStop(0.8, `rgba(255, 240, 200, 0)`);
    ctx.fillStyle = hotSpot;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Streulicht-Ringe (Lens Flare / Reflektor-Artefakte)
    ctx.strokeStyle = `rgba(255, 250, 230, ${0.02 * flicker})`;
    ctx.lineWidth = canvas.height * 0.02;
    ctx.beginPath();
    ctx.arc(gazeCenterX, gazeCenterY, canvas.height * 0.45, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = `rgba(255, 245, 220, ${0.015 * flicker})`;
    ctx.lineWidth = canvas.height * 0.05;
    ctx.beginPath();

    ctx.globalAlpha = 1.0;

    // --- 2. Realistisches Taschenlampen-Modell ---
    ctx.save();

    let fx = canvas.width * 0.72 + shakeX;
    // Die Taschenlampe bewegt sich leicht vertikal mit dem Blickwinkel mit
    let fy = canvas.height + shakeY - 10 - (player.pitch * 40);

    ctx.translate(fx, fy);

    let modelScale = (canvas.height / 600) * 1.25;
    ctx.scale(modelScale, modelScale);

    // Die Taschenlampe neigt sich jetzt passend zur Blickrichtung (player.pitch)
    let tiltAngle = -0.12 + Math.sin(time * 1.5) * 0.008 - (player.pitch * 0.5); 
    ctx.rotate(tiltAngle);

    // --- Unterarm mit Ärmel ---
    let armGrad = ctx.createLinearGradient(40, 120, 130, 400);
    armGrad.addColorStop(0, '#1a3350');
    armGrad.addColorStop(0.5, '#152a42');
    armGrad.addColorStop(1, '#0f1e30');
    ctx.fillStyle = armGrad;
    ctx.beginPath();
    ctx.moveTo(15, 95);
    ctx.quadraticCurveTo(-10, 180, 80, 400);
    ctx.lineTo(155, 400);
    ctx.quadraticCurveTo(110, 200, 55, 95);
    ctx.closePath();
    ctx.fill();

    // Ärmel-Falten
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(25, 130); ctx.quadraticCurveTo(50, 145, 50, 130);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(30, 160); ctx.quadraticCurveTo(60, 170, 55, 155);
    ctx.stroke();

    // --- Hand (Hautfarbe mit Fingern) ---
    let skinGrad = ctx.createRadialGradient(30, 75, 5, 30, 75, 40);
    skinGrad.addColorStop(0, '#f5c9a0');
    skinGrad.addColorStop(1, '#d4a574');
    ctx.fillStyle = skinGrad;

    // Handfläche (hinter dem Griff)
    ctx.beginPath();
    ctx.ellipse(28, 78, 28, 22, -0.15, 0, Math.PI * 2);
    ctx.fill();

    // Finger um den Griff (4 Finger vorne sichtbar)
    ctx.fillStyle = '#e8b888';
    for (let f = 0; f < 4; f++) {
        let fingerY = 40 + f * 18;
        let fingerCurve = Math.sin(f * 0.7 + 0.3) * 3;
        ctx.beginPath();
        ctx.ellipse(-2 + fingerCurve, fingerY, 7, 9, -0.2, 0, Math.PI * 2);
        ctx.fill();
        // Knöchel-Detail
        ctx.strokeStyle = 'rgba(180, 140, 100, 0.4)';
        ctx.lineWidth = 0.5;
        ctx.beginPath();
        ctx.arc(-2 + fingerCurve, fingerY - 2, 4, 0, Math.PI);
        ctx.stroke();
    }

    // Daumen (seitlich)
    ctx.fillStyle = '#e8b888';
    ctx.beginPath();
    ctx.ellipse(48, 55, 8, 14, 0.4, 0, Math.PI * 2);
    ctx.fill();

    // --- Taschenlampen-Griff (zylindrisch, metallisch) ---
    let handleGrad = ctx.createLinearGradient(0, 20, 42, 20);
    handleGrad.addColorStop(0, '#1a1a1a');
    handleGrad.addColorStop(0.2, '#333');
    handleGrad.addColorStop(0.4, '#2a2a2a');
    handleGrad.addColorStop(0.6, '#444');
    handleGrad.addColorStop(0.8, '#2a2a2a');
    handleGrad.addColorStop(1, '#111');
    ctx.fillStyle = handleGrad;

    // Gerundeter Griff
    ctx.beginPath();
    ctx.moveTo(3, 20);
    ctx.lineTo(3, 115);
    ctx.quadraticCurveTo(3, 125, 10, 125);
    ctx.lineTo(32, 125);
    ctx.quadraticCurveTo(39, 125, 39, 115);
    ctx.lineTo(39, 20);
    ctx.closePath();
    ctx.fill();

    // Gummi-Grip Rillen
    ctx.strokeStyle = 'rgba(80, 80, 80, 0.5)';
    ctx.lineWidth = 1.5;
    for (let gy = 35; gy < 115; gy += 6) {
        ctx.beginPath();
        ctx.moveTo(5, gy);
        ctx.lineTo(37, gy);
        ctx.stroke();
    }

    // Schalter (kleiner Knopf an der Seite)
    ctx.fillStyle = '#555';
    ctx.fillRect(39, 50, 5, 12);
    ctx.fillStyle = '#777';
    ctx.fillRect(40, 52, 3, 8);

    // --- Taschenlampen-Kopf (konisch, Reflektor) ---
    let headGrad = ctx.createLinearGradient(-15, -50, 55, -50);
    headGrad.addColorStop(0, '#0d0d0d');
    headGrad.addColorStop(0.3, '#2a2a2a');
    headGrad.addColorStop(0.5, '#333');
    headGrad.addColorStop(0.7, '#2a2a2a');
    headGrad.addColorStop(1, '#0d0d0d');
    ctx.fillStyle = headGrad;
    ctx.beginPath();
    ctx.moveTo(2, 22);
    ctx.lineTo(-12, -35);
    ctx.quadraticCurveTo(-14, -42, -8, -44);
    ctx.lineTo(50, -44);
    ctx.quadraticCurveTo(56, -42, 54, -35);
    ctx.lineTo(40, 22);
    ctx.closePath();
    ctx.fill();

    // Metallischer Ring zwischen Kopf und Griff
    ctx.fillStyle = '#555';
    ctx.fillRect(-1, 18, 44, 5);
    let ringHighlight = ctx.createLinearGradient(-1, 18, 43, 18);
    ringHighlight.addColorStop(0, 'rgba(100,100,100,0)');
    ringHighlight.addColorStop(0.4, 'rgba(180,180,180,0.3)');
    ringHighlight.addColorStop(0.6, 'rgba(180,180,180,0.3)');
    ringHighlight.addColorStop(1, 'rgba(100,100,100,0)');
    ctx.fillStyle = ringHighlight;
    ctx.fillRect(-1, 18, 44, 5);

    // Reflektor-Ring am Kopfende
    ctx.strokeStyle = '#666';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-10, -40);
    ctx.lineTo(52, -40);
    ctx.stroke();

    // --- Linse (leuchtend, mit Flicker-Effekt) ---
    let lensFlicker = flicker;

    // Linsen-Reflektor (innere Verspiegelung)
    let reflectorGrad = ctx.createLinearGradient(-6, -44, 48, -44);
    reflectorGrad.addColorStop(0, `rgba(200, 190, 170, ${0.3 * lensFlicker})`);
    reflectorGrad.addColorStop(0.5, `rgba(255, 250, 235, ${0.6 * lensFlicker})`);
    reflectorGrad.addColorStop(1, `rgba(200, 190, 170, ${0.3 * lensFlicker})`);
    ctx.fillStyle = reflectorGrad;
    ctx.fillRect(-8, -47, 58, 6);

    // Leuchtende Linse
    ctx.fillStyle = `rgba(255, 252, 240, ${0.95 * lensFlicker})`;
    ctx.fillRect(-8, -47, 58, 4);

    // Glow um die Linse
    let lensGlow = ctx.createRadialGradient(21, -47, 0, 21, -47, 100);
    lensGlow.addColorStop(0, `rgba(255, 250, 230, ${0.8 * lensFlicker})`);
    lensGlow.addColorStop(0.15, `rgba(255, 245, 210, ${0.5 * lensFlicker})`);
    lensGlow.addColorStop(0.4, `rgba(255, 240, 200, ${0.15 * lensFlicker})`);
    lensGlow.addColorStop(1, 'rgba(255, 235, 180, 0)');
    ctx.fillStyle = lensGlow;
    ctx.fillRect(-80, -150, 200, 140);

    // Lens flare (kleine Lichtreflexe)
    ctx.globalAlpha = 0.3 * lensFlicker;
    ctx.fillStyle = '#fffde8';
    ctx.beginPath(); ctx.arc(-5, -48, 3, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(47, -48, 2, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1.0;

    ctx.restore();
}

function render() {
    // Nur rendern, wenn der Context existiert und wir nicht im Jumpscare sind
    if (!ctx) return;

    if (gameState === 'gameover') {
        canvas.style.filter = 'none'; // Filter zurücksetzen bei Game Over
        return;
    }

    // Sicherheits-Reset: niemals mit einem halbtransparenten Zustand aus einem
    // vorherigen Effekt ins Frame starten (sonst wird "alles durchsichtig")
    ctx.globalAlpha = 1.0;

    // --- ORIENTIERUNGSLOSIGKEIT (Blur-Effekt) ---
    // Erzeugt eine dynamische Unschärfe basierend auf der Intensität des roten Rand-Effekts
    const blurValue = jumpscareEffect.currentRedIntensity * 5; // Ergibt max ca. 3px Blur bei 0.6 Intensität
    canvas.style.filter = blurValue > 0.1 ? `blur(${blurValue}px)` : 'none';

    let time = Date.now() / 1000;

    // Startbildschirm: am unteren Flurende stehen und nach Norden den Gang hinab blicken
    const pAngle = gameState === 'start' ? (-Math.PI / 2 + 0.04) : player.angle;
    const pX = gameState === 'start' ? 5.5 * TILE_SIZE : player.x;
    const pY = gameState === 'start' ? 11.5 * TILE_SIZE : player.y;

    const aspectRatio = width / height;
    const FOV = 2 * Math.atan(aspectRatio / 2);
    const dirX = Math.cos(pAngle);
    const dirY = Math.sin(pAngle);
    const planeX = -dirY * (aspectRatio / 2);
    const planeY = dirX * (aspectRatio / 2);
    const pitchOffset = player.pitch * (height * 0.5);

    if (gameState === 'playing' && floorPixels !== null && ceilingPixels !== null) {
        // --- TEXTURIERTER BODEN & DECKE (Performance-Buffer) ---
        if (!cachedScreenImg || cachedScreenImg.width !== width || cachedScreenImg.height !== height) {
            cachedScreenImg = ctx.createImageData(width, height);
            cachedPixels = new Uint32Array(cachedScreenImg.data.buffer);
        }
        const screenImg = cachedScreenImg;
        const pixels = cachedPixels;

        // Taschenlampen-Flackern dämpft auch Boden & Decke → bei einem Ausfall
        // wird konsequent ALLES dunkel (statt dass Wände schwarz, Boden hell bleibt)
        const floorFlick = window._flashlightFlicker || 1.0;
        const lightMul = 0.25 + 0.75 * floorFlick;

        // Loop über den gesamten Bildschirm für Decke UND Boden
        for (let y = 0; y < height; y++) {
            const isFloor = y > height / 2 + pitchOffset;
            // p ist der vertikale Abstand zum Horizont
            const p = isFloor ? (y - height / 2 - pitchOffset) : (height / 2 + pitchOffset - y);
            
            // Sicherheits-Check: p darf nicht 0 oder negativ sein
            if (p < 0.1) continue;

            // Vertikale Distanz synchronisieren (muss exakt zur wallHeight-Logik passen)
            const rowDistance = (height / 2) / p;

            // Welt-Position der Zeile berechnen
            const floorStepX = (rowDistance * planeX * 2) / width;
            const floorStepY = (rowDistance * planeY * 2) / width;

            let floorX = (pX / TILE_SIZE) + rowDistance * (dirX - planeX);
            let floorY = (pY / TILE_SIZE) + rowDistance * (dirY - planeY);

            // Shading einmal pro Zeile berechnen (spart Millionen Kalkulationen)
            const shade = (1 - Math.min(1, rowDistance / 4)) * lightMul;

            for (let x = 0; x < width; x++) {
                const tx = ((floorX * 1024) | 0) & 1023;
                const ty = ((floorY * 1024) | 0) & 1023;
                const texPos = ty * 1024 + tx;
                let color = isFloor ? floorPixels[texPos] : ceilingPixels[texPos];

                floorX += floorStepX;
                floorY += floorStepY;

                if (shade < 1) {
                    const r = ((color & 0xFF) * shade) | 0;
                    const g = (((color >> 8) & 0xFF) * shade) | 0;
                    const b = (((color >> 16) & 0xFF) * shade) | 0;
                    color = (b << 16) | (g << 8) | r;
                }

                // Alpha IMMER voll: Boden/Decke dürfen nie durchsichtig werden
                pixels[y * width + x] = color | 0xFF000000;
            }
        }
        ctx.putImageData(screenImg, 0, 0);
    } else {
        // Fallback falls Texturen noch laden oder fehlgeschlagen sind
        ctx.fillStyle = '#111'; // Boden
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = '#050505'; // Decke
        ctx.fillRect(0, 0, width, height / 2 + pitchOffset);
    }
    const STRIP_WIDTH = 2; // Höhere Auflösung
    const NUM_RAYS = Math.ceil(width / STRIP_WIDTH); // Changed from 2 to 3 for performance

    if (!zBuffer || zBuffer.length !== NUM_RAYS) {
        zBuffer = new Float64Array(NUM_RAYS);
    }
    zBuffer.fill(Infinity);

    // Performance: Fenster-Lookup und nahe Fackeln einmal pro Frame statt pro Strahl
    const winSet = (gameState === 'playing' && windowLookup[currentFloor]) ? windowLookup[currentFloor] : null;
    const nearTorches = [];
    if (gameState === 'playing') {
        for (let ti = 0; ti < torchesData.length; ti++) {
            const tch = torchesData[ti];
            if (tch.floor === currentFloor && Math.abs(tch.x - pX) < 750 && Math.abs(tch.y - pY) < 750) nearTorches.push(tch);
        }
    }

    for (let i = 0; i < NUM_RAYS; i++) {
        // camX ist die Position auf der Bildebene von -1 (links) bis 1 (rechts)
        const camX = (2 * i) / (NUM_RAYS - 1) - 1;
        const dx = dirX + planeX * camX;
        const dy = dirY + planeY * camX;

        let renderMap = gameState === 'start' ? startScreenMap : map;
        let mapW = gameState === 'start' ? renderMap[0].length : MAP_WIDTH;
        let mapH = gameState === 'start' ? renderMap.length : MAP_HEIGHT;

        let mapX = (pX / TILE_SIZE) | 0;
        let mapY = (pY / TILE_SIZE) | 0;

        let deltaDistX = Math.abs(1 / dx);
        let deltaDistY = Math.abs(1 / dy);

        let stepX, stepY;
        let sideDistX, sideDistY;

        if (dx < 0) {
            stepX = -1;
            sideDistX = ((pX / TILE_SIZE) - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - (pX / TILE_SIZE)) * deltaDistX;
        }

        if (dy < 0) {
            stepY = -1;
            sideDistY = ((pY / TILE_SIZE) - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - (pY / TILE_SIZE)) * deltaDistY;
        }

        let hit = false;
        let side = 0;
        let hitTile = null;
        let doorOpenAmt = 0;
        let doorTexU = 0; // vorberechnete Textur-Koordinate für die Schwingtür

        while (!hit && mapX >= 0 && mapX < mapW && mapY >= 0 && mapY < mapH) {
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0;
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1;
            }
            if (renderMap[mapY] && renderMap[mapY][mapX] !== '0') {
                let t = renderMap[mapY][mapX];
                if (t === '2' && gameState === 'playing') {
                    // SCHWINGTÜR: Das Türblatt dreht um die Scharnier-Seite auf und
                    // schwingt nach innen weg. Die Öffnung beginnt am Knauf und wandert
                    // zum Scharnier hin ("vom Knauf nach links"), das Blatt verkürzt sich.
                    const d = doorLookup[currentFloor] && doorLookup[currentFloor].get(mapY * MAP_WIDTH + mapX);
                    const openAmt = d ? d.open : 0;
                    if (openAmt > 0.01) {
                        let pwd = (side === 0)
                            ? (mapX - (pX / TILE_SIZE) + (1 - stepX) / 2) / dx
                            : (mapY - (pY / TILE_SIZE) + (1 - stepY) / 2) / dy;
                        let wx = (side === 0) ? (pY / TILE_SIZE) + pwd * dy : (pX / TILE_SIZE) + pwd * dx;
                        wx -= Math.floor(wx);
                        // Textur immer Scharnier(0) → Knauf(1) ausrichten (gleiche Spiegelung
                        // wie beim Zeichnen), damit die Tür von beiden Seiten korrekt aufgeht.
                        const flip = (side === 0 && dx > 0) || (side === 1 && dy < 0);
                        const texU = flip ? 1 - wx : wx;
                        // Sichtbare (projizierte) Blattbreite einer schwingenden Tür = cos(Winkel)
                        const panelW = Math.cos(openAmt * Math.PI / 2);
                        if (texU <= panelW) {
                            hit = true;
                            hitTile = t;
                            doorOpenAmt = openAmt;
                            // Volle Tür-Textur in das verkürzte Blatt stauchen → Knauf bleibt
                            // an der Vorderkante und wandert sichtbar nach innen.
                            doorTexU = panelW > 0.0001 ? texU / panelW : 0;
                        }
                        // sonst: offene Lücke auf der Knauf-Seite — Strahl läuft weiter
                    } else {
                        hit = true;
                        hitTile = t;
                    }
                } else if (t === '1' || t === '2' || t === '4' || t === '5' || t === 'E' || 'KSWB'.includes(t)) {
                    // Treppen ('U'/'D') sind KEINE Wand mehr — sie werden als echtes
                    // 3D-Treppen-Objekt (Sprite) gezeichnet, der Strahl läuft hier durch.
                    hit = true;
                    hitTile = t;
                }
            }
        }

        if (hit) {
            let perpWallDist;
            // Use pX and pY instead of player.x/y to ensure consistency with the start screen and floor transitions
            if (side === 0) perpWallDist = (mapX - (pX / TILE_SIZE) + (1 - stepX) / 2) / dx;
            else perpWallDist = (mapY - (pY / TILE_SIZE) + (1 - stepY) / 2) / dy;

            if (perpWallDist < 0.1) perpWallDist = 0.1;
            let dist = perpWallDist * TILE_SIZE;
            zBuffer[i] = dist;

            // Perspektivisch korrekte Wandhöhe: Wand füllt bei Distanz 1 exakt den Bildschirm
            let wallHeight = canvas.height / perpWallDist;

            // Die Z-Position des Spielers verschiebt die vertikale Zeichnung der Wand
            let zOffset = (player.z / TILE_SIZE) * wallHeight;
            let wallTop = (canvas.height / 2) - (wallHeight / 2) + pitchOffset + zOffset;
            let wallBottom = wallTop + wallHeight;

            let wallX;
            if (side === 0) wallX = (pY / TILE_SIZE) + perpWallDist * dy;
            else wallX = (pX / TILE_SIZE) + perpWallDist * dx;
            wallX -= Math.floor(wallX);

            // Schwingtür: bereits gestauchte, korrekt orientierte Textur-Koordinate nutzen
            if (hitTile === '2' && doorOpenAmt > 0) {
                wallX = Math.min(0.999, Math.max(0, doorTexU));
            }

            // Textur-Auswahl mit Fallback-Check
            let tex;
            let roomColor = null;
            let hasPoster = false;
            let baseWallTint = null; // Neue Variable für generische Wandtönung

            if (hitTile === '1' || 'KSWB'.includes(hitTile)) {
                tex = wallImg; // Komposit-Canvas: Web-Textur oder prozeduraler Fallback

                if (hitTile === 'K') roomColor = 'rgba(0, 120, 0, 0.45)'; // Küche: Moosgrün
                if (hitTile === 'S') { roomColor = 'rgba(0, 0, 150, 0.45)'; hasPoster = true; } // Schlafzimmer: Nachtblau
                if (hitTile === 'W') roomColor = 'rgba(150, 0, 0, 0.45)'; // Wohnzimmer: Blutrot
                if (hitTile === 'B') roomColor = 'rgba(180, 160, 0, 0.5)'; // Bad: Krankhaftes Gelb

                // Generische Wandtönung für '1' und andere Raumwände, falls keine spezifische Raumfarbe vorhanden ist
                if (!roomColor) {
                    let hue = (mapX * 47 + mapY * 31 + (currentFloor * 90)) % 360; // Größere Farbsprünge
                    let saturation = 45;
                    let lightness = 35;
                    baseWallTint = `hsla(${hue}, ${saturation}%, ${lightness}%, 0.4)`; // Kräftigerer Tint
                }
            } else if (hitTile === '2') {
                tex = doorTex; // Realistische prozedurale Holztür
            } else if (hitTile === 'E') {
                tex = exitDoorTex; // Leuchtend weiße Exit-Tür
            } else {
                tex = wallTexFallback; // Standard-Fallback für unbekannte Kacheln
            }

            // Grafik-Fix: Clamp texX um Out-of-Bounds Fehler und schwarze Linien zu vermeiden
            let texX = Math.min(tex.width - 1, Math.floor(wallX * tex.width));

            // Schwingtür ist bereits richtig orientiert (siehe doorTexU) → nicht erneut spiegeln
            const skipFlip = (hitTile === '2' && doorOpenAmt > 0);
            if (!skipFlip) {
                if (side === 0 && dx > 0) texX = tex.width - texX - 1;
                if (side === 1 && dy < 0) texX = tex.width - texX - 1;
            }

            // Stark reduziertes Umgebungslicht für echtes Horror-Feeling
            // Startbildschirm: gleichmäßig & hell genug ausgeleuchteter Flur (kein
            // Taschenlampenkegel) — so sieht man den ganzen Gang samt Türen.
            // Im Spiel fast pechschwarz, nur die Taschenlampe zählt.
            const isStart = (gameState === 'start');
            let shade = isStart
                ? 0.62 * Math.max(0.4, 1 - dist / 1700)
                : Math.pow(Math.max(0, 1 - (dist / 300)), 2) * 0.01;

            // Oberflächen-Varianz für mehr Realismus (Schmutz-Simulation)
            let surfaceNoise = Math.sin(mapX * 13 + mapY * 7 + wallX * 5) * 0.03;
            shade = Math.max(0, shade + surfaceNoise);

            // RICHTUNGS-SHADING: Hilft extrem bei der Orientierung in Ecken
            // (im Menü nur dezent, damit die Türwände hell genug bleiben)
            if (side === 1) shade *= isStart ? 0.82 : 0.6; // Seitliche Wände dunkler
            else if (dx < 0) shade *= isStart ? 0.92 : 0.85; // West-Wände leicht abdunkeln

            // --- REALISTISCHE TASCHENLAMPE mit rundem Kegel ---
            let flicker = window._flashlightFlicker || 1.0;
            let centerDistX = Math.abs(i - NUM_RAYS / 2);
            
            // Optimierte vertikale Lichtberechnung: Prüft die Distanz zum nächsten Punkt der Wand
            let screenCenterY = canvas.height / 2;
            let closestWallY = Math.max(wallTop, Math.min(screenCenterY, wallBottom));
            let centerDistY = Math.abs(closestWallY - screenCenterY) / canvas.height * NUM_RAYS;
            
            // Euklidische Distanz für runden Lichtkegel
            let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);

            // Warmer Farbton-Multiplikator (wird beim Zeichnen angewendet)
            let warmR = 1.0, warmG = 1.0, warmB = 1.0;

            // Taschenlampe NUR im Spiel — im Startbildschirm bleibt der Flur düster
            if (gameState !== 'start') {
                let flashlightCone = NUM_RAYS / 2.3;
                let flashlightFactor = Math.max(0, 1 - (centerDist2D / flashlightCone));
                if (flashlightFactor > 0 && dist < 650) {
                    // Realistischer Hotspot mit inverse-square-artigem Abfall
                    let distFalloff = 1 / (1 + (dist / 120) * (dist / 120)) * 2.5;
                    let beamIntensity = Math.pow(flashlightFactor, 2.5) * distFalloff * 4.2 * flicker; // Hellerer Kern
                    shade += beamIntensity;

                    // Breitere Corona (Streulicht)
                    let coronaFactor2D = Math.max(0, 1 - (centerDist2D / (NUM_RAYS / 1.5)));
                    shade += Math.pow(coronaFactor2D, 2) * (1 - (dist / 450)) * 0.3 * flicker; // Dunklerer Rand

                    // Warmer Farbton im Lichtkegel (stärker im Zentrum)
                    let warmth = flashlightFactor * 0.15;
                    warmR = 1.0 + warmth * 0.3;
                    warmG = 1.0 + warmth * 0.15;
                    warmB = 1.0 - warmth * 0.2;
                }
            }

            // --- FENSTER & DONNER-BELEUCHTUNG (Set-Lookup statt Array-Schleife) ---
            const isWindow = winSet ? winSet.has(mapY * MAP_WIDTH + mapX) : false;
            if (isWindow && thunderState.active) {
                // Blitz erhellt Fenster-Kacheln dramatisch
                shade += thunderState.intensity * 1.5;
            } else if (isWindow) {
                // Fenster haben schwaches bläuliches Mondlicht
                shade += 0.03;
                warmB = Math.min(warmB + 0.1, 1.2);
            }

            // Fackeln beleuchten nahe Wände (nur vorgefilterte Fackeln in der Nähe)
            for (let ti = 0; ti < nearTorches.length; ti++) {
                let torch = nearTorches[ti];
                let wallWorldX = mapX * TILE_SIZE + wallX * TILE_SIZE;
                let wallWorldY = mapY * TILE_SIZE + TILE_SIZE / 2;
                let torchDist = Math.hypot(wallWorldX - torch.x, wallWorldY - torch.y);
                if (torchDist < TILE_SIZE * 3) {
                    let torchLight = Math.pow(1 - torchDist / (TILE_SIZE * 3), 2) * 0.3;
                    torch.flickerCounter += 0.07;
                    torchLight *= 0.8 + Math.sin(torch.flickerCounter) * 0.2;
                    shade += torchLight;
                    warmR = Math.min(warmR + torchLight * 0.5, 1.4);
                    warmG = Math.min(warmG + torchLight * 0.2, 1.2);
                }
            }

            // Fog effect: blend with black based on distance
            // Im Menü viel klarer (man soll den ganzen Gang sehen), im Spiel sehr kurze Sicht
            let fogAmount = (gameState === 'start') ? Math.min(1, dist / 1400) : Math.min(1, dist / 450);
            shade = shade * (1 - fogAmount);
            
            // Sicherheit: Wand nur zeichnen, wenn sie existiert.
            if (wallHeight > 0.1) {
                // WICHTIG: Die Wand wird DECKEND gezeichnet und die Dunkelheit als
                // schwarze Auflage simuliert — NICHT mehr über die Transparenz.
                // Dadurch scheint nie mehr der Boden durch eine dunkle Wand ("durchsichtige Texturen").
                const litShade = Math.max(0, Math.min(1, shade));
                const sx = i * STRIP_WIDTH;
                const sw = STRIP_WIDTH + 0.6;

                if (hitTile !== 'E') {
                    // 1) Deckende Wandtextur
                    ctx.globalAlpha = 1.0;
                    ctx.drawImage(tex, texX, 0, 1, tex.height, sx, wallTop, STRIP_WIDTH + 0.5, wallHeight);

                    // 2) Raumfarbe/Tönung als Teil der Oberfläche
                    if ((roomColor || baseWallTint) && !isWindow) {
                        const baseAlpha = roomColor ? parseFloat(roomColor.split(',')[3]) : 0.4;
                        ctx.globalAlpha = baseAlpha;
                        ctx.fillStyle = roomColor || baseWallTint;
                        ctx.fillRect(sx, wallTop, sw, wallHeight);
                    }

                    // 3) DUNKELHEIT: schwarze Auflage (Wand bleibt fest, wird nur dunkler)
                    if (litShade < 1) {
                        ctx.globalAlpha = 1 - litShade;
                        ctx.fillStyle = '#000';
                        ctx.fillRect(sx, wallTop, sw, wallHeight);
                    }

                    // 4) Fenster leuchten DURCH die Dunkelheit (nach der Verdunkelung)
                    if (isWindow && wallX > 0.15 && wallX < 0.85) {
                        let winTop = wallTop + wallHeight * 0.15;
                        let winH = wallHeight * 0.55;
                        let skyBrightness = thunderState.active ? Math.floor(40 + thunderState.intensity * 180) : 15;
                        ctx.globalAlpha = 1.0;
                        ctx.fillStyle = `rgb(${Math.floor(skyBrightness * 0.3)}, ${Math.floor(skyBrightness * 0.35)}, ${skyBrightness})`;
                        ctx.fillRect(sx, winTop, sw, winH);
                        if (wallX > 0.14 && wallX < 0.18 || wallX > 0.82 && wallX < 0.86 || wallX > 0.48 && wallX < 0.52) {
                            ctx.fillStyle = 'rgba(20, 15, 10, 0.9)';
                            ctx.fillRect(sx, winTop, sw, winH);
                        }
                    }

                    // 5) Warmer Lichtschein der Taschenlampe (additiv, nur im Kegel)
                    if (warmR > 1.01 || warmG > 1.01 || warmB < 0.99) {
                        let tintAlpha = Math.min(0.15, litShade * 0.12);
                        let tR = Math.floor(Math.min(255, (warmR - 1) * 400));
                        let tG = Math.floor(Math.min(255, (warmG - 1) * 300));
                        ctx.globalAlpha = tintAlpha;
                        ctx.fillStyle = `rgb(${tR}, ${tG}, 0)`;
                        ctx.fillRect(sx, wallTop, sw, wallHeight);
                    }

                    // 6) Poster (nur sichtbar wenn beleuchtet)
                    if (hasPoster && wallX > 0.4 && wallX < 0.6) {
                        ctx.globalAlpha = litShade;
                        ctx.fillStyle = 'rgba(20, 20, 20, 0.85)';
                        ctx.fillRect(sx, wallTop + wallHeight * 0.25, sw, wallHeight * 0.4);
                        ctx.fillStyle = 'rgba(120, 0, 0, 0.6)';
                        ctx.fillRect(sx, wallTop + wallHeight * 0.4, sw, wallHeight * 0.05);
                    }

                    // 7) Fußleiste und Deckenkante (mit der Wand abdunkeln)
                    ctx.globalAlpha = litShade;
                    ctx.fillStyle = 'rgba(10, 5, 5, 0.7)';
                    ctx.fillRect(sx, wallTop + wallHeight * 0.88, sw, wallHeight * 0.12);
                    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                    ctx.fillRect(sx, wallTop, sw, wallHeight * 0.06);
                } else {
                    // EXIT: strahlend weiße Tür — deckend, leuchtet durch den Nebel
                    const pulse = 0.8 + Math.sin(time * 2.5) * 0.2;
                    const glow = Math.max(litShade, pulse * Math.max(0.25, 1 - dist / 1500));
                    ctx.globalAlpha = 1.0;
                    ctx.drawImage(tex, texX, 0, 1, tex.height, sx, wallTop, STRIP_WIDTH + 0.5, wallHeight);
                    // Exit nur leicht abdunkeln, damit sie als Leuchtfeuer sichtbar bleibt
                    if (glow < 1) {
                        ctx.globalAlpha = (1 - glow) * 0.55;
                        ctx.fillStyle = '#000';
                        ctx.fillRect(sx, wallTop, sw, wallHeight);
                    }
                }
                ctx.lineWidth = 1;
                ctx.globalAlpha = 1.0;
            }
        }
    }

    // Kamera-Beschreibung für das echte 3D-Rendering der Requisiten
    const cam = {
        pX: pX, pY: pY, dirX: dirX, dirY: dirY,
        a: aspectRatio / 2, w: canvas.width, h: canvas.height,
        pitch: pitchOffset, pz: player.z / TILE_SIZE
    };

    // Draw Sprites
    let sprites = [];
    if (gameState === 'start') {
        // Das Monster steht weit hinten am Ende des Flurs
        sprites.push({ x: 5.5 * TILE_SIZE, y: 2.5 * TILE_SIZE, type: 'start_monster', radius: 28 });
    } else {
        enemiesData.forEach(e => { if (e.floor === currentFloor) sprites.push({ x: e.x, y: e.y, type: 'enemy', radius: e.radius, state: e.state }) });
        keysData.forEach(k => { if (!k.collected && k.floor === currentFloor) sprites.push({ x: k.x, y: k.y, type: 'key', radius: 10 }) });
        torchesData.forEach(t => { if (t.floor === currentFloor) sprites.push({ x: t.x, y: t.y, type: 'torch', radius: 10, flick: t.flickerCounter }) });
        corpsesData.forEach(co => { if (co.floor === currentFloor) sprites.push({ x: co.x, y: co.y, type: 'corpse', corpseType: co.type, seed: co.seed, angle: co.angle, radius: 13 }) });
        stairsData.forEach(st => { if (st.floor === currentFloor) sprites.push({ x: st.x * TILE_SIZE + TILE_SIZE / 2, y: st.y * TILE_SIZE + TILE_SIZE / 2, type: 'stairs', dir: st.dir, radius: 34 }) });
        furnitureData.forEach(fu => { if (fu.floor === currentFloor) sprites.push({ x: fu.x, y: fu.y, type: 'furniture', furnType: fu.type, seed: fu.seed, angle: fu.angle, radius: 16 }) });
        closetsData.forEach(cl => { if (cl.floor === currentFloor) sprites.push({ x: cl.x, y: cl.y, type: 'closet', seed: cl.seed, angle: cl.angle, radius: 26 }) });
        bloodSplattersData.forEach(b => { if (b.floor === currentFloor) sprites.push({ x: b.x, y: b.y, z: b.z, type: 'blood', radius: b.size, opacity: b.opacity }) });
    }

    sprites.forEach(s => {
        let dx = s.x - pX;
        let dy = s.y - pY;

        // Manhattan-Distanz Quick-Culling (Performance)
        if (Math.abs(dx) + Math.abs(dy) > 4000) {
            s.dist = 99999;
            s.angle = 0;
            return;
        }

        s.dist = Math.hypot(dx, dy);
        let angleToSprite = Math.atan2(dy, dx);
        s.angle = angleToSprite - pAngle;
        while (s.angle > Math.PI) s.angle -= Math.PI * 2;
        while (s.angle < -Math.PI) s.angle += Math.PI * 2;
    });

    sprites.sort((a, b) => b.dist - a.dist);

    sprites.forEach(s => {
        if (s.dist < 5) return;
        if (s.dist > 700) return; // Nebel verschluckt alles dahinter — gar nicht erst zeichnen
        // Aufwändige 3D-Möbel/Schränke früher culin — bei der Distanz schon fast
        // komplett im Nebel (spart Zeichenzeit auf schwächeren Geräten).
        if ((s.type === 'furniture' || s.type === 'closet') && s.dist > 560) return;
        if (Math.abs(s.angle) > FOV / 1.5) return;

        let screenX = (0.5 * (s.angle / (FOV / 2)) + 0.5) * canvas.width;
        let spriteScale = (TILE_SIZE * canvas.height * 0.8) / (s.dist * Math.cos(s.angle));
        if (!isFinite(spriteScale) || spriteScale <= 0) return;

        let spriteHeight = spriteScale * (s.radius / TILE_SIZE) * 2;
        let spriteWidth = spriteHeight;

        // Grafik-Fix: Sprites müssen den vertikalen Z-Offset des Spielers (Treppen) mitmachen
        let spriteZOffset = (player.z / TILE_SIZE) * spriteScale;
        let customZOffset = (s.z || 0) / TILE_SIZE * spriteScale;
        let spriteTop = (canvas.height / 2) - (spriteHeight / 2) + pitchOffset + spriteZOffset + customZOffset;

        if (s.type === 'key') spriteTop += spriteHeight * 0.5;

        let centerIdx = Math.floor(screenX / STRIP_WIDTH);
        let projectedSpriteDist = s.dist * Math.cos(s.angle);
        let visible = (centerIdx >= 0 && centerIdx < NUM_RAYS && zBuffer[centerIdx] > projectedSpriteDist - 5);

        // Boden-verankerte Sprites (Monster, Leichen, Treppe) liegen am Boden, nicht
        // mittig auf der Bildebene. Ihre tatsächliche Zeichen-Höhe brauchen wir für die
        // Beleuchtung — sonst werden sie beim Hoch-/Runterschauen fälschlich dunkel.
        const isFloorAnchored = (s.type === 'enemy' || s.type === 'corpse' || s.type === 'stairs' || s.type === 'furniture' || s.type === 'closet');
        let floorLineY = (canvas.height / 2) + (canvas.height / (projectedSpriteDist / TILE_SIZE)) / 2 + pitchOffset + spriteZOffset + customZOffset;

        if (visible) {
            // Umgebungslicht für Sprites (pechschwarz)
            let shade = Math.max(0.005, 0.02 - (s.dist / 250));
            // Feststehende Deko (Möbel/Schränke/Leichen/Treppen) bekommt ein kleines
            // Grundleuchten, das mit der Entfernung verblasst — so sieht man, dass sie
            // FEST im Raum stehen, statt nur dort aufzutauchen, wo man gerade hinschaut.
            if (s.type === 'furniture' || s.type === 'closet' || s.type === 'corpse' || s.type === 'stairs') {
                shade = Math.max(shade, 0.13 * Math.max(0, 1 - s.dist / 620));
            }
            let flicker = window._flashlightFlicker || 1.0;
            let centerDistX = Math.abs((screenX / canvas.width) - 0.5) * NUM_RAYS;
            // Vertikale Komponente: nächstgelegener Punkt der WIRKLICHEN Zeichenfläche
            // zum Bildzentrum (Fadenkreuz). Das Lichtzentrum MUSS den Blick nach oben/
            // unten (pitchOffset) mitmachen — sonst fallen boden­verankerte Möbel beim
            // Hoch-/Runterschauen aus dem Lichtkegel und werden unsichtbar.
            let screenCenterY = canvas.height / 2 + pitchOffset;
            let drawTopY = isFloorAnchored ? (floorLineY - spriteHeight) : spriteTop;
            let drawBotY = isFloorAnchored ? floorLineY : (spriteTop + spriteHeight);
            let closestSpriteY = Math.max(drawTopY, Math.min(screenCenterY, drawBotY));
            let centerDistY = Math.abs(closestSpriteY - screenCenterY) / canvas.height * NUM_RAYS;
            let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);
            let flashlightRadius = NUM_RAYS / 2.3;

            if (centerDist2D < flashlightRadius * 2 && s.dist < 650) {
                // Realistischer Hotspot mit inverse-square Abfall
                let distFalloff = 1 / (1 + (s.dist / 120) * (s.dist / 120)) * 2.5;
                let spriteFlashLight = Math.pow(Math.max(0, 1 - (centerDist2D / flashlightRadius)), 2.5) * distFalloff * 4.5 * flicker;
                shade += spriteFlashLight;

                // Corona
                let corona = Math.pow(Math.max(0, 1 - (centerDist2D / (NUM_RAYS / 1.5))), 2) * (1 - (s.dist / 450)) * 0.3 * flicker;
                shade += corona;
            }

            // Fackel-Beleuchtung für Sprites (vorgefilterte Liste)
            for (let ti = 0; ti < nearTorches.length; ti++) {
                let torch = nearTorches[ti];
                let torchDist = Math.hypot(s.x - torch.x, s.y - torch.y);
                if (torchDist < TILE_SIZE * 3) {
                    shade += Math.pow(1 - torchDist / (TILE_SIZE * 3), 2) * 0.25;
                }
            }

            // Blitz beleuchtet alle Sprites kurz
            if (thunderState.active) {
                shade += thunderState.intensity * 0.3;
            }

            if (s.type === 'torch') shade = 1;

            // Feste 3D-Deko (Möbel/Schränke/Treppen) ist SOLIDE: Helligkeit geht in die
            // Flächenschattierung (_propLightK), die Deckkraft bleibt voll — nur der
            // Distanz-Nebel lässt sie ausbleichen. Dadurch wird ein nahes Objekt NICHT
            // mehr durchsichtig, sondern nur dunkler, wenn die Lampe woanders hinzeigt.
            if (s.type === 'furniture' || s.type === 'closet' || s.type === 'stairs') {
                _propLightK = Math.max(0.14, Math.min(1.7, shade));
                // nah (< ~3 Kacheln) komplett undurchsichtig, dann sanft in den Nebel
                ctx.globalAlpha = s.dist < 220 ? 1 : Math.max(0, 1 - (s.dist - 220) / 340);
            } else if (s.type === 'corpse') {
                // Flaches Boden-Decal: nah ebenfalls solide halten
                shade = shade * (1 - Math.min(1, s.dist / 450));
                const solid = s.dist < 220 ? 0.92 : Math.max(0, 0.92 - (s.dist - 220) / 340);
                ctx.globalAlpha = Math.max(Math.min(1, shade), solid);
            } else {
                shade = shade * (1 - Math.min(1, s.dist / 450)); // Nebel für Sprites
                ctx.globalAlpha = Math.min(1, shade);
            }

            if (s.type === 'start_monster') {
                // Reglos im Dunkeln stehende Gestalt — nur als schwacher Schemen sichtbar.
                // Feste, niedrige Deckkraft (keine Taschenlampe im Menü), am Boden verankert.
                const perpTiles = projectedSpriteDist / TILE_SIZE;
                const floorBase = (canvas.height / 2) + (canvas.height / perpTiles) / 2 + pitchOffset + spriteZOffset + customZOffset;
                const groundedTop = floorBase - spriteHeight * 0.985;
                // langsames, unheimliches Atmen/Wiegen
                ctx.globalAlpha = 0.62 + Math.sin(time * 0.8) * 0.06;
                drawMonsterModel(ctx, screenX, groundedTop, spriteWidth, spriteHeight, {
                    isChase: true,   // schwach glimmende rote Augen
                    walking: false,  // steht still
                    t: time * 0.4    // sehr träge Bewegung
                });
            } else if (s.type === 'enemy' && spriteWidth > 1) { // Nur zeichnen, wenn groß genug
                // Gemeinsames Monster-Modell — wird auch von Jumpscare und Todesbildschirm benutzt
                // Das Monster am BODEN verankern: die Füße (Modell-Höhe ~0.985) auf die
                // Bodenlinie der jeweiligen Distanz setzen, damit es nicht mehr schwebt.
                const perpTiles = projectedSpriteDist / TILE_SIZE;
                const floorBase = (canvas.height / 2) + (canvas.height / perpTiles) / 2 + pitchOffset + spriteZOffset + customZOffset;
                const groundedTop = floorBase - spriteHeight * 0.985;
                drawMonsterModel(ctx, screenX, groundedTop, spriteWidth, spriteHeight, {
                    isChase: s.state === 'chase',
                    phase: s.dist * 0.01,
                    walking: true // löst den Geh-Zyklus aus (nur Ingame, nicht im Todesbildschirm)
                });
            } else if (s.type === 'key') {
                let t = Date.now() / 1000;
                let w = spriteWidth * 0.6; // Schlüssel etwas schmaler
                let h = spriteHeight * 0.6;
                let cx = screenX;
                let floatingY = spriteTop + spriteHeight * 0.5 + Math.sin(t * 4) * 10; // Schweb-Effekt

                ctx.fillStyle = '#ffd700'; // Gold
                ctx.strokeStyle = '#b8860b'; // Dunkles Gold für Outlines
                ctx.lineWidth = 2;

                // Schlüssel-Kopf (Ring oben)
                ctx.beginPath();
                ctx.arc(cx, floatingY, w * 0.2, 0, Math.PI * 2);
                ctx.fill();
                ctx.stroke();

                // Loch im Kopf
                ctx.globalCompositeOperation = 'destination-out';
                ctx.beginPath();
                ctx.arc(cx, floatingY, w * 0.08, 0, Math.PI * 2);
                ctx.fill();
                ctx.globalCompositeOperation = 'source-over';

                // Schaft (Stab)
                ctx.fillRect(cx - w * 0.05, floatingY + w * 0.2, w * 0.1, h * 0.5);

                // Bart (die Zacken unten)
                ctx.fillRect(cx + w * 0.05, floatingY + w * 0.2 + h * 0.35, w * 0.15, h * 0.06);
                ctx.fillRect(cx + w * 0.05, floatingY + w * 0.2 + h * 0.45, w * 0.12, h * 0.06);
            } else if (s.type === 'torch') {
                ctx.fillStyle = '#ff6600'; // Feste Farbe, da kein Flackern mehr durch Blitz
                ctx.beginPath(); ctx.arc(screenX, spriteTop, spriteWidth / 2, 0, Math.PI * 2); ctx.fill();
            } else if (s.type === 'corpse') {
                // Leiche/Skelett als flaches, fest ausgerichtetes Boden-Decal
                drawCorpseDecal(ctx, cam, s);
            } else if (s.type === 'stairs') {
                // 3D-Treppe am Boden verankern und zeichnen
                drawStairs3DWorld(ctx, cam, s);
            } else if (s.type === 'furniture') {
                // Echte 3D-Box mit fester Welt-Ausrichtung
                drawFurniture3D(ctx, cam, s);
            } else if (s.type === 'closet') {
                drawCloset3D(ctx, cam, s);
            }
            ctx.globalAlpha = 1.0;
        }
    });

    // --- 3D STAUB PARTIKEL (Performance-optimierter Wrap-Around) ---
    if (!window._dustParticles3D) {
        window._dustParticles3D = [];
        for (let i = 0; i < 45; i++) { // Reduziert für konstante 60 FPS auf Low-End-Geräten
            window._dustParticles3D.push({
                x: player.x + (Math.random() - 0.5) * 600,
                y: player.y + (Math.random() - 0.5) * 600,
                z: Math.random() * TILE_SIZE, // 0 (Boden) bis TILE_SIZE (Decke)
                vx: (Math.random() - 0.5) * 0.4,
                vy: (Math.random() - 0.5) * 0.4,
                vz: (Math.random() - 0.5) * 0.2 - 0.1, // Leichtes Sinken
                size: Math.random() * 2 + 0.5,
                phase: Math.random() * Math.PI * 2
            });
        }
    }

    let flicker = window._flashlightFlicker || 1.0;
    let flashlightRadius = NUM_RAYS / 2.3;
    // Staubpartikel werden nun auch im Zentrum des Blicks beleuchtet
    let screenCenterY = canvas.height / 2;

    window._dustParticles3D.forEach(p => {
        // Bewegung
        p.x += p.vx + Math.sin(time + p.phase) * 0.3;
        p.y += p.vy + Math.cos(time + p.phase) * 0.3;
        p.z += p.vz;

        // Wrap-around um den Spieler
        if (p.x - pX > 300) p.x -= 600;
        if (p.x - pX < -300) p.x += 600;
        if (p.y - pY > 300) p.y -= 600;
        if (p.y - pY < -300) p.y += 600;
        if (p.z < 0) p.z += TILE_SIZE;
        if (p.z > TILE_SIZE) p.z -= TILE_SIZE;

        let dx = p.x - pX;
        let dy = p.y - pY;
        let dist = Math.hypot(dx, dy);

        // Nur rendern wenn vor dem Spieler und im Sichtfeld
        if (dist > 10 && dist < 650) {
            let angleToDust = Math.atan2(dy, dx);
            let dAngle = angleToDust - pAngle;
            while (dAngle > Math.PI) dAngle -= Math.PI * 2;
            while (dAngle < -Math.PI) dAngle += Math.PI * 2;

            if (Math.abs(dAngle) < FOV / 1.3) {
                let screenX = (0.5 * (dAngle / (FOV / 2)) + 0.5) * canvas.width;
                let projectedDist = dist * Math.cos(dAngle);

                let centerIdx = Math.floor(screenX / STRIP_WIDTH);
                // Z-Buffer check (wird hinter Wänden versteckt)
                if (centerIdx >= 0 && centerIdx < NUM_RAYS && zBuffer[centerIdx] > projectedDist - 5) {

                    let spriteScale = (TILE_SIZE * canvas.height * 0.8) / projectedDist;
                    // Z-Koordinate auf Bildschirm-Y abbilden
                    let dustY = (canvas.height / 2) + (spriteScale / 2) + pitchOffset - (p.z / TILE_SIZE) * spriteScale;

                    let centerDistX = Math.abs((screenX / canvas.width) - 0.5) * NUM_RAYS;
                    let centerDistY = Math.abs(dustY - screenCenterY) / canvas.height * NUM_RAYS;
                    let centerDist2D = Math.sqrt(centerDistX * centerDistX + centerDistY * centerDistY);

                    // Nur rendern wenn im runden Taschenlampenkegel
                    if (centerDist2D < flashlightRadius * 2) {
                        let distFalloff = 1 / (1 + (dist / 120) * (dist / 120)) * 2.5;
                        let intensity = Math.pow(Math.max(0, 1 - (centerDist2D / flashlightRadius)), 2.5) * distFalloff * 6.0 * flicker;

                        if (intensity > 0.05) {
                            let alpha = Math.min(1, intensity);
                            let sSize = Math.max(0.5, Math.min(8, p.size * (150 / projectedDist))); // Partikel kleiner

                            // Vorgerenderter Glow-Sprite statt teurem Gradient pro Partikel
                            ctx.globalAlpha = alpha;
                            ctx.drawImage(dustSprite, screenX - sSize * 2, dustY - sSize * 2, sSize * 4, sSize * 4);
                        }
                    }
                }
            }
        }
    });
    ctx.globalAlpha = 1.0;

    // Taschenlampe (Hand + Lichtkegel) nur im Spiel zeichnen — nicht im Hauptmenü
    if (gameState === 'playing') drawFirstPersonOverlay();

    // --- ATMOSPHÄRISCHE VIGNETTE: verdunkelte Ränder; pocht dunkelrot, wenn das
    //     Monster nah ist (Dread). Gradienten werden gecacht → günstig für schwache Geräte. ---
    if (gameState === 'playing') {
        if (!window._vigGrad || window._vigW !== width || window._vigH !== height) {
            const vg = ctx.createRadialGradient(width / 2, height / 2, Math.min(width, height) * 0.34,
                                                width / 2, height / 2, Math.max(width, height) * 0.62);
            vg.addColorStop(0, 'rgba(0,0,0,0)');
            vg.addColorStop(0.7, 'rgba(0,0,0,0.30)');
            vg.addColorStop(1, 'rgba(0,0,0,0.82)');
            window._vigGrad = vg; window._vigW = width; window._vigH = height;
        }
        ctx.globalAlpha = 0.7;
        ctx.fillStyle = window._vigGrad;
        ctx.fillRect(0, 0, width, height);

        // Nächstes Monster auf dieser Etage suchen → Nähe steuert das rote Pochen
        let nearest = Infinity;
        for (let k = 0; k < enemiesData.length; k++) {
            const en = enemiesData[k];
            if (en.floor !== currentFloor) continue;
            const dd = Math.hypot(en.x - pX, en.y - pY);
            if (dd < nearest) nearest = dd;
        }
        const danger = nearest < 650 ? (1 - nearest / 650) : 0;
        if (danger > 0.01) {
            if (!window._dangerGrad || window._dgW !== width || window._dgH !== height) {
                const dg = ctx.createRadialGradient(width / 2, height / 2, Math.min(width, height) * 0.22,
                                                    width / 2, height / 2, Math.max(width, height) * 0.6);
                dg.addColorStop(0, 'rgba(50,0,0,0)');
                dg.addColorStop(1, 'rgba(60,0,0,0.9)');
                window._dangerGrad = dg; window._dgW = width; window._dgH = height;
            }
            const pulse = 0.5 + Math.sin(time * 6) * 0.5;
            ctx.globalAlpha = danger * (0.2 + pulse * 0.3);
            ctx.fillStyle = window._dangerGrad;
            ctx.fillRect(0, 0, width, height);
        }
        ctx.globalAlpha = 1.0;
    }

    // --- FILMKORN (analoges Rauschen für mehr Unbehagen) ---
    if (gameState === 'playing') {
        if (!window._grainPattern) {
            const gcv = document.createElement('canvas');
            gcv.width = 256; gcv.height = 256;
            const gctx = gcv.getContext('2d');
            const gd = gctx.createImageData(256, 256);
            for (let i = 0; i < gd.data.length; i += 4) {
                const v = (Math.random() * 255) | 0;
                gd.data[i] = gd.data[i + 1] = gd.data[i + 2] = v;
                gd.data[i + 3] = 10; // dezenter (weniger "verrauscht/pixelig")
            }
            gctx.putImageData(gd, 0, 0);
            window._grainPattern = ctx.createPattern(gcv, 'repeat');
        }
        ctx.save();
        // Zufälliger Offset pro Frame lässt das Korn "leben"
        ctx.translate(-((Math.random() * 256) | 0), -((Math.random() * 256) | 0));
        ctx.fillStyle = window._grainPattern;
        ctx.fillRect(0, 0, width + 256, height + 256);
        ctx.restore();
    }

    // Versteck-Overlay (Schranktüren + Spalt + QTE) über die ganze Szene legen
    if (gameState === 'playing' && hideState.active) { drawHideOverlay(); drawHidePanic(); }

    // Treppen-Fade Animation
    if (fadeAlpha > 0.01) {
        ctx.fillStyle = `rgba(0,0,0,${fadeAlpha})`;
        ctx.fillRect(0, 0, width, height);
    }

    // Red screen effect (drawn last, on top of everything else)
    if (jumpscareEffect.currentRedIntensity > 0.001) { // Check for a small threshold
        ctx.globalAlpha = jumpscareEffect.currentRedIntensity;

        // Add a red vignette for more intensity at edges
        let redVignette = ctx.createRadialGradient(width / 2, height / 2, width / 4, width / 2, height / 2, width / 2);
        redVignette.addColorStop(0, 'rgba(255,0,0,0)');
        redVignette.addColorStop(0.7, 'rgba(150,0,0,0.2)');
        redVignette.addColorStop(1, 'rgba(139,0,0,0.8)'); // Dunkles Blutrot am Rand
        ctx.fillStyle = redVignette;
        ctx.fillRect(0, 0, width, height);
        ctx.globalAlpha = 1.0; // Reset globalAlpha
    }
}

// --- FNAF-STYLE TV-STATIC für das Hauptmenü ---
function drawMenuStatic() {
    const sc = document.getElementById('menu-static');
    if (!sc) return;
    if (sc.width !== 160) { sc.width = 160; sc.height = 90; }
    const sctx = sc.getContext('2d');
    const id = sctx.createImageData(160, 90);
    for (let i = 0; i < id.data.length; i += 4) {
        const v = (Math.random() * 255) | 0;
        id.data[i] = id.data[i + 1] = id.data[i + 2] = v;
        id.data[i + 3] = 255;
    }
    sctx.putImageData(id, 0, 0);
}

// --- ATMOSPHÄRE im Hauptmenü: langsam aufsteigende, glühende Aschepartikel ---
let menuParticles = null;
function drawMenuAtmosphere() {
    const cv = document.getElementById('menu-particles');
    if (!cv) return;
    const w = window.innerWidth, h = window.innerHeight;
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const c = cv.getContext('2d');

    if (!menuParticles) {
        menuParticles = [];
        for (let i = 0; i < 75; i++) {
            menuParticles.push({
                x: Math.random() * w,
                y: Math.random() * h,
                r: 0.5 + Math.random() * 1.9,
                spd: 0.12 + Math.random() * 0.55,   // Steiggeschwindigkeit
                drift: (Math.random() - 0.5) * 0.35, // seitliches Treiben
                a: 0.08 + Math.random() * 0.4,       // Grundhelligkeit
                tw: Math.random() * Math.PI * 2      // Flacker-Phase
            });
        }
    }

    c.clearRect(0, 0, w, h);
    const now = Date.now() * 0.001;
    for (const p of menuParticles) {
        p.y -= p.spd;
        p.x += p.drift + Math.sin(now * 0.6 + p.tw) * 0.18;
        if (p.y < -6) { p.y = h + 6; p.x = Math.random() * w; }
        if (p.x < -6) p.x = w + 6; else if (p.x > w + 6) p.x = -6;
        const flick = 0.55 + Math.sin(now * 2.2 + p.tw) * 0.45;
        c.beginPath();
        c.fillStyle = `rgba(190, 70, 45, ${p.a * flick})`; // glühende Asche/Glut
        c.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        c.fill();
    }
}

// Performance-Monitor: misst die echte Frame-Zeit und passt die Render-Auflösung
// automatisch an — so bleibt das Spiel auch auf Low-End-Geräten flüssig
let perfLast = performance.now(), perfAccum = 0, perfFrames = 0;

function gameLoop() {
    const perfNow = performance.now();
    if (gameState === 'playing') {
        perfAccum += perfNow - perfLast;
        perfFrames++;
        if (perfFrames >= 45) { // schneller reagieren (~0.75 s)
            const avgMs = perfAccum / perfFrames;
            // Ziel: ~60 FPS (16.6 ms). Über 18 ms → gröber; deutlich drunter → schärfer.
            if (avgMs > 18 && renderScale < 4) {
                renderScale = Math.min(4, renderScale + 0.25); // zu langsam: Auflösung senken
                resize();
            } else if (avgMs < 12 && renderScale > 1.25) {
                renderScale = Math.max(1.25, renderScale - 0.25); // viel Reserve: schärfer rendern
                resize();
            }
            perfAccum = 0; perfFrames = 0;
        }
    } else {
        perfAccum = 0; perfFrames = 0;
    }
    perfLast = perfNow;

    update();
    render();
    // TV-Rauschen + Atmosphäre im Menü animieren
    if (gameState === 'start') {
        drawMenuStatic();
        drawMenuAtmosphere();
    }
    // HUD Minimap jedes Frame aktualisieren
    if (gameState === 'playing') {
        drawHudMinimap();
    }
    // Große Minimap aktualisieren wenn offen
    if (minimapOpen) {
        drawMinimap();
    }
    // Interaktionstaste gilt immer nur für einen Frame
    interactPressed = false;
    requestAnimationFrame(gameLoop);
}

// --- MINIMAP FUNKTIONEN ---

function toggleMinimap() {
    minimapOpen = !minimapOpen;
    const overlay = document.getElementById('minimap-overlay');
    if (minimapOpen) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

// HUD Minimap ein-/ausblenden bei Spielstart
function showHudMinimap() {
    const hud = document.getElementById('minimap-hud');
    if (hud) hud.classList.remove('hidden-hud');
}
function hideHudMinimap() {
    const hud = document.getElementById('minimap-hud');
    if (hud) hud.classList.add('hidden-hud');
}

// Aktueller Scanner-Winkel (rotierender Radar-Sweep auf der Minimap)
let scannerAngle = 0;

function updateExploration() {
    // SCANNER-AUFDECKUNG: Statt ganze Räume sofort zu zeigen, deckt die Karte
    // nur das auf, was der Spieler tatsächlich SIEHT. Strahlen gehen vom Spieler
    // aus und stoppen an Wänden/geschlossenen Türen — kein Blick durch Wände.
    const explored = exploredTiles[currentFloor];
    const grid = maps[currentFloor];
    if (!explored || !grid) return;

    const px = player.x / TILE_SIZE;
    const py = player.y / TILE_SIZE;
    const pcx = Math.floor(px), pcy = Math.floor(py);
    if (pcx < 0 || pcy < 0 || pcx >= MAP_WIDTH || pcy >= MAP_HEIGHT) return;

    explored.add(pcy * MAP_WIDTH + pcx);

    const RADIUS = 4.5;   // Reichweite des Scanners in Kacheln (kleiner = klaustrophobischer)
    const RAYS = 150;     // Winkel-Auflösung der Abtastung
    const STEP = 0.2;
    const lk = doorLookup[currentFloor];

    for (let a = 0; a < RAYS; a++) {
        const ang = (a / RAYS) * Math.PI * 2;
        const cos = Math.cos(ang), sin = Math.sin(ang);
        let lastKey = -1;
        for (let r = 0.5; r <= RADIUS; r += STEP) {
            const fx = px + cos * r, fy = py + sin * r;
            if (fx < 0 || fy < 0 || fx >= MAP_WIDTH || fy >= MAP_HEIGHT) break;
            const tx = fx | 0, ty = fy | 0;
            const key = ty * MAP_WIDTH + tx;
            if (key !== lastKey) {
                lastKey = key;
                explored.add(key);
                const t = grid[ty][tx];
                let blocks = (t === '1' || 'KSWB'.includes(t));
                if (t === '2') { // geschlossene Tür blockt die Sicht
                    const d = lk && lk.get(key);
                    if (!d || d.open < 0.5) blocks = true;
                }
                if (blocks) break; // Wand wird noch aufgedeckt, dahinter aber nichts mehr
            }
        }
    }

    // Radar-Sweep weiterdrehen (rein optisch)
    scannerAngle = (scannerAngle + 0.06) % (Math.PI * 2);
}

let minimapCache = document.createElement('canvas');
let minimapCacheCtx = minimapCache.getContext('2d', { alpha: false });

function updateMinimapCache() {
    if (!exploredTiles[currentFloor]) return;
    if (minimapCacheFloor === currentFloor && minimapCacheExploredSize === exploredTiles[currentFloor].size) return;
    
    minimapCacheFloor = currentFloor;
    minimapCacheExploredSize = exploredTiles[currentFloor].size;
    
    const CELL = 8;
    if (minimapCache.width !== MAP_WIDTH * CELL) {
        minimapCache.width = MAP_WIDTH * CELL;
        minimapCache.height = MAP_HEIGHT * CELL;
    }
    
    minimapCacheCtx.fillStyle = '#111115';
    minimapCacheCtx.fillRect(0, 0, minimapCache.width, minimapCache.height);
    
    const grid = maps[currentFloor];
    const explored = exploredTiles[currentFloor];
    if (!grid || !explored) return;
    
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const key = y * MAP_WIDTH + x;
            if (!explored.has(key)) continue;
            
            const tile = grid[y][x];
            let color = '';
            
            if (tile === '0') color = '#333340';
            else if (tile === '1') color = '#5c4b38';
            else if (tile === 'K') color = '#2e522e';
            else if (tile === 'S') color = '#2e2e52';
            else if (tile === 'W') color = '#522626';
            else if (tile === 'B') color = '#525226';
            else if (tile === '2') color = '#8c541d';
            else if (tile === 'U' || tile === 'D') color = '#33bbff';
            else if (tile === 'E') color = '#ffffff'; // Weiße Exit-Tür
            else color = '#222222';
            
            minimapCacheCtx.fillStyle = color;
            minimapCacheCtx.fillRect(x * CELL, y * CELL, CELL, CELL);
        }
    }
    
    minimapCacheCtx.strokeStyle = 'rgba(255, 0, 0, 0.5)';
    minimapCacheCtx.lineWidth = 1;
    for (let y = 0; y < MAP_HEIGHT; y++) {
        for (let x = 0; x < MAP_WIDTH; x++) {
            const key = y * MAP_WIDTH + x;
            if (!explored.has(key)) continue;
            
            const neighbors = [[0,-1],[0,1],[-1,0],[1,0]];
            for (const [ndx, ndy] of neighbors) {
                const nx = x + ndx;
                const ny = y + ndy;
                if (nx >= 0 && nx < MAP_WIDTH && ny >= 0 && ny < MAP_HEIGHT) {
                    if (!explored.has(ny * MAP_WIDTH + nx)) {
                        minimapCacheCtx.beginPath();
                        if (ndx === 1) { minimapCacheCtx.moveTo((x+1)*CELL, y*CELL); minimapCacheCtx.lineTo((x+1)*CELL, (y+1)*CELL); }
                        if (ndx === -1) { minimapCacheCtx.moveTo(x*CELL, y*CELL); minimapCacheCtx.lineTo(x*CELL, (y+1)*CELL); }
                        if (ndy === 1) { minimapCacheCtx.moveTo(x*CELL, (y+1)*CELL); minimapCacheCtx.lineTo((x+1)*CELL, (y+1)*CELL); }
                        if (ndy === -1) { minimapCacheCtx.moveTo(x*CELL, y*CELL); minimapCacheCtx.lineTo((x+1)*CELL, y*CELL); }
                        minimapCacheCtx.stroke();
                    }
                }
            }
        }
    }
}

// --- GROßE MINIMAP (Overlay, volle Karte) ---
function drawMinimap() {
    updateMinimapCache();
    
    const mmCanvas = document.getElementById('minimapCanvas');
    if (!mmCanvas) return;
    const mmCtx = mmCanvas.getContext('2d', { alpha: false });

    if (mmCanvas.width !== minimapCache.width) {
        mmCanvas.width = minimapCache.width;
        mmCanvas.height = minimapCache.height;
    }

    mmCtx.drawImage(minimapCache, 0, 0);

    const CELL = 8;
    const explored = exploredTiles[currentFloor];
    if (!explored) return;

    keysData.forEach(k => {
        if (k.collected || k.floor !== currentFloor) return;
        const kx = Math.floor(k.x / TILE_SIZE);
        const ky = Math.floor(k.y / TILE_SIZE);
        if (!explored.has(ky * MAP_WIDTH + kx)) return;

        const pulse = Math.sin(Date.now() / 200) * 0.3 + 0.7;
        mmCtx.fillStyle = `rgba(255, 215, 0, ${pulse})`;
        mmCtx.shadowColor = '#ffd700';
        mmCtx.shadowBlur = 6;
        mmCtx.beginPath();
        mmCtx.arc(kx * CELL + CELL / 2, ky * CELL + CELL / 2, CELL * 0.5, 0, Math.PI * 2);
        mmCtx.fill();
        mmCtx.shadowBlur = 0;
    });

    // Weiße Exit-Tür pulsierend hervorheben (nur wenn ihr Raum schon entdeckt wurde)
    if (exitSpawned && exitFloor === currentFloor && explored.has(exitTileY * MAP_WIDTH + exitTileX)) {
        const ep = Math.sin(Date.now() / 150) * 0.3 + 0.7;
        mmCtx.fillStyle = `rgba(255, 255, 255, ${ep})`;
        mmCtx.shadowColor = '#ffffff';
        mmCtx.shadowBlur = 10;
        mmCtx.beginPath();
        mmCtx.arc(exitTileX * CELL + CELL / 2, exitTileY * CELL + CELL / 2, CELL * 0.6, 0, Math.PI * 2);
        mmCtx.fill();
        mmCtx.shadowBlur = 0;
    }

    const playerScreenX = (player.x / TILE_SIZE) * CELL;
    const playerScreenY = (player.y / TILE_SIZE) * CELL;

    const arrowLen = CELL * 2;
    const arrowAngle = player.angle;
    mmCtx.fillStyle = 'rgba(0, 255, 0, 0.6)';
    mmCtx.beginPath();
    mmCtx.moveTo(playerScreenX + Math.cos(arrowAngle) * arrowLen, playerScreenY + Math.sin(arrowAngle) * arrowLen);
    mmCtx.lineTo(playerScreenX + Math.cos(arrowAngle + 2.5) * arrowLen * 0.5, playerScreenY + Math.sin(arrowAngle + 2.5) * arrowLen * 0.5);
    mmCtx.lineTo(playerScreenX + Math.cos(arrowAngle - 2.5) * arrowLen * 0.5, playerScreenY + Math.sin(arrowAngle - 2.5) * arrowLen * 0.5);
    mmCtx.closePath();
    mmCtx.fill();

    const playerPulse = Math.sin(Date.now() / 250) * 0.3 + 0.7;
    mmCtx.fillStyle = `rgba(0, 255, 0, ${playerPulse})`;
    mmCtx.shadowColor = '#00ff00';
    mmCtx.shadowBlur = 10;
    mmCtx.beginPath();
    mmCtx.arc(playerScreenX, playerScreenY, CELL * 0.7, 0, Math.PI * 2);
    mmCtx.fill();
    mmCtx.shadowBlur = 0;

    const vigGrad = mmCtx.createRadialGradient(
        playerScreenX, playerScreenY, mmCanvas.width * 0.15,
        playerScreenX, playerScreenY, mmCanvas.width * 0.55
    );
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.7, 'rgba(0,0,0,0.2)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    mmCtx.fillStyle = vigGrad;
    mmCtx.fillRect(0, 0, mmCanvas.width, mmCanvas.height);

    const titleEl = document.getElementById('minimap-title');
    if (titleEl) {
        const floorNames = ["Ground Floor", "1st Floor", "2nd Floor", "3rd Floor", "Attic"];
        let name = floorNames[currentFloor] || (currentFloor + ". Floor");
        if (currentFloor === maps.length - 1) name = "Attic";
        titleEl.textContent = name.toUpperCase();
    }
}

// --- KLEINE HUD MINIMAP (dauerhaft rechts unten, flüssig zentriert) ---
const HUD_SIZE = 240; 
const HUD_CELL = 8;   

function drawHudMinimap() {
    updateMinimapCache();

    const hudCanvas = document.getElementById('minimapHudCanvas');
    if (!hudCanvas) return;
    const hCtx = hudCanvas.getContext('2d', { alpha: false });

    if (hudCanvas.width !== HUD_SIZE) {
        hudCanvas.width = HUD_SIZE;
        hudCanvas.height = HUD_SIZE;
    }

    const explored = exploredTiles[currentFloor];
    if (!explored) return;

    // Weiche Kamera-Bewegung (Sub-Pixel genau)
    const pxInCells = player.x / TILE_SIZE;
    const pyInCells = player.y / TILE_SIZE;
    
    const viewHalf = HUD_SIZE / 2;
    const cacheX = pxInCells * HUD_CELL - viewHalf;
    const cacheY = pyInCells * HUD_CELL - viewHalf;

    hCtx.fillStyle = '#060608';
    hCtx.fillRect(0, 0, HUD_SIZE, HUD_SIZE);

    hCtx.save();
    hCtx.translate(-cacheX, -cacheY);
    hCtx.drawImage(minimapCache, 0, 0);

    // Schlüssel zeichnen
    keysData.forEach(k => {
        if (k.collected || k.floor !== currentFloor) return;
        const kx = Math.floor(k.x / TILE_SIZE);
        const ky = Math.floor(k.y / TILE_SIZE);
        if (!explored.has(ky * MAP_WIDTH + kx)) return;

        const pulse = Math.sin(Date.now() / 200) * 0.3 + 0.7;
        hCtx.fillStyle = `rgba(255, 215, 0, ${pulse})`;
        hCtx.shadowColor = '#ffd700';
        hCtx.shadowBlur = 4;
        hCtx.beginPath();
        hCtx.arc(kx * HUD_CELL + HUD_CELL / 2, ky * HUD_CELL + HUD_CELL / 2, HUD_CELL * 0.45, 0, Math.PI * 2);
        hCtx.fill();
        hCtx.shadowBlur = 0;
    });

    // Weiße Exit-Tür auch auf der HUD-Map pulsieren lassen
    if (exitSpawned && exitFloor === currentFloor && explored.has(exitTileY * MAP_WIDTH + exitTileX)) {
        const ep = Math.sin(Date.now() / 150) * 0.3 + 0.7;
        hCtx.fillStyle = `rgba(255, 255, 255, ${ep})`;
        hCtx.shadowColor = '#ffffff';
        hCtx.shadowBlur = 6;
        hCtx.beginPath();
        hCtx.arc(exitTileX * HUD_CELL + HUD_CELL / 2, exitTileY * HUD_CELL + HUD_CELL / 2, HUD_CELL * 0.55, 0, Math.PI * 2);
        hCtx.fill();
        hCtx.shadowBlur = 0;
    }

    hCtx.restore();

    // Spieler immer exakt in der Mitte
    const playerHudX = viewHalf;
    const playerHudY = viewHalf;

    const arrowLen = HUD_CELL * 1.5;
    const angle = player.angle;
    hCtx.fillStyle = 'rgba(0, 255, 0, 0.7)';
    hCtx.beginPath();
    hCtx.moveTo(playerHudX + Math.cos(angle) * arrowLen, playerHudY + Math.sin(angle) * arrowLen);
    hCtx.lineTo(playerHudX + Math.cos(angle + 2.5) * arrowLen * 0.4, playerHudY + Math.sin(angle + 2.5) * arrowLen * 0.4);
    hCtx.lineTo(playerHudX + Math.cos(angle - 2.5) * arrowLen * 0.4, playerHudY + Math.sin(angle - 2.5) * arrowLen * 0.4);
    hCtx.closePath();
    hCtx.fill();

    const pp = Math.sin(Date.now() / 250) * 0.3 + 0.7;
    hCtx.fillStyle = `rgba(0, 255, 0, ${pp})`;
    hCtx.shadowColor = '#00ff00';
    hCtx.shadowBlur = 6;
    hCtx.beginPath();
    hCtx.arc(playerHudX, playerHudY, HUD_CELL * 0.5, 0, Math.PI * 2);
    hCtx.fill();
    hCtx.shadowBlur = 0;

    // --- RADAR-SWEEP: kleine, rotierende Scanner-Optik um den Spieler ---
    const sweepR = HUD_SIZE * 0.3; // kompakter als zuvor
    // konzentrische Scan-Ringe
    hCtx.strokeStyle = 'rgba(0, 255, 100, 0.06)';
    hCtx.lineWidth = 1;
    for (let ri = 1; ri <= 2; ri++) {
        hCtx.beginPath();
        hCtx.arc(playerHudX, playerHudY, sweepR * (ri / 2), 0, Math.PI * 2);
        hCtx.stroke();
    }
    // nachleuchtender Keil hinter der Sweep-Linie
    const sweepGrad = hCtx.createRadialGradient(playerHudX, playerHudY, 0, playerHudX, playerHudY, sweepR);
    sweepGrad.addColorStop(0, 'rgba(0, 255, 100, 0.18)');
    sweepGrad.addColorStop(1, 'rgba(0, 255, 100, 0)');
    hCtx.fillStyle = sweepGrad;
    hCtx.beginPath();
    hCtx.moveTo(playerHudX, playerHudY);
    hCtx.arc(playerHudX, playerHudY, sweepR, scannerAngle - 0.5, scannerAngle);
    hCtx.closePath();
    hCtx.fill();
    // helle Sweep-Linie
    hCtx.strokeStyle = 'rgba(120, 255, 160, 0.45)';
    hCtx.lineWidth = 1.5;
    hCtx.beginPath();
    hCtx.moveTo(playerHudX, playerHudY);
    hCtx.lineTo(playerHudX + Math.cos(scannerAngle) * sweepR, playerHudY + Math.sin(scannerAngle) * sweepR);
    hCtx.stroke();

    // Runde Schatten-Vignette
    const vigGrad = hCtx.createRadialGradient(viewHalf, viewHalf, HUD_SIZE * 0.15, viewHalf, viewHalf, HUD_SIZE * 0.5);
    vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vigGrad.addColorStop(0.6, 'rgba(0,0,0,0.15)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.5)');
    hCtx.fillStyle = vigGrad;
    hCtx.fillRect(0, 0, HUD_SIZE, HUD_SIZE);

    const floorEl = document.getElementById('minimap-hud-floor');
    if (floorEl) {
        const floorNames = ["GF", "1st", "2nd", "3rd", "Attic"];
        let name = floorNames[currentFloor] || (currentFloor + "th");
        if (currentFloor === maps.length - 1) name = "Attic";
        floorEl.textContent = name;
    }
}

gameLoop();